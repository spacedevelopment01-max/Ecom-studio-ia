{literal}<div id="shopify-section-template--es__main_page_4" class="shopify-section " data-es-section="page.faq:main_page_4" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;"><div class="es-container es-page__inner"><h1 class="es-heading es-h1" data-reveal="lines">Questions fréquentes</h1><div class="es-rte es-page__content" data-reveal="up"></div>
  </div><script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Entretien de pianos — RECETTE", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Questions fréquentes", "item": "/pages/faq" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__faq_5" class="shopify-section es-section-wrapper" data-es-section="page.faq:faq_5" data-es-type="faq"><section class="es-section es-faq es-faq--cards es-faq--side es-faq--cols-1 color-scheme-1" style="--pt: 104px; --pb: 104px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Questions fréquentes</h2></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_5"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="question_21">
          <summary><span class="es-faq__q">Comment obtenir un devis ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Décrivez votre projet dans le formulaire de la page Contact ; nous revenons vers vous avec une proposition détaillée.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="question_22">
          <summary><span class="es-faq__q">Où intervenez-vous ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : votre zone d'intervention ou votre adresse]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="question_23">
          <summary><span class="es-faq__q">Quels sont vos horaires ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : vos horaires]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 3" data-faq-item data-es-block="question_24">
          <summary><span class="es-faq__q">Quels sont vos tarifs ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : vos tarifs, ou la façon dont ils sont établis]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 4" data-faq-item data-es-block="question_25">
          <summary><span class="es-faq__q">Comment se déroule une première prestation ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : le déroulement d'une première prestation]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 5" data-faq-item data-es-block="question_26">
          <summary><span class="es-faq__q">Quels moyens de paiement acceptez-vous ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : les moyens de paiement acceptés]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 6" data-faq-item data-es-block="question_27">
          <summary><span class="es-faq__q">Quelles conditions ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Elles sont à confirmer dans le projet.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 7" data-faq-item data-es-block="question_28">
          <summary><span class="es-faq__q">Quels délais ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Ils restent à confirmer.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Comment obtenir un devis ?", "acceptedAnswer": { "@type": "Answer", "text": "Décrivez votre projet dans le formulaire de la page Contact ; nous revenons vers vous avec une proposition détaillée." } },{ "@type": "Question", "name": "Où intervenez-vous ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : votre zone d'intervention ou votre adresse]" } },{ "@type": "Question", "name": "Quels sont vos horaires ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : vos horaires]" } },{ "@type": "Question", "name": "Quels sont vos tarifs ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : vos tarifs, ou la façon dont ils sont établis]" } },{ "@type": "Question", "name": "Comment se déroule une première prestation ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : le déroulement d'une première prestation]" } },{ "@type": "Question", "name": "Quels moyens de paiement acceptez-vous ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : les moyens de paiement acceptés]" } },{ "@type": "Question", "name": "Quelles conditions ?", "acceptedAnswer": { "@type": "Answer", "text": "Elles sont à confirmer dans le projet." } },{ "@type": "Question", "name": "Quels délais ?", "acceptedAnswer": { "@type": "Answer", "text": "Ils restent à confirmer." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__contact_form_3" class="shopify-section " data-es-section="page.faq:contact_form_3" data-es-type="contact-form"><section class="es-section es-contact color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-contact__grid"><header class="es-contact__intro"><h2 class="es-heading es-h2" data-reveal="words">Une autre question ?</h2><div class="es-rte es-contact__text" data-reveal="up"><p>Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser.</p></div><ul class="es-contact__details" role="list" data-reveal="up" style="--d: 1"><li><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><a href="mailto:recette@example.invalid">recette@example.invalid</a></li></ul></header><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="ContactForm" class="es-form es-contact__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><div class="es-form__row">
        <label>Nom<input type="text" name="contact[name]" autocomplete="name" value=""></label>
        <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label>
      </div><label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label><label>Message<textarea name="contact[body]" rows="6" class="es-textarea"></textarea></label><button type="submit" class="es-button">Envoyer</button></form></div>
</section>





</div>{/literal}