{literal}<div id="shopify-section-template--es__hero_split_1" class="shopify-section es-section-wrapper" data-es-section="index:hero_split_1" data-es-type="hero-split"><section class="es-section es-ambient es-hero-split es-hero-split--right es-hero-split--large color-scheme-1" style="--pt: 72px; --pb: 104px;">
  <div class="es-container es-hero-split__grid">
    <div class="es-hero-split__content"><p class="es-pill-badge" data-reveal="up"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>RECETTE TECHNIQUE</p><p class="es-eyebrow" data-reveal="up">RECETTE ISOLÉE — CONTENUS FICTIFS</p><h1 class="es-heading es-h1" data-reveal="words">Votre piano, une <span class="es-accent">attention précise.</span></h1><div class="es-rte es-lead" data-reveal="up" style="--d: 1"><p>Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser.</p></div><div class="es-actions es-actions--stack" data-reveal="up" style="--d: 2"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button">Demander un devis <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a><a href="{/literal}{$urls.base_url}{literal}pages/prestations" class="es-button es-button--secondary">Nos prestations</a></div>
    </div>
    <div class="es-hero-split__media es-media-frame" data-reveal="zoom" data-parallax="0.12">
      <img src="{/literal}{$urls.base_url}{literal}themes/esentretiendepianosrc96c9759/assets/es/es-recette-service.webp" alt="Votre piano, une" class="es-cover" width="1600" height="1600" loading="eager" decoding="async" fetchpriority="high">
    </div>
  </div></section>




</div>
<div id="shopify-section-template--es__services_list_1" class="shopify-section es-section-wrapper" data-es-section="index:services_list_1" data-es-type="services-list"><section class="es-section es-svc es-svc--cards color-scheme-1" style="--pt: 104px; --pb: 104px; --cols: 1;">
  <div class="es-container"><header class="es-svc__head">
        <div><p class="es-eyebrow" data-reveal="up">Prestations</p><h2 class="es-heading es-h2" data-reveal="words">Ce que nous faisons pour vous</h2></div></header><ul class="es-svc__list" role="list"><li class="es-svc__item es-glow" data-reveal="up" style="--i: 0" data-es-block="service_1"><div class="es-svc__body">
            <div class="es-svc__top"><span class="es-svc__icon" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></svg></span></div>
            <h3 class="es-heading es-h4 es-svc__title">Entretien de piano</h3><div class="es-rte es-svc__text"><p>Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser.</p></div></div><div class="es-svc__action"><a class="es-link-arrow es-svc__link" href="{/literal}{$urls.base_url}{literal}pages/contact">
                <span>Demander un devis</span><span class="visually-hidden"> — Entretien de piano</span><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>
              </a></div></li></ul></div>
</section>




</div>
<div id="shopify-section-template--es__how_to_1" class="shopify-section es-section-wrapper" data-es-section="index:how_to_1" data-es-type="how-to"><section class="es-section es-howto es-howto--vertical es-howto--landscape color-scheme-1" style="--pt: 104px; --pb: 104px; --n: 3;" data-howto>
  <div class="es-container">
    <header class="es-howto__head"><p class="es-eyebrow" data-reveal="up">Notre méthode</p><h2 class="es-heading es-h2" data-reveal="words">Comment ça se passe</h2></header>
    <ol class="es-howto__list" role="list" data-howto-list>
      <li class="es-howto__rail" aria-hidden="true"><span class="es-howto__fill"></span></li><li class="es-howto__step is-lit" data-howto-step style="--i: 0" data-es-block="step_3">
          <span class="es-howto__node" aria-hidden="true"><span>01</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 1</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Décrivez votre projet</h3><div class="es-rte"><p>Quelques lignes suffisent : le besoin, le lieu, vos contraintes.</p></div></div>
        </li><li class="es-howto__step" data-howto-step style="--i: 1" data-es-block="step_4">
          <span class="es-howto__node" aria-hidden="true"><span>02</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 2</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Recevez votre devis</h3><div class="es-rte"><p>Une proposition détaillée, établie d'après votre demande.</p></div></div>
        </li><li class="es-howto__step" data-howto-step style="--i: 2" data-es-block="step_5">
          <span class="es-howto__node" aria-hidden="true"><span>03</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 3</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Nous réalisons</h3><div class="es-rte"><p>Le travail est réalisé selon ce qui a été convenu ensemble.</p></div></div>
        </li></ol><div class="es-actions es-actions--center"><a class="es-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Demander un devis</a></div></div>
</section>






</div>
<div id="shopify-section-template--es__testimonials_1" class="shopify-section es-section-wrapper" data-es-section="index:testimonials_1" data-es-type="testimonials"><section class="es-section es-testi color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container"><header class="es-section-head es-section-head--center es-testi__head"><p class="es-eyebrow" data-reveal="up">Avis</p><h2 class="es-heading es-h2" data-reveal="words">Ils nous ont fait confiance</h2></header>
      <div class="es-testi__track" data-reveal-stagger style="--n: 3"><figure class="es-testi__card" data-reveal="up" style="--i: 0" data-es-block="review_1"><span class="es-testi__mark" aria-hidden="true">&ldquo;</span>
            <blockquote class="es-testi__quote">[À compléter : avis réel d'un client, avec son accord]</blockquote><figcaption class="es-testi__who"><span><b>[À compléter : prénom]</b><small>[À compléter : prestation]</small></span>
            </figcaption>
          </figure><figure class="es-testi__card" data-reveal="up" style="--i: 1" data-es-block="review_2"><span class="es-testi__mark" aria-hidden="true">&ldquo;</span>
            <blockquote class="es-testi__quote">[À compléter : avis réel d'un client, avec son accord]</blockquote><figcaption class="es-testi__who"><span><b>[À compléter : prénom]</b><small>[À compléter : prestation]</small></span>
            </figcaption>
          </figure><figure class="es-testi__card" data-reveal="up" style="--i: 2" data-es-block="review_3"><span class="es-testi__mark" aria-hidden="true">&ldquo;</span>
            <blockquote class="es-testi__quote">[À compléter : avis réel d'un client, avec son accord]</blockquote><figcaption class="es-testi__who"><span><b>[À compléter : prénom]</b><small>[À compléter : prestation]</small></span>
            </figcaption>
          </figure></div></div>
</section>




</div>
<div id="shopify-section-template--es__practical_info_1" class="shopify-section es-section-wrapper" data-es-section="index:practical_info_1" data-es-type="practical-info"><section class="es-section es-info color-scheme-1" style="--pt: 104px; --pb: 104px;">
  <div class="es-container">
    <header class="es-info__head"><p class="es-eyebrow" data-reveal="up">Infos pratiques</p><h2 class="es-heading es-h2" data-reveal="words">Nous trouver, nous joindre</h2></header>

    <div class="es-info__grid">
      <div class="es-info__cards"><div class="es-info__card es-info__card--hours" data-reveal="up">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Horaires</h3>
            <dl class="es-info__hours"><div class="es-info__row"><dt>[À compléter : vos horaires, une ligne par jour]</dt><dd></dd></div></dl></div><div class="es-info__card" data-reveal="up" style="--d: 1">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>Adresse</h3><p class="es-info__area"><span class="es-info__label">Zone d'intervention</span>[À compléter : zone d'intervention ou adresse]</p></div><div class="es-info__card es-info__card--contact" data-reveal="up" style="--d: 2">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg>Nous joindre</h3><a class="es-info__email" href="mailto:recette@example.invalid"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><span>recette@example.invalid</span></a><a class="es-button es-button--full es-info__cta" href="{/literal}{$urls.base_url}{literal}pages/contact">Demander un devis</a></div></div></div>
  </div>
</section>






</div>
<div id="shopify-section-template--es__faq_2" class="shopify-section es-section-wrapper" data-es-section="index:faq_2" data-es-type="faq"><section class="es-section es-faq es-faq--cards es-faq--side es-faq--cols-1 color-scheme-2" style="--pt: 104px; --pb: 104px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Avant de décider</h2></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_2"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="question_5">
          <summary><span class="es-faq__q">Comment obtenir un devis ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Décrivez votre projet dans le formulaire de la page Contact ; nous revenons vers vous avec une proposition détaillée.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="question_6">
          <summary><span class="es-faq__q">Où intervenez-vous ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : votre zone d'intervention ou votre adresse]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="question_7">
          <summary><span class="es-faq__q">Quels sont vos horaires ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : vos horaires]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 3" data-faq-item data-es-block="question_8">
          <summary><span class="es-faq__q">Quels sont vos tarifs ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : vos tarifs, ou la façon dont ils sont établis]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 4" data-faq-item data-es-block="question_9">
          <summary><span class="es-faq__q">Comment se déroule une première prestation ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : le déroulement d'une première prestation]</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Comment obtenir un devis ?", "acceptedAnswer": { "@type": "Answer", "text": "Décrivez votre projet dans le formulaire de la page Contact ; nous revenons vers vous avec une proposition détaillée." } },{ "@type": "Question", "name": "Où intervenez-vous ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : votre zone d'intervention ou votre adresse]" } },{ "@type": "Question", "name": "Quels sont vos horaires ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : vos horaires]" } },{ "@type": "Question", "name": "Quels sont vos tarifs ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : vos tarifs, ou la façon dont ils sont établis]" } },{ "@type": "Question", "name": "Comment se déroule une première prestation ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : le déroulement d'une première prestation]" } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__booking_1" class="shopify-section es-section-wrapper" data-es-section="index:booking_1" data-es-type="booking"><section class="es-section es-booking es-booking--form color-scheme-2" style="--pt: 96px; --pb: 96px; --embed-h: 700px;">
  <div class="es-container es-booking__grid">
    <div class="es-booking__intro"><p class="es-eyebrow" data-reveal="up">Devis</p><h2 class="es-heading es-h2" data-reveal="words">Demander un devis</h2><div class="es-rte es-lead" data-reveal="up"><p>Décrivez votre projet : nous revenons vers vous avec une proposition détaillée.</p></div><ol class="es-booking__steps" role="list" data-reveal="up" style="--d: 1"><li data-es-block="step_6"><span class="es-booking__step-num" aria-hidden="true">1</span><span><strong>Décrivez votre projet</strong><span class="es-booking__step-text">Quelques lignes suffisent : le besoin, le lieu, vos contraintes.</span></span></li><li data-es-block="step_7"><span class="es-booking__step-num" aria-hidden="true">2</span><span><strong>Recevez votre devis</strong><span class="es-booking__step-text">Une proposition détaillée, établie d'après votre demande.</span></span></li><li data-es-block="step_8"><span class="es-booking__step-num" aria-hidden="true">3</span><span><strong>Nous réalisons</strong><span class="es-booking__step-text">Le travail est réalisé selon ce qui a été convenu ensemble.</span></span></li></ol><ul class="es-booking__direct" role="list" data-reveal="up" style="--d: 2"><li><a href="mailto:recette@example.invalid" class="es-booking__chip"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><span>recette@example.invalid</span></a></li></ul></div>

    <div class="es-booking__panel es-glow is-lit" data-reveal="up" style="--d: 1"><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="BookingForm-template--es__booking_1" class="es-form es-booking__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><input type="hidden" name="contact[Demande]" value="Demander un devis">
            <div class="es-form__row">
              <label>Nom *<input type="text" name="contact[name]" autocomplete="name" required value=""></label>
              <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
            </div>
            <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label><label>Prestation souhaitée
                <select name="contact[Prestation souhaitée]">
                  <option value="">Choisir une prestation</option><option value="Entretien de piano">Entretien de piano</option></select>
              </label><label>Créneau souhaité<input type="text" name="contact[Créneau souhaité]" placeholder="Ex. mardi en fin de journée"></label><label>Message<textarea name="contact[body]" rows="4" class="es-textarea"></textarea></label>
            <button type="submit" class="es-button es-button--full">Envoyer ma demande</button></form></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__cta_banner_2" class="shopify-section es-section-wrapper" data-es-section="index:cta_banner_2" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-3 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.6;"><div class="es-cta__media" data-parallax="0.2"><img src="{/literal}{$urls.base_url}{literal}themes/esentretiendepianosrc96c9759/assets/es/es-recette-service.webp" alt="" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Parlons de votre besoin.</h2><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button" data-reveal="up" style="--d: 1">Demander un devis <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>


</div>{/literal}