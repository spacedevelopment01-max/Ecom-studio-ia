{literal}<div id="shopify-section-template--es__hero_editorial_1" class="shopify-section es-section-wrapper" data-es-section="index:hero_editorial_1" data-es-type="hero-editorial"><section class="es-section es-ambient es-hero-edito color-scheme-1" style="--pt: 56px; --pb: 104px;" data-hero-edito>
  <div class="es-container es-hero-edito__inner"><p class="es-eyebrow es-hero-edito__eyebrow" data-reveal="up">RECETTE ISOLÉE — CONTENUS FICTIFS</p><h1 class="es-heading es-hero-edito__title" aria-label="Votre café, un geste précis.">
      <span class="es-hero-edito__line" data-reveal="mask" aria-hidden="true">Votre café,</span>
      <span class="es-hero-edito__line es-hero-edito__line--accent" data-reveal="mask" style="--d: 1" aria-hidden="true">un geste précis.</span>
    </h1>
    <div class="es-hero-edito__product" data-float data-parallax="-0.06">
      <img src="{/literal}{$urls.base_url}{literal}themes/esfiltreceramiquerec3cf50238/assets/es/es-recette-mono.webp" alt="Filtre pour cafetière" class="es-hero-edito__img" width="1600" height="1600" loading="eager" decoding="async" fetchpriority="high">
    </div>
    <div class="es-hero-edito__foot"><div class="es-rte es-lead" data-reveal="up" style="--d: 2"><p>Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.</p></div><a href="{/literal}{$urls.base_url}{literal}products/offre-recette" class="es-button" data-reveal="up" style="--d: 3">Voir le produit <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
  </div>
</section>





</div>
<div id="shopify-section-template--es__image_with_text_2" class="shopify-section es-section-wrapper" data-es-section="index:image_with_text_2" data-es-type="image-with-text"><section class="es-section es-iwt es-iwt--image-left color-scheme-1" style="--pt: 104px; --pb: 104px;">
  <div class="es-container es-iwt__grid">
    <div class="es-iwt__media es-media-frame es-media-frame--portrait" data-reveal="zoom" data-scroll-zoom>
      <div class="es-placeholder es-cover" role="img" aria-label="Image à venir">
    <svg class="es-placeholder__svg" viewBox="0 0 525 525" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect width="525" height="525" fill="none"/><path d="M180 330l60-80 50 60 35-40 70 60H180z" fill="currentColor" opacity=".35"/><circle cx="215" cy="215" r="24" fill="currentColor" opacity=".35"/><title>image</title></svg>
  </div>
    </div>
    <div class="es-iwt__content"><p class="es-eyebrow" data-reveal="up">Les informations acquises</p><h2 class="es-heading es-h2" data-reveal="words">Filtre pour cafetière</h2>
      <div class="es-rte" data-reveal="up" style="--d: 1"></div></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__features_grid_1" class="shopify-section es-section-wrapper" data-es-section="index:features_grid_1" data-es-type="features-grid"><section data-layout="grid" data-cols-m="1" class="es-section cv-anim cv-anim--normal es-features es-features--glow es-ambient es-ambient--left color-scheme-2" style="--pt: 104px; --pb: 104px;">
  <div class="es-container">
    <header class="es-section-head es-section-head--left"><h2 class="es-heading es-h2" data-reveal="words">Votre projet</h2></header>
    <div class="es-features__grid" style="--cols: 2; --cols-m: 1; --cols-t: 2" data-reveal-stagger><article class="es-feature es-glow"data-reveal="up" style="--i: 0" data-es-block="feature_1"><span class="es-feature__index">01</span><span class="es-feature__tile"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M8 12V5.5a1.5 1.5 0 0 1 3 0V11m0-5.5a1.5 1.5 0 0 1 3 0V11m0-4a1.5 1.5 0 0 1 3 0v6c0 4-2.5 8-7 8-3 0-4.5-1.5-6-4l-1.5-3a1.5 1.5 0 0 1 2.5-1.5L8 14"/></svg></span><h3 class="es-heading es-h4">Filtre pour cafetière</h3>
          <div class="es-rte es-muted"><p>Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.</p></div></article><article class="es-feature es-glow"data-reveal="up" style="--i: 1" data-es-block="feature_2"><span class="es-feature__index">02</span><span class="es-feature__tile"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Ce qui reste à préciser</h3>
          <div class="es-rte es-muted"><p>Les caractéristiques non confirmées restent à compléter.</p></div></article></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__rich_text_2" class="shopify-section es-section-wrapper" data-es-section="index:rich_text_2" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--reveal color-scheme-1" style="--pt: 120px; --pb: 120px;">
  <div class="es-container es-richtext__inner es-richtext__inner--left"><p class="es-eyebrow" data-reveal="up" data-es-block="eyebrow_3">Votre besoin</p><h2 class="es-heading es-h2" data-scroll-words data-es-block="heading_2">Filtre pour cafetière</h2><div class="es-rte es-lead" data-reveal="up" data-es-block="text_3"><p>Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.</p></div></div>
</section>


</div>
<div id="shopify-section-template--es__scroll_story_2" class="shopify-section es-section-wrapper" data-es-section="index:scroll_story_2" data-es-type="scroll-story"><section class="es-section es-story color-scheme-2" style="--pt: 104px; --pb: 104px;" data-scroll-story>
  <div class="es-container"><h2 class="es-heading es-h2 es-story__heading" data-reveal="words">Partir de votre besoin.</h2><div class="es-story__grid">
      <div class="es-story__visual">
        <div class="es-story__sticky">
          <div class="es-story__stage es-media-frame">
            <img src="{/literal}{$urls.base_url}{literal}themes/esfiltreceramiquerec3cf50238/assets/es/es-recette-mono.webp" alt="Partir de votre besoin." class="es-story__base" width="1600" height="1600" loading="lazy" decoding="async"></div>
          <ol class="es-story__dots" aria-hidden="true"><li data-story-dot="0"></li><li data-story-dot="1"></li></ol>
        </div>
      </div>
      <div class="es-story__steps"><article class="es-story__step" data-story-step="0" data-es-block="step_3">
            <span class="es-story__index">01</span>
            <h3 class="es-heading es-h3">Votre demande</h3>
            <div class="es-rte"><p>Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.</p></div>
          </article><article class="es-story__step" data-story-step="1" data-es-block="step_4">
            <span class="es-story__index">02</span>
            <h3 class="es-heading es-h3">Les détails à préciser</h3>
            <div class="es-rte"><p>Aucune caractéristique ni promesse commerciale supplémentaire ne sera supposée.</p></div>
          </article></div>
    </div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__horizontal_gallery_1" class="shopify-section es-section-wrapper" data-es-section="index:horizontal_gallery_1" data-es-type="horizontal-gallery"><section class="es-section es-hgallery color-scheme-1" style="--pt: 104px; --pb: 104px;" data-hgallery>
  <div class="es-container">
    <header class="es-section-head es-section-head--split">
      <div class="es-hgallery__title"><h2 class="es-heading es-h2" data-reveal="words">Illustration de recette</h2>
      </div>
      <div class="es-hgallery__nav">
        <button type="button" class="es-icon-button es-icon-button--outline" data-hg-prev aria-label="Précédent"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 12H4M10 6l-6 6 6 6"/></svg></button>
        <button type="button" class="es-icon-button es-icon-button--outline" data-hg-next aria-label="Suivant"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></button>
      </div>
    </header>
  </div>
  <div class="es-hgallery__track" data-hg-track tabindex="0" role="region" aria-label="Illustration de recette"></div>
</section>




</div>
<div id="shopify-section-template--es__faq_2" class="shopify-section es-section-wrapper" data-es-section="index:faq_2" data-es-type="faq"><section class="es-section es-faq es-faq--cards es-faq--side es-faq--cols-1 color-scheme-2" style="--pt: 104px; --pb: 104px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Avant de décider</h2></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_2"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="question_3">
          <summary><span class="es-faq__q">Quelles conditions ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Elles sont à confirmer dans le projet.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="question_4">
          <summary><span class="es-faq__q">Quels délais ?</span><span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Ils restent à confirmer.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Quelles conditions ?", "acceptedAnswer": { "@type": "Answer", "text": "Elles sont à confirmer dans le projet." } },{ "@type": "Question", "name": "Quels délais ?", "acceptedAnswer": { "@type": "Answer", "text": "Ils restent à confirmer." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__newsletter_1" class="shopify-section es-section-wrapper" data-es-section="index:newsletter_1" data-es-type="newsletter"><section class="es-section es-newsletter color-scheme-1" style="--pt: 104px; --pb: 104px;">
  <div class="es-container es-newsletter__inner"><h2 class="es-heading es-h2" data-reveal="words">Rester en contact</h2><div class="es-rte es-muted es-newsletter__text" data-reveal="up"><p>Formulaire de recette sans envoi réel.</p></div><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" class="es-newsletter-form" id="NewsletterSection"><input type="hidden" name="form_type" value="customer"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><input type="hidden" name="contact[tags]" value="newsletter">
      <div class="es-inline-field" data-reveal="up">
        <label class="visually-hidden" for="NewsletterEmail-template--es__newsletter_1">Votre adresse e-mail</label>
        <input id="NewsletterEmail-template--es__newsletter_1" type="email" name="contact[email]" required autocomplete="email" placeholder="Votre adresse e-mail">
        <button type="submit" class="es-button">S'inscrire</button>
      </div></form><p class="es-small es-muted es-newsletter__legal">Désinscription possible à tout moment.</p></div>
</section>





</div>{/literal}