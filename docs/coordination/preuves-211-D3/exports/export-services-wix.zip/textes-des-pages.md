## Accueil

### Section : hero-split
- eyebrow : RECETTE ISOLÉE — CONTENUS FICTIFS
- heading : Votre piano, une
- text : Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser.
- button_label : Demander un devis
- button_link : /pages/contact
- image : medias/es-recette-service.webp

### Section : services-list
- eyebrow : Prestations
- heading : Ce que nous faisons pour vous
- button_label : Demander un devis
- button_link : /pages/contact
  - title : Entretien de piano · text : Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser. · icon : sparkle

### Section : how-to
- eyebrow : Notre méthode
- heading : Comment ça se passe
- button_label : Demander un devis
- button_link : /pages/contact
  - title : Décrivez votre projet · text : Quelques lignes suffisent : le besoin, le lieu, vos contraintes.
  - title : Recevez votre devis · text : Une proposition détaillée, établie d'après votre demande.
  - title : Nous réalisons · text : Le travail est réalisé selon ce qui a été convenu ensemble.

### Section : testimonials
- eyebrow : Avis
- heading : Ils nous ont fait confiance
  - quote : [À compléter : avis réel d'un client, avec son accord] · author : [À compléter : prénom] · detail : [À compléter : prestation] · rating : 0
  - quote : [À compléter : avis réel d'un client, avec son accord] · author : [À compléter : prénom] · detail : [À compléter : prestation] · rating : 0
  - quote : [À compléter : avis réel d'un client, avec son accord] · author : [À compléter : prénom] · detail : [À compléter : prestation] · rating : 0

### Section : practical-info
- eyebrow : Infos pratiques
- heading : Nous trouver, nous joindre
- button_label : Demander un devis
- button_link : /pages/contact
- hours : [À compléter : vos horaires, une ligne par jour]
- area : [À compléter : zone d'intervention ou adresse]
- email : recette@example.invalid

### Section : faq
- heading : Avant de décider
  - question : Comment obtenir un devis ? · answer : Décrivez votre projet dans le formulaire de la page Contact ; nous revenons vers vous avec une proposition détaillée.
  - question : Où intervenez-vous ? · answer : [À compléter : votre zone d'intervention ou votre adresse]
  - question : Quels sont vos horaires ? · answer : [À compléter : vos horaires]
  - question : Quels sont vos tarifs ? · answer : [À compléter : vos tarifs, ou la façon dont ils sont établis]
  - question : Comment se déroule une première prestation ? · answer : [À compléter : le déroulement d'une première prestation]

### Section : booking
- eyebrow : Devis
- heading : Demander un devis
- text : Décrivez votre projet : nous revenons vers vous avec une proposition détaillée.
- button_label : Envoyer ma demande
- email : recette@example.invalid
  - title : Décrivez votre projet · text : Quelques lignes suffisent : le besoin, le lieu, vos contraintes.
  - title : Recevez votre devis · text : Une proposition détaillée, établie d'après votre demande.
  - title : Nous réalisons · text : Le travail est réalisé selon ce qui a été convenu ensemble.

### Section : cta-banner
- heading : Parlons de votre besoin.
- button_label : Demander un devis
- button_link : /pages/contact
- image : medias/es-recette-service.webp

## Prestations

### Section : main-page

### Section : services-list
- eyebrow : Prestations
- heading : Nos prestations
- button_label : Demander un devis
- button_link : /pages/contact
  - title : Entretien de piano · text : Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser. · icon : sparkle

### Section : how-to
- eyebrow : Notre méthode
- heading : Comment ça se passe
- button_label : Demander un devis
- button_link : /pages/contact
  - title : Décrivez votre projet · text : Quelques lignes suffisent : le besoin, le lieu, vos contraintes.
  - title : Recevez votre devis · text : Une proposition détaillée, établie d'après votre demande.
  - title : Nous réalisons · text : Le travail est réalisé selon ce qui a été convenu ensemble.

### Section : faq
- heading : Bon à savoir
  - question : Quels sont vos tarifs ? · answer : [À compléter : vos tarifs, ou la façon dont ils sont établis]
  - question : Comment se déroule une première prestation ? · answer : [À compléter : le déroulement d'une première prestation]
  - question : Quels moyens de paiement acceptez-vous ? · answer : [À compléter : les moyens de paiement acceptés]

### Section : cta-banner
- heading : Parlons de votre besoin.
- text : Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser.
- button_label : Demander un devis
- button_link : /pages/contact
- image : medias/es-recette-service.webp

## À propos

### Section : main-page

### Section : about
- eyebrow : À propos
- heading : Votre projet
- lead : Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser.
- button_label : Découvrir nos prestations
- button_link : /pages/prestations
- image : medias/es-recette-service.webp

### Section : team
- eyebrow : L'équipe
- heading : Les personnes qui vous accueillent
  - name : [À compléter : prénom et nom] · role : [À compléter : rôle] · bio : [À compléter : parcours et spécialités réels]
  - name : [À compléter : prénom et nom] · role : [À compléter : rôle] · bio : [À compléter : parcours et spécialités réels]
  - name : [À compléter : prénom et nom] · role : [À compléter : rôle] · bio : [À compléter : parcours et spécialités réels]

### Section : timeline
- eyebrow : Notre méthode
- heading : Comment ça se passe
  - title : Décrivez votre projet · text : Quelques lignes suffisent : le besoin, le lieu, vos contraintes.
  - title : Recevez votre devis · text : Une proposition détaillée, établie d'après votre demande.
  - title : Nous réalisons · text : Le travail est réalisé selon ce qui a été convenu ensemble.

### Section : cta-banner
- heading : Parlons de votre besoin.
- text : Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser.
- button_label : Demander un devis
- button_link : /pages/contact
- image : medias/es-recette-service.webp

## Demande de devis

### Section : main-page

### Section : booking
- eyebrow : Devis
- heading : Demander un devis
- text : Décrivez votre projet : nous revenons vers vous avec une proposition détaillée.
- button_label : Envoyer ma demande
- email : recette@example.invalid
  - title : Décrivez votre projet · text : Quelques lignes suffisent : le besoin, le lieu, vos contraintes.
  - title : Recevez votre devis · text : Une proposition détaillée, établie d'après votre demande.
  - title : Nous réalisons · text : Le travail est réalisé selon ce qui a été convenu ensemble.

### Section : practical-info
- eyebrow : Infos pratiques
- heading : Nous trouver, nous joindre
- hours : [À compléter : vos horaires, une ligne par jour]
- area : [À compléter : zone d'intervention ou adresse]
- email : recette@example.invalid

## Questions fréquentes

### Section : main-page

### Section : faq
- heading : Questions fréquentes
  - question : Comment obtenir un devis ? · answer : Décrivez votre projet dans le formulaire de la page Contact ; nous revenons vers vous avec une proposition détaillée.
  - question : Où intervenez-vous ? · answer : [À compléter : votre zone d'intervention ou votre adresse]
  - question : Quels sont vos horaires ? · answer : [À compléter : vos horaires]
  - question : Quels sont vos tarifs ? · answer : [À compléter : vos tarifs, ou la façon dont ils sont établis]
  - question : Comment se déroule une première prestation ? · answer : [À compléter : le déroulement d'une première prestation]
  - question : Quels moyens de paiement acceptez-vous ? · answer : [À compléter : les moyens de paiement acceptés]
  - question : Quelles conditions ? · answer : Elles sont à confirmer dans le projet.
  - question : Quels délais ? · answer : Ils restent à confirmer.

### Section : contact-form
- heading : Une autre question ?
- text : Entretien de pianos apportés à l’atelier, après examen et devis. Les tarifs et délais restent à préciser.
- email : recette@example.invalid

## Mentions légales

### Section : legal-page
- eyebrow : Informations légales
- heading : Mentions légales
  - title : Éditeur du site · text : Entretien de pianos — RECETTE — [À compléter : forme juridique, adresse du siège, numéro d'immatriculation (SIRET, RCS ou RM)]
  - title : Contact · text : recette@example.invalid
  - title : Directeur de la publication · text : [À compléter : prénom et nom]
  - title : Hébergement · text : [À compléter : nom, adresse et téléphone de l'hébergeur du site]
  - title : Activité réglementée · text : [À compléter : ordre ou chambre professionnelle, assurance, numéro d'inscription — le cas échéant]
  - title : Propriété intellectuelle · text : Les textes, images et logos de ce site appartiennent à Entretien de pianos — RECETTE ou sont utilisés avec l'accord de leurs auteurs. Toute reproduction sans autorisation est interdite.
  - title : Données personnelles · text : Les informations transmises via les formulaires servent uniquement à répondre à votre demande. Voir la politique de confidentialité pour le détail de vos droits.