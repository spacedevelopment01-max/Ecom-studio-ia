# Kit de création Wix — Entretien de pianos — RECETTE

Wix n'accepte pas l'import d'un thème externe : ce kit n'est pas un thème installable.
Il rassemble tout ce qu'il faut pour reproduire fidèlement le site conçu dans le studio, dans l'éditeur de la plateforme.

## Étapes
1. Dans l'éditeur Wix, créez un site vierge (pas de modèle Wix Stores : aucune boutique n'est nécessaire).
2. Thème du site › Couleurs : reportez la palette ci-dessous ; Thème du site › Texte : importez les polices du dossier « polices ».
3. Médias : importez le dossier « medias » dans le gestionnaire de médias.
4. Rendez-vous : ajoutez Wix Bookings, ou un bouton vers votre lien de réservation (Calendly, Planity, Doctolib…).
5. Reconstituez les pages avec « textes-des-pages.md » (accueil, prestations, à propos, contact / rendez-vous, FAQ, mentions légales).
6. Infos pratiques : ajoutez l'élément Google Maps avec votre adresse et un bouton « Appeler » (lien téléphone).

## Palette
- scheme-1 : fond #F9F8F6 · texte #1B2220 · accent #355746 · texte sur accent #FFFFFF
- scheme-2 : fond #F7F5F2 · texte #1B2220 · accent #355746 · texte sur accent #FFFFFF
- scheme-3 : fond #151918 · texte #F4F4F0 · accent #bba76a · texte sur accent #141414
- scheme-4 : fond #DDD7C5 · texte #1B2220 · accent #1B2220 · texte sur accent #FFFFFF

## Typographies
- Titres : Playfair Display
- Texte : Inter


## Catalogue, pages et navigation / Catalog, pages and navigation

`catalogue.json` conserve les axes, combinaisons, SKU, prix, associations d’images, pages et menus. `configuration-studio.json` conserve les réglages et tous les contenus des sections. Ces JSON et le CSV sont des données de reprise : aucun n’est annoncé comme un import natif validé. Reportez les colonnes dans le modèle actuel de la plateforme et affectez les fichiers de `medias/`. Aucune publication automatique.

`catalogue.json` retains axes, combinations, SKUs, prices, image associations, pages and menus. `configuration-studio.json` retains section settings and complete contents. These JSON files and the CSV are rebuild data, not a verified native importer. Map columns to the platform’s current template and assign the files in `medias/`. No automatic publication.
