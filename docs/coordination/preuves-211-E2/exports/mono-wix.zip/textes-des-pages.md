## Accueil

### Section : hero-editorial
- eyebrow : RECETTE ISOLÉE — CONTENUS FICTIFS
- heading_line1 : Votre café,
- heading_line2 : un geste précis.
- text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.
- button_label : Voir le produit
- button_link : /products/offre-recette
- image : medias/es-recette-mono.webp

### Section : image-with-text
- heading : Filtre pour cafetière
- text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.
- image : medias/es-hero-zm9gt7.jpg

### Section : image-with-text
- eyebrow : Les informations acquises
- heading : Filtre pour cafetière

### Section : features-grid
- heading : Votre projet
  - title : Filtre pour cafetière · text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer. · icon : hand
  - title : Ce qui reste à préciser · text : Les caractéristiques non confirmées restent à compléter. · icon : check

### Section : rich-text
  - text : Votre besoin
  - text : Filtre pour cafetière · size : h2
  - text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.

### Section : scroll-story
- heading : Partir de votre besoin.
- image : medias/es-recette-mono.webp
  - title : Votre demande · text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.
  - title : Les détails à préciser · text : Aucune caractéristique ni promesse commerciale supplémentaire ne sera supposée.

### Section : horizontal-gallery
- heading : Illustration de recette

### Section : faq
- heading : Avant de décider
  - question : Quelles conditions ? · answer : Elles sont à confirmer dans le projet.
  - question : Quels délais ? · answer : Ils restent à confirmer.

### Section : newsletter
- heading : Rester en contact
- text : Formulaire de recette sans envoi réel.
- button_label : S'inscrire

## Fiche produit

### Section : main-product
  - text : Filtre céramique — RECETTE
  - 
  - anchor : avis
  - 
  - text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.
  - picker : buttons

### Section : product-reviews
- heading : Avis des clients

### Section : scroll-story
- heading : Partir de votre besoin.
- image : medias/es-recette-mono.webp
  - title : Votre demande · text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.
  - title : Les détails à préciser · text : Aucune caractéristique ni promesse commerciale supplémentaire ne sera supposée.

### Section : specs-list
- heading : Les informations du projet
  - label : Offre · value : Filtre pour cafetière

### Section : faq
- heading : Avant de décider
  - question : Quelles conditions ? · answer : Elles sont à confirmer dans le projet.
  - question : Quels délais ? · answer : Ils restent à confirmer.

### Section : product-recommendations
- heading : Vous aimerez aussi

## Notre histoire

### Section : main-page

### Section : rich-text
  - text : Notre histoire
  - text : Votre projet · size : h1
  - text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.

### Section : image-with-text
- heading : La démarche
- text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.

### Section : cta-banner
- heading : Parlons de votre besoin.
- text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.
- button_label : Préparer ma demande
- button_link : /products/offre-recette
- image : medias/es-recette-mono.webp

## FAQ

### Section : main-page

### Section : faq
- heading : Avant de décider
  - question : Quelles conditions ? · answer : Elles sont à confirmer dans le projet.
  - question : Quels délais ? · answer : Ils restent à confirmer.

### Section : contact-form
- heading : Une autre question ?
- text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.

## Contact

### Section : main-page

### Section : contact-form
- heading : Votre demande
- text : Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.

## Livraison et retours

### Section : main-page

### Section : rich-text
  - text : Conditions · size : h3
  - text : À confirmer.