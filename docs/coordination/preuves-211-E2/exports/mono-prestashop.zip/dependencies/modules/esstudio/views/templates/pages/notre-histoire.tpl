{literal}<div id="shopify-section-template--es__main_page_3" class="shopify-section " data-es-section="page.about:main_page_3" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;"><div class="es-container es-page__inner"><h1 class="es-heading es-h1" data-reveal="lines">Notre histoire</h1><div class="es-rte es-page__content" data-reveal="up"></div>
  </div><script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Filtre céramique — RECETTE", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Notre histoire", "item": "/pages/notre-histoire" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__rich_text_1" class="shopify-section es-section-wrapper" data-es-section="page.about:rich_text_1" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--statement color-scheme-1" style="--pt: 120px; --pb: 64px;">
  <div class="es-container es-richtext__inner es-richtext__inner--center"><p class="es-eyebrow" data-reveal="up" data-es-block="eyebrow_2">Notre histoire</p><h2 class="es-heading es-h1" data-reveal="words" data-es-block="heading_1">Votre projet</h2><div class="es-rte es-lead" data-reveal="up" data-es-block="text_2"><p>Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.</p></div></div>
</section>


</div>
<div id="shopify-section-template--es__image_with_text_1" class="shopify-section es-section-wrapper" data-es-section="page.about:image_with_text_1" data-es-type="image-with-text"><section class="es-section es-iwt es-iwt--image-left color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-iwt__grid">
    <div class="es-iwt__media es-media-frame es-media-frame--portrait" data-reveal="curtain" data-scroll-zoom>
      <div class="es-placeholder es-cover" role="img" aria-label="Image à venir">
    <svg class="es-placeholder__svg" viewBox="0 0 525 525" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect width="525" height="525" fill="none"/><path d="M180 330l60-80 50 60 35-40 70 60H180z" fill="currentColor" opacity=".35"/><circle cx="215" cy="215" r="24" fill="currentColor" opacity=".35"/><title>image</title></svg>
  </div>
    </div>
    <div class="es-iwt__content"><h2 class="es-heading es-h2" data-reveal="words">La démarche</h2>
      <div class="es-rte" data-reveal="up" style="--d: 1"><p>Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.</p></div></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__cta_banner_1" class="shopify-section es-section-wrapper" data-es-section="page.about:cta_banner_1" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-3 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.6;"><div class="es-cta__media" data-parallax="0.2"><img src="{/literal}{$urls.base_url}{literal}themes/esfiltreceramiquerecf6b10e8c/assets/es/es-recette-mono.webp" alt="" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Parlons de votre besoin.</h2><div class="es-rte es-lead" data-reveal="up"><p>Un filtre céramique pour préparer le café. Format, entretien et compatibilité à confirmer.</p></div><a href="{/literal}{$urls.base_url}{literal}products/offre-recette" class="es-button" data-reveal="up" style="--d: 1">Préparer ma demande <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>


</div>{/literal}