{literal}<div id="shopify-section-template--es__announcement_bar_1" class="shopify-section es-announcement-section" data-es-section="group:header:announcement_bar_1" data-es-type="announcement-bar"><div class="es-announcement es-announcement--static color-scheme-3" role="region" aria-label="Annonce"><div class="es-announcement__track" style="--count: 1"><p class="es-announcement__item" data-es-block="announcement_1">RECETTE TECHNIQUE — NON PUBLIÉE</p></div></div>
</div><div id="shopify-section-template--es__header_1" class="shopify-section es-header-section" data-es-section="group:header:header_1" data-es-type="header"><header class="es-header es-header--logo-center es-header--shape-floating es-header--icons-circles es-header--sticky color-scheme-1" data-header>
  <div class="es-header__inner es-container">
    <button class="es-header__burger es-icon-button" type="button" aria-controls="MobileMenu" aria-expanded="false" data-menu-open>
      <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7h18M3 12h18M3 17h18"/></svg><span class="visually-hidden">Menu</span>
    </button>

    <a href="{/literal}{$urls.base_url}{literal}" class="es-header__logo" aria-label="Filtre céramique — RECETTE"><span class="es-header__wordmark">Filtre céramique — RECETTE</span></a>

    <nav class="es-header__nav" aria-label="Navigation principale">
      <ul role="list"><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}" class="es-nav__link"><span>Accueil</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}collections/all" class="es-nav__link"><span>Boutique</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/notre-histoire" class="es-nav__link"><span>Notre histoire</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/faq" class="es-nav__link"><span>FAQ</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-nav__link"><span>Contact</span></a></li></ul>
    </nav>

    <div class="es-header__icons"><a href="{/literal}{$urls.pages.search}{literal}" class="es-icon-button" aria-label="Rechercher"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg></a><a href="{/literal}{$urls.pages.cart}{literal}" class="es-icon-button es-cart-link" data-cart-open aria-label="Panier">
          <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 7h14l-1.2 12.1a1 1 0 0 1-1 .9H7.2a1 1 0 0 1-1-.9L5 7Z"/><path d="M9 7V6a3 3 0 0 1 6 0v1"/></svg>
          <span class="es-cart-count" data-cart-count{/literal}{if $cart.products_count == 0} hidden{/if}{literal}>{/literal}{$cart.products_count}{literal}</span>
        </a></div>
  </div><div class="es-mobile-menu es-mobile-menu--fullscreen es-mobile-menu--sub-accordion color-scheme-1" id="MobileMenu" hidden data-mobile-menu>
    <div class="es-mobile-menu__head">
      <span class="es-header__wordmark">Filtre céramique — RECETTE</span>
      <button type="button" class="es-icon-button" data-menu-close aria-label="Fermer"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 5 14 14M19 5 5 19"/></svg></button>
    </div><ul role="list" class="es-mobile-menu__list"><li style="--i: 1"><a href="{/literal}{$urls.base_url}{literal}" class="es-mm__link"><span>Accueil</span></a></li><li style="--i: 2"><a href="{/literal}{$urls.base_url}{literal}collections/all" class="es-mm__link"><span>Boutique</span></a></li><li style="--i: 3"><a href="{/literal}{$urls.base_url}{literal}pages/notre-histoire" class="es-mm__link"><span>Notre histoire</span></a></li><li style="--i: 4"><a href="{/literal}{$urls.base_url}{literal}pages/faq" class="es-mm__link"><span>FAQ</span></a></li><li style="--i: 5"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-mm__link"><span>Contact</span></a></li></ul><ul class="es-social" role="list"></ul>

  </div>
</header>




</div>{/literal}