{** E-COM STUDIO IA : même mise en page que le reste du site. *}
{extends file='layouts/layout-full-width.tpl'}
