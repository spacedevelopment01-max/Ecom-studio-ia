{literal}<div id="shopify-section-template--es__ed_opening_1" class="shopify-section " data-es-section="index:ed_opening_1" data-es-type="ed-opening">
<section class="ed-section ed-opening ed-opening--immersive color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell">
 <header class="ed-opening__copy"><p class="ed-kicker">Atelier Safran</p>
 <h1 class="ed-title ed-opening__title" data-ed-title>Le thé prend son temps.</h1>
 <div class="ed-prose"><p>Une théière en grès émaillé bleu ardoise, avec une anse arrondie et un couvercle amovible, pour partager le thé autour de la table.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}products/theiere-anse">Découvrir Anse<span aria-hidden="true">↗</span></a></header>
 <div class="ed-opening__media"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esateliersafran450247d1/assets/es/es-client-1c3dt4owl0uibvxj.jpg" alt="La théière Anse au centre de la table" class="ed-image" width="1600" height="1600" loading="eager" decoding="async" fetchpriority="high"></div>
</div>
 
</div></section>

</div>
<div id="shopify-section-template--es__ed_statement_1" class="shopify-section " data-es-section="index:ed_statement_1" data-es-type="ed-statement">
<section class="ed-section ed-statement color-scheme-3" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell ed-statement__grid"><header><p class="ed-kicker">L&#39;objet</p><h2 class="ed-title">Une place au centre de la table.</h2><div class="ed-prose"><p>Atelier Safran dessine des objets pour le temps partagé autour de la table. La théière Anse associe une silhouette arrondie à un émail bleu ardoise.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}products/theiere-anse">Découvrir Théière Anse<span aria-hidden="true">↗</span></a></header><div class="ed-statement__aside"><ul class="ed-points" role="list"><li data-es-block="client_0"><h3>Matière</h3><div class="ed-prose"><p>Grès émaillé</p></div></li><li data-es-block="client_1"><h3>Contenance</h3><div class="ed-prose"><p>700 ml</p></div></li><li data-es-block="client_2"><h3>Finition</h3><div class="ed-prose"><p>Bleu ardoise satiné</p></div></li><li data-es-block="client_3"><h3>Anse</h3><div class="ed-prose"><p>Anse arrondie</p></div></li></ul></div></div></section>

</div>
<div id="shopify-section-template--es__ed_finishes_1" class="shopify-section " data-es-section="index:ed_finishes_1" data-es-type="ed-finishes">
<section class="ed-section ed-finishes ed-finishes--strip color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;" data-ed-finishes>
 <div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker">Finitions</p><h2 class="ed-title">L’anse, le couvercle et l’émail</h2><div class="ed-prose"><p>Découvrez les différentes vues d’Anse : une silhouette arrondie, un émail bleu ardoise et un couvercle amovible.</p></div></header><div class="ed-finishes__grid">
 
 
 </div></div></section>

</div>
<div id="shopify-section-template--es__ed_scene_2" class="shopify-section " data-es-section="index:ed_scene_2" data-es-type="ed-scene">
<section class="ed-section ed-scene ed-scene--split color-scheme-2" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><div class="ed-scene__media"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esateliersafran450247d1/assets/es/es-client-3927kje3jow0nh7z.jpg" alt="La théière Anse au centre de la table" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div><div class="ed-scene__copy"><p class="ed-kicker">En situation</p><h2 class="ed-title">En situation</h2><div class="ed-prose"><p>La théière Anse au centre de la table</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}products/theiere-anse">Découvrir Théière Anse<span aria-hidden="true">↗</span></a></div></div></section>

</div>
<div id="shopify-section-template--es__ed_diptych_1" class="shopify-section " data-es-section="index:ed_diptych_1" data-es-type="ed-diptych">
<section class="ed-section ed-diptych ed-diptych--side color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker">Usages</p><h2 class="ed-title">Anse au fil des moments</h2><div class="ed-prose"></div></header><div class="ed-diptych__grid"><figure class="ed-diptych__frame ed-ratio--portrait" data-es-block="frame_1"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esateliersafran450247d1/assets/es/es-client-dhi25mcz0p2a4zhq.jpg" alt="La théière Anse sur la table, à côté d’une tasse" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
<figcaption><h3>La théière Anse sur la table, à côté d’une tasse</h3><div class="ed-prose"><p>La théière Anse sur la table, à côté d’une tasse</p></div></figcaption></figure><figure class="ed-diptych__frame ed-ratio--portrait" data-es-block="frame_2"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esateliersafran450247d1/assets/es/es-client-eab4hpzk13my8jgc.jpg" alt="La théière Anse sur la table, à côté d’une tasse" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
<figcaption><h3>La théière Anse sur la table, à côté d’une tasse</h3><div class="ed-prose"><p>La théière Anse sur la table, à côté d’une tasse</p></div></figcaption></figure></div></div></section>

</div>
<div id="shopify-section-template--es__v2_faq_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_faq_1" data-es-type="v2-faq"><section class="v2-faq v2-faq--side color-scheme-3" style="--pt: 104px; --pb: 104px;">
  <div class="es-container v2-faq__grid">
    <header class="v2-head v2-faq__head"><h2 class="v2-h2" data-reveal="up">Vos questions</h2></header>
    <div class="v2-faq__list"><details class="v2-faq__item" data-reveal="up" style="--i: 0" data-es-block="client_0">
          <summary><span>Quelle est la contenance ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>La contenance confirmée est de 700 ml.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 1" data-es-block="client_1">
          <summary><span>Comment nettoyer Anse ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Laver à la main avec une éponge douce.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 2" data-es-block="client_2">
          <summary><span>Le couvercle est-il amovible ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Oui, le couvercle est amovible.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 3" data-es-block="client_3">
          <summary><span>Quelle finition est présentée ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>La finition présentée est bleu ardoise satiné.</p></div>
        </details></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__cta_banner_2" class="shopify-section es-section-wrapper" data-es-section="index:cta_banner_2" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-4 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.6;"><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Le thé prend son temps.</h2><div class="es-rte es-lead" data-reveal="up"><p>Une théière en grès émaillé bleu ardoise, avec une anse arrondie et un couvercle amovible, pour partager le thé autour de la table.</p></div><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-button" data-reveal="up" style="--d: 1">Découvrir Anse <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>





</div>{/literal}