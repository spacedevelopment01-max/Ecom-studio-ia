{literal}<div id="shopify-section-template--es__footer_1" class="shopify-section es-footer-section" data-es-section="group:footer:footer_1" data-es-type="footer"><footer class="es-footer es-footer--minimal es-ambient color-scheme-3">
  <div class="es-container"><div class="es-footer__inline">
        <a href="{/literal}{$urls.base_url}{literal}" class="es-footer__brand">Atelier Safran</a>
        <ul role="list" class="es-footer__inline-links"><li><a href="{/literal}{$urls.base_url}{literal}">Accueil</a></li><li><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse">Théière Anse</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/notre-histoire">Notre histoire</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/faq">Questions fréquentes</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/contact">Questions et contact</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/livraison-et-retours">Livraison et retours</a></li></ul>
        <ul class="es-social" role="list"></ul>

      </div><div class="es-footer__bottom">
      <p>&copy; 2026 Atelier Safran</p><ul role="list" class="es-footer__policies"><li><a href="{/literal}{$urls.base_url}{literal}policies/terms-of-service">Conditions générales de vente</a></li><li><a href="{/literal}{$urls.base_url}{literal}policies/privacy-policy">Politique de confidentialité</a></li><li><a href="{/literal}{$urls.base_url}{literal}policies/refund-policy">Politique de remboursement</a></li><li><a href="{/literal}{$urls.base_url}{literal}policies/legal-notice">Mentions légales</a></li></ul><ul class="es-footer__payment" role="list"></ul></div>
  </div>
</footer>




</div><div class="es-fab" data-fab><a href="#MainContent" class="es-fab__button es-fab__button--top" data-back-to-top aria-label="Revenir en haut de la page"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20V4M6 10l6-6 6 6"/></svg></a><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-fab__button es-fab__button--contact" aria-label="Nous contacter"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg></a></div>{/literal}