{literal}<div id="shopify-section-template--es__main_page_2" class="shopify-section " data-es-section="page.shipping:main_page_2" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--narrow" style="--pt: 64px; --pb: 96px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Livraison et retours</h1>
    <div class="es-rte es-page__content" data-reveal="up"><p>Les conditions détaillées figurent ci-dessous.</p></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Atelier Safran", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Livraison et retours", "item": "/pages/livraison-et-retours" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__rich_text_2" class="shopify-section es-section-wrapper" data-es-section="page.shipping:rich_text_2" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--plain color-scheme-2" style="--pt: 64px; --pb: 64px;">
  <div class="es-container es-richtext__inner es-richtext__inner--left"><h2 class="es-heading es-h2" data-reveal="words" data-es-block="client_0">Une place au centre de la table.</h2><div class="es-rte es-lead" data-reveal="up" data-es-block="client_1"><p>Atelier Safran dessine des objets pour le temps partagé autour de la table. La théière Anse associe une silhouette arrondie à un émail bleu ardoise.</p></div></div>
</section>


</div>{/literal}