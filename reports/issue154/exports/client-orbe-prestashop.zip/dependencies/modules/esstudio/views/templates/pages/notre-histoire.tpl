{literal}<div id="shopify-section-template--es__main_page_3" class="shopify-section " data-es-section="page.about:main_page_3" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Notre histoire</h1>
    <div class="es-rte es-page__content" data-reveal="up"></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Atelier Safran", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Notre histoire", "item": "/pages/notre-histoire" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__rich_text_1" class="shopify-section es-section-wrapper" data-es-section="page.about:rich_text_1" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--statement color-scheme-1" style="--pt: 120px; --pb: 64px;">
  <div class="es-container es-richtext__inner es-richtext__inner--center"><h2 class="es-heading es-h2" data-reveal="words" data-es-block="client_0">Atelier Safran</h2><div class="es-rte es-lead" data-reveal="up" data-es-block="client_1"><p>Atelier Safran dessine des objets pour le temps partagé autour de la table. La théière Anse associe une silhouette arrondie à un émail bleu ardoise.</p></div></div>
</section>


</div>
<div id="shopify-section-template--es__image_with_text_1" class="shopify-section es-section-wrapper" data-es-section="page.about:image_with_text_1" data-es-type="image-with-text"><section class="es-section es-iwt es-iwt--image-left color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-iwt__grid">
    <div class="es-iwt__media es-media-frame es-media-frame--portrait" data-reveal="curtain" data-scroll-zoom>
      <img src="{/literal}{$urls.base_url}{literal}themes/esateliersafran450247d1/assets/es/es-client-3927kje3jow0nh7z.jpg" alt="Une silhouette accueillante" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async">
    </div>
    <div class="es-iwt__content"><p class="es-eyebrow" data-reveal="up">Atelier Safran</p><h2 class="es-heading es-h2" data-reveal="words">Une silhouette accueillante</h2>
      <div class="es-rte" data-reveal="up" style="--d: 1"><p>L’anse arrondie et le couvercle composent un volume simple à retrouver sur la table.</p></div><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-button es-button--secondary" data-reveal="up" style="--d: 2">Découvrir Théière Anse</a></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__features_grid_1" class="shopify-section es-section-wrapper" data-es-section="page.about:features_grid_1" data-es-type="features-grid"><section data-layout="grid" data-cols-m="1" class="es-section cv-anim cv-anim--normal es-features es-features--glow es-ambient es-ambient--left color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container">
    <header class="es-section-head es-section-head--left"><p class="es-eyebrow"data-reveal="up">Atelier Safran</p><h2 class="es-heading es-h2" data-reveal="words">L’anse, le couvercle et l’émail <em>en un coup d'œil.</em></h2><a class="es-link-arrow" href="{/literal}{$urls.base_url}{literal}collections/all"data-reveal="up">Découvrir Théière Anse <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></header>
    <div class="es-features__grid" style="--cols: 2; --cols-m: 1; --cols-t: 2" data-reveal-stagger><article class="es-feature es-glow"data-reveal="up" style="--i: 0" data-es-block="client_0"><span class="es-feature__index">01</span><span class="es-feature__tile"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Une silhouette accueillante</h3>
          <div class="es-rte es-muted"><p>L’anse arrondie et le couvercle composent un volume simple à retrouver sur la table.</p></div></article><article class="es-feature es-glow"data-reveal="up" style="--i: 1" data-es-block="client_1"><span class="es-feature__index">02</span><span class="es-feature__tile"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Le sens du détail</h3>
          <div class="es-rte es-muted"><p>L’émail bleu ardoise et la forme de l’anse sont présentés dans les vues détaillées.</p></div></article><article class="es-feature es-glow"data-reveal="up" style="--i: 2" data-es-block="client_2"><span class="es-feature__index">03</span><span class="es-feature__tile"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">700 ml</h3>
          <div class="es-rte es-muted"><p>La contenance confirmée de la théière.</p></div></article></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__cta_banner_1" class="shopify-section es-section-wrapper" data-es-section="page.about:cta_banner_1" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-3 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.6;"><div class="es-cta__media" data-parallax="0.2"><img src="{/literal}{$urls.base_url}{literal}themes/esateliersafran450247d1/assets/es/es-client-1c3dt4owl0uibvxj.jpg" alt="" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Théière Anse</h2><div class="es-rte es-lead" data-reveal="up"><p>Une théière en grès émaillé bleu ardoise, avec une anse arrondie et un couvercle amovible, pour partager le thé autour de la table.</p></div><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-button" data-reveal="up" style="--d: 1">Découvrir Anse <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>





</div>{/literal}