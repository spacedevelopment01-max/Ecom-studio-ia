{literal}<div id="shopify-section-template--es__main_page_5" class="shopify-section " data-es-section="page.contact:main_page_5" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Questions et contact</h1>
    <div class="es-rte es-page__content" data-reveal="up"></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Atelier Safran", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Questions et contact", "item": "/pages/contact" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__contact_form_2" class="shopify-section " data-es-section="page.contact:contact_form_2" data-es-type="contact-form"><section class="es-section es-contact color-scheme-1" style="--pt: 64px; --pb: 120px;">
  <div class="es-container es-contact__grid">
    <header class="es-contact__intro"><p class="es-eyebrow" data-reveal="up">Contact</p><h2 class="es-heading es-h2" data-reveal="words">Parlons de votre projet</h2><div class="es-rte es-contact__text" data-reveal="up"><p>Écrivez à Atelier Safran pour toute question sur Anse.</p></div></header><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="ContactForm" class="es-form es-contact__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><div class="es-form__row">
        <label>Nom<input type="text" name="contact[name]" autocomplete="name" value=""></label>
        <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label>
      </div>
      <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
      <label>Message<textarea name="contact[body]" rows="6" class="es-textarea"></textarea></label>
      <button type="submit" class="es-button">Envoyer</button></form></div>
</section>





</div>{/literal}