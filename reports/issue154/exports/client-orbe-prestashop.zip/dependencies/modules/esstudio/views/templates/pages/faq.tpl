{literal}<div id="shopify-section-template--es__main_page_4" class="shopify-section " data-es-section="page.faq:main_page_4" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Questions fréquentes</h1>
    <div class="es-rte es-page__content" data-reveal="up"></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Atelier Safran", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Questions fréquentes", "item": "/pages/faq" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__faq_2" class="shopify-section es-section-wrapper" data-es-section="page.faq:faq_2" data-es-type="faq"><section class="es-section es-faq es-faq--cards es-faq--side es-faq--cols-1 color-scheme-1" style="--pt: 96px; --pb: 96px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><p class="es-eyebrow" data-reveal="up">Besoin d'aide ?</p><h2 class="es-heading es-h2" data-reveal="words">Vos questions</h2><div class="es-faq__contact" data-reveal="up"><p class="es-faq__contact-text">Une autre question ?</p><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-button es-button--secondary es-button--small">Découvrir Théière Anse <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a>
        </div></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_2"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="client_0">
          <summary><span class="es-faq__q">Quelle est la contenance ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>La contenance confirmée est de 700 ml.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="client_1">
          <summary><span class="es-faq__q">Comment nettoyer Anse ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Laver à la main avec une éponge douce.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="client_2">
          <summary><span class="es-faq__q">Le couvercle est-il amovible ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Oui, le couvercle est amovible.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 3" data-faq-item data-es-block="client_3">
          <summary><span class="es-faq__q">Quelle finition est présentée ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>La finition présentée est bleu ardoise satiné.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Quelle est la contenance ?", "acceptedAnswer": { "@type": "Answer", "text": "La contenance confirmée est de 700 ml." } },{ "@type": "Question", "name": "Comment nettoyer Anse ?", "acceptedAnswer": { "@type": "Answer", "text": "Laver à la main avec une éponge douce." } },{ "@type": "Question", "name": "Le couvercle est-il amovible ?", "acceptedAnswer": { "@type": "Answer", "text": "Oui, le couvercle est amovible." } },{ "@type": "Question", "name": "Quelle finition est présentée ?", "acceptedAnswer": { "@type": "Answer", "text": "La finition présentée est bleu ardoise satiné." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__contact_form_1" class="shopify-section " data-es-section="page.faq:contact_form_1" data-es-type="contact-form"><section class="es-section es-contact color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-contact__grid">
    <header class="es-contact__intro"><p class="es-eyebrow" data-reveal="up">Contact</p><h2 class="es-heading es-h2" data-reveal="words">Parlons de votre projet</h2><div class="es-rte es-contact__text" data-reveal="up"><p>Écrivez à Atelier Safran pour toute question sur Anse.</p></div></header><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="ContactForm" class="es-form es-contact__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><div class="es-form__row">
        <label>Nom<input type="text" name="contact[name]" autocomplete="name" value=""></label>
        <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label>
      </div>
      <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
      <label>Message<textarea name="contact[body]" rows="6" class="es-textarea"></textarea></label>
      <button type="submit" class="es-button">Envoyer</button></form></div>
</section>





</div>{/literal}