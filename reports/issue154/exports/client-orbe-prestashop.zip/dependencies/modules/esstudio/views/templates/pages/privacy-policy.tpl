{literal}<div id="shopify-section-template--es__main_page_1" class="shopify-section " data-es-section="page:main_page_1" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--narrow" style="--pt: 64px; --pb: 96px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Politique de confidentialité</h1>
    <div class="es-rte es-page__content" data-reveal="up"><p>[À compléter dans le thème : fichier de cette page (module esstudio) ou nouvelle exportation]</p></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Atelier Safran", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Politique de confidentialité", "item": "" }
      ]
    }
  </script>
</section>


</div>{/literal}