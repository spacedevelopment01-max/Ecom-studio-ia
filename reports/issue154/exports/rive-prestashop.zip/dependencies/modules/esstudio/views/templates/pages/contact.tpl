{literal}<div id="shopify-section-template--es__main_page_5" class="shopify-section " data-es-section="page.contact:main_page_5" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Questions et contact</h1>
    <div class="es-rte es-page__content" data-reveal="up"></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Terre & Geste", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Questions et contact", "item": "/pages/contact" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__booking_1" class="shopify-section es-section-wrapper" data-es-section="page.contact:booking_1" data-es-type="booking"><section class="es-section es-booking es-booking--form color-scheme-1" style="--pt: 96px; --pb: 96px; --embed-h: 700px;">
  <div class="es-container es-booking__grid">
    <div class="es-booking__intro"><h2 class="es-heading es-h2" data-reveal="words">Parlons de votre projet</h2><div class="es-rte es-lead" data-reveal="up"><p>Écrivez à l’atelier pour préparer votre rendez-vous.</p></div><ol class="es-booking__steps" role="list" data-reveal="up" style="--d: 1"><li data-es-block="client_0"><span class="es-booking__step-num" aria-hidden="true">1</span><span><strong>Réservez votre créneau</strong><span class="es-booking__step-text">Indiquez la prestation et le moment qui vous conviennent.</span></span></li><li data-es-block="client_1"><span class="es-booking__step-num" aria-hidden="true">2</span><span><strong>Faisons connaissance</strong><span class="es-booking__step-text">Nous prenons le temps de comprendre votre besoin avant de commencer.</span></span></li><li data-es-block="client_2"><span class="es-booking__step-num" aria-hidden="true">3</span><span><strong>Votre rendez-vous</strong><span class="es-booking__step-text">La prestation choisie, réalisée avec soin.</span></span></li></ol><ul class="es-booking__direct" role="list" data-reveal="up" style="--d: 2"><li><a href="mailto:atelier@example.test" class="es-booking__chip"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><span>atelier@example.test</span></a></li></ul></div>

    <div class="es-booking__panel es-glow is-lit" data-reveal="up" style="--d: 1"><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="BookingForm-template--es__booking_1" class="es-form es-booking__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><input type="hidden" name="contact[Demande]" value="Parlons de votre projet">
            <div class="es-form__row">
              <label>Nom *<input type="text" name="contact[name]" autocomplete="name" required value=""></label>
              <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
            </div>
            <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label><label>Prestation souhaitée
                <select name="contact[Prestation souhaitée]">
                  <option value="">Choisir une prestation</option><option value="Atelier de tournage individuel">Atelier de tournage individuel</option><option value="Découverte des émaux">Découverte des émaux</option></select>
              </label><label>Message<textarea name="contact[body]" rows="4" class="es-textarea"></textarea></label>
            <button type="submit" class="es-button es-button--full">Prendre rendez-vous</button></form></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__practical_info_2" class="shopify-section es-section-wrapper" data-es-section="page.contact:practical_info_2" data-es-type="practical-info"><section class="es-section es-info color-scheme-2" style="--pt: 104px; --pb: 104px;">
  <div class="es-container">
    <header class="es-info__head"><h2 class="es-heading es-h2" data-reveal="words">Parlons de votre projet</h2><div class="es-rte es-lead" data-reveal="up"><p>Écrivez à l’atelier pour préparer votre rendez-vous.</p></div></header>

    <div class="es-info__grid">
      <div class="es-info__cards"><div class="es-info__card es-info__card--hours" data-reveal="up">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Horaires</h3>
            <dl class="es-info__hours"><div class="es-info__row"><dt>Sur rendez-vous</dt><dd></dd></div></dl></div><div class="es-info__card" data-reveal="up" style="--d: 1">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>Adresse</h3><p class="es-info__area"><span class="es-info__label">Zone d'intervention</span>Quartier des Ateliers, Lyon — exemple fictif</p></div><div class="es-info__card es-info__card--contact" data-reveal="up" style="--d: 2">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg>Nous joindre</h3><a class="es-info__email" href="mailto:atelier@example.test"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><span>atelier@example.test</span></a><a class="es-button es-button--full es-info__cta" href="{/literal}{$urls.base_url}{literal}pages/contact">Prendre rendez-vous</a></div></div></div>
  </div>
</section>






</div>{/literal}