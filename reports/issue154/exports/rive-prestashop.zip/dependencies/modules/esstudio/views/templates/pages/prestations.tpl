{literal}<div id="shopify-section-template--es__main_page_6" class="shopify-section " data-es-section="page.services:main_page_6" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Nos prestations</h1>
    <div class="es-rte es-page__content" data-reveal="up"></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Terre & Geste", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Nos prestations", "item": "/pages/prestations" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__services_list_2" class="shopify-section es-section-wrapper" data-es-section="page.services:services_list_2" data-es-type="services-list"><section class="es-section es-svc es-svc--list color-scheme-1" style="--pt: 104px; --pb: 104px; --cols: 2;">
  <div class="es-container"><header class="es-svc__head es-svc__head--split">
        <div><h2 class="es-heading es-h2" data-reveal="words">Approcher la terre et le tour</h2></div><div class="es-rte es-lead es-svc__intro" data-reveal="up"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div></header><ul class="es-svc__list" role="list"><li class="es-svc__item es-glow" data-reveal="up" style="--i: 0" data-es-block="client_0"><div class="es-svc__body">
            <div class="es-svc__top"><span class="es-svc__num" aria-hidden="true">01</span></div>
            <h3 class="es-heading es-h4 es-svc__title">Atelier de tournage individuel</h3><div class="es-rte es-svc__text"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div><p class="es-svc__meta"><span class="es-svc__price">75 €</span><span class="es-svc__duration"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>1 h 30</span></p></div><div class="es-svc__action">
              <a class="es-link-arrow es-svc__link" href="{/literal}{$urls.base_url}{literal}pages/contact">
                <span>Prendre rendez-vous</span><span class="visually-hidden"> — Atelier de tournage individuel</span><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>
              </a>
            </div></li><li class="es-svc__item es-glow" data-reveal="up" style="--i: 1" data-es-block="client_1"><div class="es-svc__body">
            <div class="es-svc__top"><span class="es-svc__num" aria-hidden="true">02</span></div>
            <h3 class="es-heading es-h4 es-svc__title">Découverte des émaux</h3><div class="es-rte es-svc__text"><p>Choisir une palette et découvrir l’application des émaux sur une pièce préparée.</p></div><p class="es-svc__meta"><span class="es-svc__price">45 €</span><span class="es-svc__duration"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>1 h</span></p></div><div class="es-svc__action">
              <a class="es-link-arrow es-svc__link" href="{/literal}{$urls.base_url}{literal}pages/contact">
                <span>Prendre rendez-vous</span><span class="visually-hidden"> — Découverte des émaux</span><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>
              </a>
            </div></li></ul></div>
</section>




</div>
<div id="shopify-section-template--es__how_to_1" class="shopify-section es-section-wrapper" data-es-section="page.services:how_to_1" data-es-type="how-to"><section class="es-section es-howto es-howto--horizontal es-howto--landscape color-scheme-1" style="--pt: 104px; --pb: 104px; --n: 3;" data-howto>
  <div class="es-container">
    <header class="es-howto__head"><p class="es-eyebrow" data-reveal="up">Notre méthode</p><h2 class="es-heading es-h2" data-reveal="words">Le déroulé de votre atelier</h2></header>
    <ol class="es-howto__list" role="list" data-howto-list>
      <li class="es-howto__rail" aria-hidden="true"><span class="es-howto__fill"></span></li><li class="es-howto__step is-lit" data-howto-step style="--i: 0" data-es-block="client_0">
          <span class="es-howto__node" aria-hidden="true"><span>01</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 1</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Préparer la terre</h3><div class="es-rte"><p>La séance commence par la préparation de la terre.</p></div></div>
        </li><li class="es-howto__step" data-howto-step style="--i: 1" data-es-block="client_1">
          <span class="es-howto__node" aria-hidden="true"><span>02</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 2</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Centrer sur le tour</h3><div class="es-rte"><p>Le centrage se travaille avec l’accompagnement de l’atelier.</p></div></div>
        </li><li class="es-howto__step" data-howto-step style="--i: 2" data-es-block="client_2">
          <span class="es-howto__node" aria-hidden="true"><span>03</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 3</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Travailler la forme</h3><div class="es-rte"><p>La forme est travaillée progressivement sur le tour.</p></div></div>
        </li></ol><div class="es-actions es-actions--center"><a class="es-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Prendre rendez-vous</a></div></div>
</section>






</div>
<div id="shopify-section-template--es__faq_4" class="shopify-section es-section-wrapper" data-es-section="page.services:faq_4" data-es-type="faq"><section class="es-section es-faq es-faq--lines es-faq--side es-faq--cols-1 color-scheme-2" style="--pt: 96px; --pb: 96px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Vos questions</h2><div class="es-faq__contact" data-reveal="up"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button es-button--secondary es-button--small">Prendre rendez-vous <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a>
        </div></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_4"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="client_0">
          <summary><span class="es-faq__q">Comment réserver ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Choisissez un créneau par la prise de rendez-vous.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="client_1">
          <summary><span class="es-faq__q">Quelle est la durée ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>L’atelier de tournage individuel dure 1 h 30.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="client_2">
          <summary><span class="es-faq__q">Quel est le tarif ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>L’atelier individuel est proposé à 75 € dans ce projet fictif.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Comment réserver ?", "acceptedAnswer": { "@type": "Answer", "text": "Choisissez un créneau par la prise de rendez-vous." } },{ "@type": "Question", "name": "Quelle est la durée ?", "acceptedAnswer": { "@type": "Answer", "text": "L’atelier de tournage individuel dure 1 h 30." } },{ "@type": "Question", "name": "Quel est le tarif ?", "acceptedAnswer": { "@type": "Answer", "text": "L’atelier individuel est proposé à 75 € dans ce projet fictif." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__cta_banner_2" class="shopify-section es-section-wrapper" data-es-section="page.services:cta_banner_2" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-3 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.6;"><div class="es-cta__media" data-parallax="0.2"><img src="{/literal}{$urls.base_url}{literal}themes/esterregestecfab67cd/assets/es/es-client-udcuwg40py4d0phg.jpg" alt="" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Terre & Geste</h2><div class="es-rte es-lead" data-reveal="up"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button" data-reveal="up" style="--d: 1">Prendre rendez-vous <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>





</div>{/literal}