{literal}<div id="shopify-section-template--es__ed_opening_1" class="shopify-section " data-es-section="index:ed_opening_1" data-es-type="ed-opening">
<section class="ed-section ed-opening ed-opening--journal color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell">
 <header class="ed-opening__copy"><p class="ed-kicker">Terre &amp; Geste</p>
 <h1 class="ed-title ed-opening__title" data-ed-title>De la terre au geste juste.</h1>
 <div class="ed-prose"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Prendre rendez-vous<span aria-hidden="true">↗</span></a></header>
 <div class="ed-opening__media"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esterregestecfab67cd/assets/es/es-client-udcuwg40py4d0phg.jpg" alt="Le tour avant la séance individuelle" class="ed-image" width="1600" height="1600" loading="eager" decoding="async" fetchpriority="high"></div>
</div>
 
</div></section>

</div>
<div id="shopify-section-template--es__ed_statement_1" class="shopify-section " data-es-section="index:ed_statement_1" data-es-type="ed-statement">
<section class="ed-section ed-statement color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell ed-statement__grid"><header><p class="ed-kicker">L&#39;objet</p><h2 class="ed-title">Un atelier, un geste à la fois.</h2><div class="ed-prose"><p>L’atelier accompagne chaque étape du tournage, de la préparation de la terre à la forme qui prend place sur le tour.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Prendre rendez-vous<span aria-hidden="true">↗</span></a></header><div class="ed-statement__aside"><ul class="ed-points" role="list"><li data-es-block="client_0"><h3>Un accompagnement individuel</h3><div class="ed-prose"><p>Chaque atelier reçoit une seule personne, sur rendez-vous.</p></div></li><li data-es-block="client_1"><h3>Le sens du détail</h3><div class="ed-prose"><p>La préparation, le centrage et le geste se travaillent dans cet ordre.</p></div></li></ul></div></div></section>

</div>
<div id="shopify-section-template--es__ref_narrative_1" class="shopify-section reference-section" data-es-section="index:ref_narrative_1" data-es-type="ref-narrative"><section class="ref-section ref-narrative color-scheme-1" style="--ref-pt:96px;--ref-pb:96px" data-narrative data-motion="reveal">
 <div class="ref-shell"><div class="ref-section-head"><h2 class="ref-heading">Le déroulé de votre atelier</h2></div>
  <div class="ref-narrative__grid">
   <div class="ref-narrative__chapters">
    <details class="ref-narrative__chapter" open data-es-block="client_0" data-narrative-chapter="0">
     <summary><span>Préparer la terre</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>La séance commence par la préparation de la terre.</p></div>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="client_1" data-narrative-chapter="1">
     <summary><span>Centrer sur le tour</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Le centrage se travaille avec l’accompagnement de l’atelier.</p></div>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="client_2" data-narrative-chapter="2">
     <summary><span>Travailler la forme</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>La forme est travaillée progressivement sur le tour.</p></div>
    </details>
   </div>
   <div class="ref-narrative__visuals"></div>
  </div>
 </div>
</section>

</div>
<div id="shopify-section-template--es__services_list_1" class="shopify-section es-section-wrapper" data-es-section="index:services_list_1" data-es-type="services-list"><section class="es-section es-svc es-svc--list color-scheme-3" style="--pt: 104px; --pb: 104px; --cols: 2;">
  <div class="es-container"><header class="es-svc__head es-svc__head--split">
        <div><h2 class="es-heading es-h2" data-reveal="words">Approcher la terre et le tour</h2></div><div class="es-rte es-lead es-svc__intro" data-reveal="up"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div></header><ul class="es-svc__list" role="list"><li class="es-svc__item es-glow" data-reveal="up" style="--i: 0" data-es-block="client_0"><div class="es-svc__body">
            <div class="es-svc__top"><span class="es-svc__num" aria-hidden="true">01</span></div>
            <h3 class="es-heading es-h4 es-svc__title">Atelier de tournage individuel</h3><div class="es-rte es-svc__text"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div><p class="es-svc__meta"><span class="es-svc__price">75 €</span><span class="es-svc__duration"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>1 h 30</span></p></div><div class="es-svc__action">
              <a class="es-link-arrow es-svc__link" href="{/literal}{$urls.base_url}{literal}pages/contact">
                <span>Prendre rendez-vous</span><span class="visually-hidden"> — Atelier de tournage individuel</span><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>
              </a>
            </div></li><li class="es-svc__item es-glow" data-reveal="up" style="--i: 1" data-es-block="client_1"><div class="es-svc__body">
            <div class="es-svc__top"><span class="es-svc__num" aria-hidden="true">02</span></div>
            <h3 class="es-heading es-h4 es-svc__title">Découverte des émaux</h3><div class="es-rte es-svc__text"><p>Choisir une palette et découvrir l’application des émaux sur une pièce préparée.</p></div><p class="es-svc__meta"><span class="es-svc__price">45 €</span><span class="es-svc__duration"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>1 h</span></p></div><div class="es-svc__action">
              <a class="es-link-arrow es-svc__link" href="{/literal}{$urls.base_url}{literal}pages/contact">
                <span>Prendre rendez-vous</span><span class="visually-hidden"> — Découverte des émaux</span><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>
              </a>
            </div></li></ul></div>
</section>




</div>
<div id="shopify-section-template--es__timeline_1" class="shopify-section es-section-wrapper" data-es-section="index:timeline_1" data-es-type="timeline"><section class="es-section es-timeline color-scheme-1" style="--pt: 104px; --pb: 104px;">
  <div class="es-container es-timeline__inner"><p class="es-eyebrow es-timeline__eyebrow" data-reveal="up">Notre méthode</p><h2 class="es-heading es-h2 es-timeline__heading" data-reveal="words">Le déroulé de votre atelier</h2><div class="es-timeline__media es-media-frame" data-scroll-zoom data-reveal="zoom"><img src="{/literal}{$urls.base_url}{literal}themes/esterregestecfab67cd/assets/es/es-client-0qtryyui6yerpga1.jpg" alt="Le déroulé de votre atelier" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><ol class="es-timeline__list" data-timeline>
      <span class="es-timeline__line" aria-hidden="true"><span class="es-timeline__fill"></span></span><li class="es-timeline__step" data-timeline-step data-es-block="client_0">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">01</span>
          <h3 class="es-heading es-h3">Préparer la terre</h3>
          <div class="es-rte"><p>La séance commence par la préparation de la terre.</p></div>
        </li><li class="es-timeline__step" data-timeline-step data-es-block="client_1">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">02</span>
          <h3 class="es-heading es-h3">Centrer sur le tour</h3>
          <div class="es-rte"><p>Le centrage se travaille avec l’accompagnement de l’atelier.</p></div>
        </li><li class="es-timeline__step" data-timeline-step data-es-block="client_2">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">03</span>
          <h3 class="es-heading es-h3">Travailler la forme</h3>
          <div class="es-rte"><p>La forme est travaillée progressivement sur le tour.</p></div>
        </li></ol>
  </div>
</section>




</div>
<div id="shopify-section-template--es__portfolio_1" class="shopify-section es-section-wrapper" data-es-section="index:portfolio_1" data-es-type="portfolio"><section class="es-section es-folio es-folio--editorial color-scheme-1" style="--pt: 104px; --pb: 104px;" data-folio>
  <div class="es-container">
    <header class="es-folio__head">
      <div><h2 class="es-heading es-h2" data-reveal="words">Approcher la terre et le tour</h2><div class="es-rte es-lead" data-reveal="up"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div></div></header>

    <ul class="es-folio__grid" role="list"><li class="es-folio__item" data-reveal="up" style="--i: 0" data-folio-tag="" data-es-block="project_1">
          <figure class="es-folio__figure">
            <div class="es-folio__media">
              <img src="{/literal}{$urls.base_url}{literal}themes/esterregestecfab67cd/assets/es/es-client-lcru0hpellde6ubh.jpg" alt="Le tour avant la séance individuelle" class="es-cover es-folio__after" width="1600" height="1600" loading="lazy" decoding="async"></div>
            <figcaption class="es-folio__caption"><span class="es-heading es-h4 es-folio__title">Le tour avant la séance individuelle</span><span class="es-folio__text">Le tour avant la séance individuelle</span></figcaption>
          </figure>
        </li><li class="es-folio__item" data-reveal="up" style="--i: 1" data-folio-tag="" data-es-block="project_2">
          <figure class="es-folio__figure">
            <div class="es-folio__media">
              <img src="{/literal}{$urls.base_url}{literal}themes/esterregestecfab67cd/assets/es/es-client-tsxxyvius5lj5015.jpg" alt="Le tour et la terre dans l’atelier" class="es-cover es-folio__after" width="1600" height="1600" loading="lazy" decoding="async"></div>
            <figcaption class="es-folio__caption"><span class="es-heading es-h4 es-folio__title">Le tour et la terre dans l’atelier</span><span class="es-folio__text">Le tour et la terre dans l’atelier</span></figcaption>
          </figure>
        </li><li class="es-folio__item" data-reveal="up" style="--i: 2" data-folio-tag="" data-es-block="project_3">
          <figure class="es-folio__figure">
            <div class="es-folio__media">
              <img src="{/literal}{$urls.base_url}{literal}themes/esterregestecfab67cd/assets/es/es-client-vvohgnm2je02hf2b.jpg" alt="Vue fournie de l’atelier et de son matériel, scène 12 — recette fictive" class="es-cover es-folio__after" width="1600" height="1600" loading="lazy" decoding="async"></div>
            <figcaption class="es-folio__caption"><span class="es-heading es-h4 es-folio__title">Vue fournie de l’atelier et de son matériel, scène 12 — recette fictive</span><span class="es-folio__text">Vue fournie de l’atelier et de son matériel, scène 12 — recette fictive</span></figcaption>
          </figure>
        </li><li class="es-folio__item" data-reveal="up" style="--i: 0" data-folio-tag="" data-es-block="project_4">
          <figure class="es-folio__figure">
            <div class="es-folio__media">
              <img src="{/literal}{$urls.base_url}{literal}themes/esterregestecfab67cd/assets/es/es-client-ya5p2hzol8foeyda.jpg" alt="Vue fournie de l’atelier et de son matériel, scène 13 — recette fictive" class="es-cover es-folio__after" width="1600" height="1600" loading="lazy" decoding="async"></div>
            <figcaption class="es-folio__caption"><span class="es-heading es-h4 es-folio__title">Vue fournie de l’atelier et de son matériel, scène 13 — recette fictive</span><span class="es-folio__text">Vue fournie de l’atelier et de son matériel, scène 13 — recette fictive</span></figcaption>
          </figure>
        </li></ul><div class="es-actions es-actions--center"><a class="es-button es-button--secondary" href="{/literal}{$urls.base_url}{literal}pages/contact">Prendre rendez-vous</a></div></div>
</section>






</div>
<div id="shopify-section-template--es__ed_scene_2" class="shopify-section " data-es-section="index:ed_scene_2" data-es-type="ed-scene">
<section class="ed-section ed-scene ed-scene--split color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><div class="ed-scene__media"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esterregestecfab67cd/assets/es/es-client-1kx98nbpe56znuv4.jpg" alt="Vue fournie de l’atelier et de son matériel, scène 2 — recette fictive" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div><div class="ed-scene__copy"><p class="ed-kicker">En situation</p><h2 class="ed-title">En situation</h2><div class="ed-prose"><p>Vue fournie de l’atelier et de son matériel, scène 2 — recette fictive</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Prendre rendez-vous<span aria-hidden="true">↗</span></a></div></div></section>

</div>
<div id="shopify-section-template--es__practical_info_1" class="shopify-section es-section-wrapper" data-es-section="index:practical_info_1" data-es-type="practical-info"><section class="es-section es-info color-scheme-3" style="--pt: 104px; --pb: 104px;">
  <div class="es-container">
    <header class="es-info__head"><h2 class="es-heading es-h2" data-reveal="words">Parlons de votre projet</h2><div class="es-rte es-lead" data-reveal="up"><p>Écrivez à l’atelier pour préparer votre rendez-vous.</p></div></header>

    <div class="es-info__grid">
      <div class="es-info__cards"><div class="es-info__card es-info__card--hours" data-reveal="up">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Horaires</h3>
            <dl class="es-info__hours"><div class="es-info__row"><dt>Sur rendez-vous</dt><dd></dd></div></dl></div><div class="es-info__card" data-reveal="up" style="--d: 1">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>Adresse</h3><p class="es-info__area"><span class="es-info__label">Zone d'intervention</span>Quartier des Ateliers, Lyon — exemple fictif</p></div><div class="es-info__card es-info__card--contact" data-reveal="up" style="--d: 2">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg>Nous joindre</h3><a class="es-info__email" href="mailto:atelier@example.test"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><span>atelier@example.test</span></a><a class="es-button es-button--full es-info__cta" href="{/literal}{$urls.base_url}{literal}pages/contact">Prendre rendez-vous</a></div></div></div>
  </div>
</section>






</div>
<div id="shopify-section-template--es__faq_2" class="shopify-section es-section-wrapper" data-es-section="index:faq_2" data-es-type="faq"><section class="es-section es-faq es-faq--lines es-faq--side es-faq--cols-1 color-scheme-1" style="--pt: 104px; --pb: 104px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Vos questions</h2><div class="es-faq__contact" data-reveal="up"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button es-button--secondary es-button--small">Prendre rendez-vous <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a>
        </div></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_2"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="client_0">
          <summary><span class="es-faq__q">Comment réserver ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Choisissez un créneau par la prise de rendez-vous.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="client_1">
          <summary><span class="es-faq__q">Quelle est la durée ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>L’atelier de tournage individuel dure 1 h 30.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="client_2">
          <summary><span class="es-faq__q">Quel est le tarif ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>L’atelier individuel est proposé à 75 € dans ce projet fictif.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Comment réserver ?", "acceptedAnswer": { "@type": "Answer", "text": "Choisissez un créneau par la prise de rendez-vous." } },{ "@type": "Question", "name": "Quelle est la durée ?", "acceptedAnswer": { "@type": "Answer", "text": "L’atelier de tournage individuel dure 1 h 30." } },{ "@type": "Question", "name": "Quel est le tarif ?", "acceptedAnswer": { "@type": "Answer", "text": "L’atelier individuel est proposé à 75 € dans ce projet fictif." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__contact_form_1" class="shopify-section " data-es-section="index:contact_form_1" data-es-type="contact-form"><section class="es-section es-contact color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-contact__grid">
    <header class="es-contact__intro"><h2 class="es-heading es-h2" data-reveal="words">Parlons de votre projet</h2><div class="es-rte es-contact__text" data-reveal="up"><p>Écrivez à l’atelier pour préparer votre rendez-vous.</p></div><ul class="es-contact__details" role="list" data-reveal="up" style="--d: 1"><li><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><a href="mailto:atelier@example.test">atelier@example.test</a></li><li><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span>Sur rendez-vous</span></li></ul></header><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="ContactForm" class="es-form es-contact__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><div class="es-form__row">
        <label>Nom<input type="text" name="contact[name]" autocomplete="name" value=""></label>
        <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label>
      </div>
      <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
      <label>Message<textarea name="contact[body]" rows="6" class="es-textarea"></textarea></label>
      <button type="submit" class="es-button">Envoyer</button></form></div>
</section>





</div>{/literal}