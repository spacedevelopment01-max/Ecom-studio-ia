{literal}<div id="shopify-section-template--es__main_page_4" class="shopify-section " data-es-section="page.faq:main_page_4" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Questions fréquentes</h1>
    <div class="es-rte es-page__content" data-reveal="up"></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "L’Atelier des Gestes", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Questions fréquentes", "item": "/pages/faq" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__faq_5" class="shopify-section es-section-wrapper" data-es-section="page.faq:faq_5" data-es-type="faq"><section class="es-section es-faq es-faq--cards es-faq--side es-faq--cols-1 color-scheme-1" style="--pt: 104px; --pb: 104px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Vos questions</h2><div class="es-faq__contact" data-reveal="up"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button es-button--secondary es-button--small">Prendre rendez-vous <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a>
        </div></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_5"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="client_0">
          <summary><span class="es-faq__q">Comment réserver ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Choisissez un créneau par la prise de rendez-vous.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="client_1">
          <summary><span class="es-faq__q">Quelle est la durée ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>L’atelier de tournage individuel dure 1 h 30.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="client_2">
          <summary><span class="es-faq__q">Quel est le tarif ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>L’atelier individuel est proposé à 75 € dans ce projet fictif.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Comment réserver ?", "acceptedAnswer": { "@type": "Answer", "text": "Choisissez un créneau par la prise de rendez-vous." } },{ "@type": "Question", "name": "Quelle est la durée ?", "acceptedAnswer": { "@type": "Answer", "text": "L’atelier de tournage individuel dure 1 h 30." } },{ "@type": "Question", "name": "Quel est le tarif ?", "acceptedAnswer": { "@type": "Answer", "text": "L’atelier individuel est proposé à 75 € dans ce projet fictif." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__contact_form_4" class="shopify-section " data-es-section="page.faq:contact_form_4" data-es-type="contact-form"><section class="es-section es-contact color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-contact__grid">
    <header class="es-contact__intro"><h2 class="es-heading es-h2" data-reveal="words">Parlons de votre projet</h2><div class="es-rte es-contact__text" data-reveal="up"><p>Écrivez à l’atelier pour préparer votre rendez-vous.</p></div><ul class="es-contact__details" role="list" data-reveal="up" style="--d: 1"><li><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><a href="mailto:atelier@example.test">atelier@example.test</a></li><li><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span>Sur rendez-vous</span></li></ul></header><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="ContactForm" class="es-form es-contact__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><div class="es-form__row">
        <label>Nom<input type="text" name="contact[name]" autocomplete="name" value=""></label>
        <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label>
      </div>
      <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
      <label>Message<textarea name="contact[body]" rows="6" class="es-textarea"></textarea></label>
      <button type="submit" class="es-button">Envoyer</button></form></div>
</section>





</div>{/literal}