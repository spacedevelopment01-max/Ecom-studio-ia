{literal}<div id="shopify-section-template--es__legal_page_1" class="shopify-section es-section-wrapper" data-es-section="page.legal:legal_page_1" data-es-type="legal-page"><section class="es-section es-legal color-scheme-1" style="--pt: 64px; --pb: 96px;" data-legal>
  <div class="es-legal__progress" aria-hidden="true"><span data-legal-bar></span></div>
  <div class="es-container">
    <header class="es-legal__head"><p class="es-eyebrow">Informations légales</p><h1 class="es-heading es-h2 es-legal__title">Informations légales</h1><div class="es-legal__meta"><button type="button" class="es-legal__print" data-legal-print>Imprimer</button></div></header>
    <div class="es-legal__layout"><nav class="es-legal__toc" aria-labelledby="LegalToc-template--es__legal_page_1" data-legal-toc>
          <details class="es-legal__details" open data-legal-details>
            <summary id="LegalToc-template--es__legal_page_1">Sommaire</summary>
            <ol class="es-legal__toclist" data-legal-toclist><li><a href="#template--es__legal_page_1-part-1">Informations à fournir</a></li></ol>
          </details>
        </nav><article class="es-legal__body es-rte" data-legal-body><section class="es-legal__part" aria-labelledby="template--es__legal_page_1-part-1" data-es-block="client_part">
              <h2 id="template--es__legal_page_1-part-1">Informations à fournir</h2>
              <p>Ces informations doivent être fournies et vérifiées par le professionnel avant publication.</p>
            </section><p class="es-legal__top"><a href="#LegalTop-template--es__legal_page_1" data-legal-top><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20V4M6 10l6-6 6 6"/></svg>Revenir en haut de la page</a></p>
      </article>
    </div>
  </div>
  <span id="LegalTop-template--es__legal_page_1" class="es-legal__anchor"></span>
</section>






</div>{/literal}