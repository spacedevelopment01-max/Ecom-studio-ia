{literal}<div id="shopify-section-template--es__main_page_1" class="shopify-section " data-es-section="page:main_page_1" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--narrow" style="--pt: 64px; --pb: 96px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Conditions générales de prestation</h1>
    <div class="es-rte es-page__content" data-reveal="up"><p><strong>Prestations</strong><br>Atelier de tournage individuel (1 h 30 · 75 €) ; Découverte des émaux (1 h · 45 €).</p><p><strong>Tarifs</strong><br>Atelier de tournage individuel : 75 € ; Découverte des émaux : 45 €.</p><p><strong>Devis et réservation</strong><br>[À compléter : conditions de devis, d'acompte et de confirmation]</p><p><strong>Annulation et report</strong><br>[À compléter : délai et conditions d'annulation]</p><p><strong>Paiement</strong><br>[À compléter : moyens et échéances de paiement]</p><p><strong>Responsabilité et assurance</strong><br>[À compléter : assurance professionnelle et responsabilités]</p></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "L’Atelier des Gestes", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Conditions générales de prestation", "item": "" }
      ]
    }
  </script>
</section>


</div>{/literal}