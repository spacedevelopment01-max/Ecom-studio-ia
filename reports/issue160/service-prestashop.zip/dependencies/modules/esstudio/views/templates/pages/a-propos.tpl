{literal}<div id="shopify-section-template--es__main_page_3" class="shopify-section " data-es-section="page.about:main_page_3" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 40px; --pb: 0px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Notre histoire</h1>
    <div class="es-rte es-page__content" data-reveal="up"></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "L’Atelier des Gestes", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "Notre histoire", "item": "/pages/a-propos" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__about_1" class="shopify-section es-section-wrapper" data-es-section="page.about:about_1" data-es-type="about"><section class="es-section es-about color-scheme-1" style="--pt: 120px; --pb: 104px;">
  <div class="es-container">
    <header class="es-about__head"><h2 class="es-heading es-about__title" data-reveal="words">L’Atelier des Gestes</h2></header>

    <div class="es-about__intro">
      <figure class="es-about__media" data-reveal="curtain">
        <div class="es-about__img" data-parallax="0.06">
          <img src="{/literal}{$urls.base_url}{literal}themes/eslatelierdesgestes7003bbb2/assets/es/es-client-1lhl49pm2yihgr6x.jpg" alt="L’Atelier des Gestes" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async">
        </div></figure>
      <div class="es-about__story"><div class="es-rte es-about__lead" data-reveal="up"><p>L’atelier accompagne chaque étape du tournage, de la préparation de la terre à la forme qui prend place sur le tour.</p></div><div class="es-about__pillars"><div class="es-about__pillar" data-reveal="up" style="--d: 1">
              <p class="es-about__kicker"><span>01</span>Un atelier, un geste à la fois.</p>
              <div class="es-rte"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div>
            </div><div class="es-about__pillar" data-reveal="up" style="--d: 2">
              <p class="es-about__kicker"><span>02</span></p>
              <div class="es-rte"><p>Un accompagnement individuel : Chaque atelier reçoit une seule personne, sur rendez-vous.</p><p>Le sens du détail : La préparation, le centrage et le geste se travaillent dans cet ordre.</p></div>
            </div></div><p class="es-signature es-about__sign" data-reveal="up" style="--d: 3">L’Atelier des Gestes</p></div>
    </div><div class="es-about__values"><ul class="es-about__cards" role="list" style="--count: 2;"><li class="es-about__card" data-reveal="up" style="--i: 0" data-es-block="client_0">
              <span class="es-about__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span>
              <h4 class="es-about__card-title">Un accompagnement individuel</h4><div class="es-rte es-about__card-text"><p>Chaque atelier reçoit une seule personne, sur rendez-vous.</p></div></li><li class="es-about__card" data-reveal="up" style="--i: 1" data-es-block="client_1">
              <span class="es-about__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span>
              <h4 class="es-about__card-title">Le sens du détail</h4><div class="es-rte es-about__card-text"><p>La préparation, le centrage et le geste se travaillent dans cet ordre.</p></div></li></ul>
      </div><div class="es-actions es-actions--center es-about__cta" data-reveal="up"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button">Prendre rendez-vous <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div></div>
</section>




</div>
<div id="shopify-section-template--es__team_1" class="shopify-section es-section-wrapper" data-es-section="page.about:team_1" data-es-type="team"><section class="es-section es-team es-team--cards color-scheme-2" style="--pt: 104px; --pb: 104px; --cols: 1;">
  <div class="es-container">
    <header class="es-team__head"><h2 class="es-heading es-h2" data-reveal="words">Approcher la terre et le tour</h2><div class="es-rte es-lead" data-reveal="up"><p>Un atelier individuel sur rendez-vous pour découvrir le tournage et travailler une pièce avec un accompagnement pas à pas.</p></div></header>
    <ul class="es-team__grid" role="list"></ul>
  </div>
</section>




</div>
<div id="shopify-section-template--es__timeline_2" class="shopify-section es-section-wrapper" data-es-section="page.about:timeline_2" data-es-type="timeline"><section class="es-section es-timeline color-scheme-1" style="--pt: 104px; --pb: 104px;">
  <div class="es-container es-timeline__inner"><p class="es-eyebrow es-timeline__eyebrow" data-reveal="up">Notre méthode</p><h2 class="es-heading es-h2 es-timeline__heading" data-reveal="words">Le déroulé de votre atelier</h2><div class="es-timeline__media es-media-frame" data-scroll-zoom data-reveal="zoom"><img src="{/literal}{$urls.base_url}{literal}themes/eslatelierdesgestes7003bbb2/assets/es/es-client-633529xli78brckx.jpg" alt="Le déroulé de votre atelier" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><ol class="es-timeline__list" data-timeline>
      <span class="es-timeline__line" aria-hidden="true"><span class="es-timeline__fill"></span></span><li class="es-timeline__step" data-timeline-step data-es-block="client_0">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">01</span>
          <h3 class="es-heading es-h3">Préparer la terre</h3>
          <div class="es-rte"><p>La séance commence par la préparation de la terre.</p></div>
        </li><li class="es-timeline__step" data-timeline-step data-es-block="client_1">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">02</span>
          <h3 class="es-heading es-h3">Centrer sur le tour</h3>
          <div class="es-rte"><p>Le centrage se travaille avec l’accompagnement de l’atelier.</p></div>
        </li><li class="es-timeline__step" data-timeline-step data-es-block="client_2">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">03</span>
          <h3 class="es-heading es-h3">Travailler la forme</h3>
          <div class="es-rte"><p>La forme est travaillée progressivement sur le tour.</p></div>
        </li></ol>
  </div>
</section>




</div>
<div id="shopify-section-template--es__cta_banner_3" class="shopify-section es-section-wrapper" data-es-section="page.about:cta_banner_3" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-3 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.6;"><div class="es-cta__media" data-parallax="0.2"><img src="{/literal}{$urls.base_url}{literal}themes/eslatelierdesgestes7003bbb2/assets/es/es-client-sj8523n2jfkdtwsy.jpg" alt="" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">L’Atelier des Gestes</h2><div class="es-rte es-lead" data-reveal="up"><p>L’Atelier des Gestes : atelier de tournage individuel, découverte des émaux.</p></div><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button" data-reveal="up" style="--d: 1">Prendre rendez-vous <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>





</div>{/literal}