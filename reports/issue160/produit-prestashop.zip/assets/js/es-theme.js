/* Thème E-COM STUDIO IA — interactions et animations.
   Aucune dépendance. Respecte prefers-reduced-motion et le réglage du thème. */
(function () {
  'use strict';
  var doc = document.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var settings = window.themeSettings || {};
  var motion = settings.motion !== false && !reduce && 'IntersectionObserver' in window;
  var routes = window.routes || {};
  var strings = window.themeStrings || {};

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
  function formatMoney(cents, format) {
    format = format || settings.moneyFormat || '{{amount}} €';
    cents = typeof cents === 'string' ? cents.replace('.', '') : cents;
    function fmt(n, dec, ts, ds) {
      dec = dec == null ? 2 : dec; ts = ts || ','; ds = ds || '.';
      var num = (n / 100).toFixed(dec); var parts = num.split('.');
      return parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + ts) + (parts[1] ? ds + parts[1] : '');
    }
    return format.replace(/\{\{\s*(\w+)\s*\}\}/, function (_, key) {
      switch (key) {
        case 'amount_no_decimals': return fmt(cents, 0);
        case 'amount_with_comma_separator': return fmt(cents, 2, '.', ',');
        case 'amount_no_decimals_with_comma_separator': return fmt(cents, 0, '.', ',');
        case 'amount_with_space_separator': return fmt(cents, 2, ' ', ',');
        default: return fmt(cents, 2);
      }
    });
  }
  function toast(msg) {
    var t = $('.es-toast'); if (!t) return;
    t.textContent = msg; t.hidden = false;
    clearTimeout(t._h); t._h = setTimeout(function () { t.hidden = true; }, 2600);
  }

  /* ---------- Apparitions au défilement ---------- */
  function initReveal(root) {
    var items = $$('[data-reveal]', root);
    if (!motion) { items.forEach(function (el) { el.classList.add('is-in'); }); return; }
    doc.classList.add('motion-ready');
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { (e.target._esReveal || [e.target]).forEach(function (el) { el.classList.add('is-in'); }); io.unobserve(e.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    // Rideau et masque : l'élément est entièrement découpé (clip-path) au départ, ce que Chrome compte comme invisible ;
    // on observe donc son parent.
    items.forEach(function (el) {
      if (el.classList.contains('is-in')) return;
      var t = /^(curtain|mask)$/.test(el.getAttribute('data-reveal')) && el.parentElement ? el.parentElement : el;
      if (t !== el) (t._esReveal = t._esReveal || (t.hasAttribute('data-reveal') ? [t] : [])).push(el);
      io.observe(t);
    });
    // Repli de sécurité : un texte ne reste jamais masqué en attente d'une apparition (observateur manqué, page
    // restaurée, défilement très rapide) ; passé ce délai, tout ce qui est encore invisible est révélé.
    setTimeout(function () { $$('[data-reveal]:not(.is-in)', root).forEach(function (el) { el.classList.add('is-in'); }); }, 3200);
  }

  /* ---------- Parallaxe (rAF, désactivée si mouvement réduit) ---------- */
  var parallaxItems = [];
  function initParallax() {
    if (!motion || settings.parallax === false) return;
    parallaxItems = $$('[data-parallax]').map(function (el) { return { el: el, speed: parseFloat(el.getAttribute('data-parallax')) || 0.15 }; });
  }
  var ticking = false;
  function onScroll() {
    if (ticking) return; ticking = true;
    requestAnimationFrame(function () {
      var vh = window.innerHeight;
      parallaxItems.forEach(function (p) {
        var r = p.el.getBoundingClientRect();
        if (r.bottom < -200 || r.top > vh + 200) return;
        var center = r.top + r.height / 2 - vh / 2;
        p.el.style.transform = 'translate3d(0,' + (-center * p.speed).toFixed(1) + 'px,0)';
      });
      headerOnScroll();
      stickyBuyOnScroll();
      scrollEffects();
      narrativeOnScroll();
      ticking = false;
    });
  }

  /* ---------- En-tête ---------- */
  var header = $('[data-header]'); var lastY = 0;
  function headerOnScroll() {
    if (!header) return;
    var y = window.scrollY;
    header.classList.toggle('is-scrolled', y > 40);
    // En-tête transparent fixé : il reste sous le bandeau d'annonce tant que celui-ci est visible.
    if (header.classList.contains('es-header--transparent')) {
      var ann = $('.es-announcement-section');
      var annBottom = ann ? ann.getBoundingClientRect().bottom : 0;
      header.style.setProperty('--es-hoff', Math.max(0, annBottom) + 'px');
    }
    if (header.classList.contains('es-header--sticky')) header.classList.toggle('is-hidden', y > 300 && y > lastY && !document.body.classList.contains('menu-open'));
    lastY = y;
  }
  function initMenu() {
    var menu = $('[data-mobile-menu]'); if (!menu) return;
    var opener = $('[data-menu-open]');
    function open() { menu.hidden = false; requestAnimationFrame(function () { menu.classList.add('is-open'); }); document.body.classList.add('menu-open'); document.body.style.overflow = 'hidden'; opener && opener.setAttribute('aria-expanded', 'true'); var c = $('[data-menu-close]', menu); c && c.focus(); }
    function close() { menu.classList.remove('is-open'); menu.hidden = true; document.body.classList.remove('menu-open'); document.body.style.overflow = ''; opener && opener.setAttribute('aria-expanded', 'false'); opener && opener.focus(); }
    opener && opener.addEventListener('click', open);
    $$('[data-menu-close]', menu).forEach(function (b) { b.addEventListener('click', close); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !menu.hidden) close(); });
  }

  /* ---------- Panier latéral (API AJAX de Shopify) ---------- */
  var drawer = null;
  function drawerEl() { return drawer || (drawer = $('[data-cart-drawer]')); }
  function openDrawer() {
    var d = drawerEl(); if (!d) { window.location.href = routes.cart; return; }
    d.hidden = false; requestAnimationFrame(function () { d.classList.add('is-open'); });
    document.body.style.overflow = 'hidden';
    var c = $('[data-cart-close].es-icon-button', d); c && c.focus();
  }
  function closeDrawer() {
    var d = drawerEl(); if (!d) return;
    d.classList.remove('is-open'); document.body.style.overflow = '';
    setTimeout(function () { d.hidden = true; }, 450);
  }
  function renderDrawer(html) {
    var d = drawerEl(); if (!d || !html) return;
    var tmp = document.createElement('div'); tmp.innerHTML = html;
    var fresh = $('[data-cart-drawer]', tmp);
    if (fresh) { var panel = $('.es-drawer__panel', d); var newPanel = $('.es-drawer__panel', fresh); var scroller = $('[data-cart-scroll]', d); var top = scroller ? scroller.scrollTop : 0; if (panel && newPanel) panel.innerHTML = newPanel.innerHTML; var again = $('[data-cart-scroll]', d); if (again && top) again.scrollTop = top; }
    bindDrawer();
  }
  function updateCount(count) {
    $$('[data-cart-count]').forEach(function (el) { el.textContent = count; el.hidden = !count; });
  }
  function bindDrawer() {
    var d = drawerEl(); if (!d) return;
    $$('[data-cart-close]', d).forEach(function (b) { b.onclick = closeDrawer; });
    $$('[data-qty-change]', d).forEach(function (b) {
      b.onclick = function () {
        var li = b.closest('[data-key]'); if (!li) return;
        changeLine(li.getAttribute('data-key'), parseInt(b.getAttribute('data-qty-change'), 10));
      };
    });
  }
  function changeLine(key, qty) {
    var d = drawerEl(); d && d.classList.add('is-loading');
    fetch(routes.cart_change, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ id: key, quantity: qty, sections: 'cart-drawer', sections_url: window.location.pathname })
    }).then(function (r) { return r.json(); }).then(function (cart) {
      updateCount(cart.item_count);
      if (cart.sections) renderDrawer(cart.sections['cart-drawer']);
    }).catch(function () { toast(strings.error); }).finally(function () { d && d.classList.remove('is-loading'); });
  }
  function initCart() {
    bindDrawer();
    if (settings.cartType === 'drawer') {
      $$('[data-cart-open]').forEach(function (a) { a.addEventListener('click', function (e) { if (drawerEl()) { e.preventDefault(); openDrawer(); } }); });
    }
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeDrawer(); });
  }

  /* ---------- Fiche produit : variantes, quantité, ajout ---------- */
  function initBuy(root) {
    $$('[data-product-buy]', root).forEach(function (wrap) {
      var variants = []; try { variants = JSON.parse(($('[data-variants]', wrap) || {}).textContent || '[]'); } catch (e) {}
      var form = $('[data-product-form]', wrap);
      var idInput = $('[data-variant-id]', wrap);
      var addBtn = $('[data-add-button]', wrap);
      var addLabel = $('[data-add-label]', wrap);
      var errorEl = $('[data-form-error]', wrap);
      function selected() {
        var values = [];
        $$('[data-option-index]', wrap).forEach(function (input) {
          var i = parseInt(input.getAttribute('data-option-index'), 10);
          if (input.tagName === 'SELECT' || input.checked) values[i] = input.value;
        });
        return values;
      }
      function onChange() {
        var values = selected();
        var v = variants.find(function (x) { return x.options.every(function (o, i) { return values[i] === undefined || o === values[i]; }); });
        values.forEach(function (val, i) { var lab = $('[data-option-value="' + i + '"]', wrap); if (lab) lab.textContent = val; });
        if (!v) { addBtn.disabled = true; addLabel.textContent = strings.unavailable; return; }
        idInput.value = v.id;
        addBtn.disabled = !v.available;
        var withPrice = !!$('[data-button-price]', wrap) || wrap.hasAttribute('data-price-in-button');
        if (withPrice) wrap.setAttribute('data-price-in-button', '');
        addLabel.textContent = v.available ? strings.addToCart + (withPrice && v.price != null ? ' – ' + formatMoney(v.price) : '') : strings.soldOut;
        var section = wrap.closest('[data-main-product], [data-featured-product]');
        var priceWrap = section && $('[data-price]', section);
        if (priceWrap && v.price != null) { var cur = priceWrap.querySelector('.es-price__current'); if (cur) cur.textContent = formatMoney(v.price); }
        if (v.featured_media && section) goToMedia(section, v.featured_media.id);
        if (section) section.dispatchEvent(new CustomEvent('es:variant', { detail: v }));
        if (wrap.getAttribute('data-product-url') && history.replaceState && section && section.hasAttribute('data-main-product')) {
          history.replaceState({}, '', wrap.getAttribute('data-product-url') + '?variant=' + v.id);
        }
      }
      $$('[data-option-index]', wrap).forEach(function (input) { input.addEventListener('change', onChange); });
      $$('[data-qty-step]', wrap).forEach(function (b) {
        b.addEventListener('click', function () {
          var input = $('input[name="quantity"]', wrap); if (!input) return;
          input.value = Math.max(1, (parseInt(input.value, 10) || 1) + parseInt(b.getAttribute('data-qty-step'), 10));
        });
      });
      if (form) form.addEventListener('submit', function (e) {
        if (settings.cartType !== 'drawer' || !drawerEl()) return;
        e.preventDefault();
        errorEl && (errorEl.hidden = true);
        addBtn.setAttribute('aria-busy', 'true'); addBtn.disabled = true;
        var fd = new FormData(form);
        fd.append('sections', 'cart-drawer'); fd.append('sections_url', window.location.pathname);
        fetch(routes.cart_add, { method: 'POST', headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, body: fd })
          .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
          .then(function (res) {
            if (!res.ok || res.body.status) { errorEl.textContent = res.body.description || res.body.message || strings.error; errorEl.hidden = false; return; }
            if (res.body.sections) renderDrawer(res.body.sections['cart-drawer']);
            return fetch(routes.cart + '.js', { headers: { Accept: 'application/json' } }).then(function (r) { return r.json(); }).then(function (cart) { updateCount(cart.item_count); openDrawer(); });
          })
          .catch(function () { errorEl.textContent = strings.error; errorEl.hidden = false; })
          .finally(function () { addBtn.removeAttribute('aria-busy'); addBtn.disabled = false; });
      });
    });
  }

  /* ---------- Lots (compose ton panier) et abonnement ---------- */
  function initOffers(root) {
    $$('[data-bundles]', root).forEach(function (box) {
      var section = box.closest('[data-main-product]') || document;
      var units = parseInt(box.getAttribute('data-units'), 10) || 0;
      function pick(btn) {
        $$('.es-bundle', box).forEach(function (b) { b.setAttribute('aria-checked', b === btn ? 'true' : 'false'); });
        var q = $('input[name="quantity"]', section); if (q) q.value = btn.getAttribute('data-qty');
      }
      $$('.es-bundle', box).forEach(function (b) { b.addEventListener('click', function () { pick(b); }); });
      var initial = $('.es-bundle[aria-checked="true"]', box); if (initial) pick(initial);
      section.addEventListener('es:variant', function (e) {
        var price = e.detail && e.detail.price; if (price == null) return;
        $$('.es-bundle', box).forEach(function (b) {
          var q = +b.getAttribute('data-qty'), d = +b.getAttribute('data-discount') || 0;
          var full = price * q, total = Math.round(full * (100 - d) / 100);
          var p = $('[data-bundle-price]', b); if (p) p.textContent = formatMoney(total);
          var c = $('[data-bundle-compare]', b); if (c) c.textContent = formatMoney(full);
          var u = $('[data-bundle-unit]', b); if (u && units) u.textContent = formatMoney(Math.round(total / (units * q)));
        });
      });
    });
    $$('[data-subscribe]', root).forEach(function (box) {
      var section = box.closest('[data-main-product]') || document;
      var form = $('[data-product-form]', section); if (!form) return;
      function sync() {
        var sel = $('input[type="radio"]:checked', box), val = sel ? sel.value : '';
        var hidden = $('input[name="selling_plan"]', form);
        if (val) { if (!hidden) { hidden = document.createElement('input'); hidden.type = 'hidden'; hidden.name = 'selling_plan'; form.appendChild(hidden); } hidden.value = val; }
        else if (hidden) hidden.remove();
      }
      $$('input[type="radio"]', box).forEach(function (r) { r.addEventListener('change', sync); });
      sync();
    });
  }

  /* ---------- Livraison estimée (délais réels saisis par le marchand) ---------- */
  function initEta(root) {
    $$('[data-eta]', root).forEach(function (box) {
      var min = parseInt(box.getAttribute('data-min'), 10) || 0, max = parseInt(box.getAttribute('data-max'), 10) || 0;
      var business = box.getAttribute('data-business') === 'true';
      function add(days) {
        var d = new Date();
        while (days > 0) { d.setDate(d.getDate() + 1); if (!business || (d.getDay() !== 0 && d.getDay() !== 6)) days--; }
        return d;
      }
      var fmt = function (d) { return d.toLocaleDateString(document.documentElement.lang || undefined, { weekday: 'short', day: 'numeric', month: 'short' }); };
      var out = $('[data-eta-range]', box); if (!out || !max) return;
      out.textContent = min && min !== max ? fmt(add(min)) + ' – ' + fmt(add(max)) : fmt(add(max));
    });
  }

  /* ---------- Galerie produit ---------- */
  function goToMedia(section, mediaId) {
    var track = $('[data-gallery-track]', section); if (!track) return;
    var slide = $('[data-media-id="' + mediaId + '"]', track); if (!slide) return;
    var idx = Array.prototype.indexOf.call(track.children, slide);
    if (getComputedStyle(track).display === 'flex') track.scrollTo({ left: slide.offsetLeft - track.offsetLeft, behavior: reduce ? 'auto' : 'smooth' });
    else slide.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'nearest' });
    $$('[data-gallery-go]', section).forEach(function (t, i) { t.classList.toggle('is-active', i === idx); });
  }
  /* Agrandissement des images produit : boîte de dialogue native (Échap, focus rendu au bouton), flèches et clavier. */
  function initZoom() {
    $$('[data-gallery]').forEach(function (g) {
      var dlg = $('[data-zoom]', g); if (!dlg || !dlg.showModal) return;
      var stage = $('[data-zoom-stage]', dlg);
      var btns = $$('[data-zoom-open]', g); var at = 0; var opener = null;
      function show(i) {
        at = (i + btns.length) % btns.length; var b = btns[at];
        var img = document.createElement('img');
        img.className = 'es-zoom__img'; img.src = b.getAttribute('data-zoom-src'); img.alt = b.getAttribute('data-zoom-alt') || '';
        stage.innerHTML = ''; stage.appendChild(img);
        $$('[data-zoom-step]', dlg).forEach(function (x) { x.hidden = btns.length < 2; });
      }
      btns.forEach(function (b, i) { b.addEventListener('click', function () { opener = b; show(i); dlg.showModal(); }); });
      $$('[data-zoom-step]', dlg).forEach(function (x) { x.addEventListener('click', function () { show(at + parseInt(x.getAttribute('data-zoom-step'), 10)); }); });
      $('[data-zoom-close]', dlg).addEventListener('click', function () { dlg.close(); });
      dlg.addEventListener('click', function (e) { if (e.target === dlg || e.target === stage) dlg.close(); });
      dlg.addEventListener('keydown', function (e) { if (e.key === 'ArrowRight') show(at + 1); if (e.key === 'ArrowLeft') show(at - 1); });
      dlg.addEventListener('close', function () { stage.innerHTML = ''; if (opener) opener.focus(); });
    });
  }
  function initGallery() {
    initZoom();
    $$('[data-gallery]').forEach(function (g) {
      var track = $('[data-gallery-track]', g);
      $$('[data-gallery-go]', g).forEach(function (btn) {
        btn.addEventListener('click', function () {
          var i = parseInt(btn.getAttribute('data-gallery-go'), 10); var slide = track.children[i]; if (!slide) return;
          goToMedia(g.closest('section') || g, slide.getAttribute('data-media-id'));
        });
      });
      if (track) track.addEventListener('scroll', function () {
        if (getComputedStyle(track).display !== 'flex') return;
        var i = Math.round(track.scrollLeft / (track.children[0] ? track.children[0].offsetWidth + 8 : 1));
        $$('[data-gallery-go]', g).forEach(function (t, j) { t.classList.toggle('is-active', j === i); });
      }, { passive: true });
    });
  }

  /* ---------- Barre d'achat qui suit le défilement ---------- */
  var stickyBuy = null; var mainBuy = null;
  function initStickyBuy() {
    stickyBuy = $('[data-sticky-buy]'); mainBuy = $('#MainBuy');
    if (!stickyBuy || !mainBuy) return;
    stickyBuy.hidden = false;
    var section = mainBuy.closest('[data-main-product]') || document;
    section.addEventListener('es:variant', stickySummary);
    section.addEventListener('click', function (e) { if (e.target.closest('.es-bundle, [data-qty-step]')) setTimeout(stickySummary, 0); });
    section.addEventListener('input', function (e) { if (e.target.name === 'quantity') stickySummary(); });
    stickySummary();
    var btn = $('[data-sticky-add]', stickyBuy);
    btn && btn.addEventListener('click', function () {
      var form = $('[data-product-form]', mainBuy);
      if (form) { if (form.requestSubmit) form.requestSubmit(); else form.submit(); }
    });
  }
  /* Résumé de la barre : lot ou quantité, variante, total. */
  function stickySummary() {
    if (!stickyBuy || !mainBuy) return;
    var section = mainBuy.closest('[data-main-product]') || document;
    var variants = []; try { variants = JSON.parse(($('[data-variants]', section) || {}).textContent || '[]'); } catch (e) {}
    var idInput = $('[data-variant-id]', section);
    var v = variants.find(function (x) { return idInput && String(x.id) === String(idInput.value); }) || variants[0];
    if (!v) return;
    var qInput = $('input[name="quantity"]', section);
    var q = Math.max(1, parseInt(qInput && qInput.value, 10) || 1);
    var bundle = $('.es-bundle[aria-checked="true"]', section);
    var discount = bundle && +bundle.getAttribute('data-qty') === q ? +bundle.getAttribute('data-discount') || 0 : 0;
    var parts = [];
    if (bundle && +bundle.getAttribute('data-qty') === q) { var lab = $('.es-bundle__label', bundle); parts.push(lab ? lab.childNodes[0].textContent.trim() : q + ' ×'); }
    else if (q > 1) parts.push(q + ' ×');
    if (v.title && v.title !== 'Default Title') parts.push(v.title);
    var meta = $('[data-sticky-meta]', stickyBuy); if (meta) meta.textContent = parts.join(' · ') + (parts.length ? ' ·' : '');
    var total = $('[data-sticky-total]', stickyBuy); if (total && v.price != null) total.textContent = formatMoney(Math.round(v.price * q * (100 - discount) / 100));
    var btn = $('[data-sticky-add]', stickyBuy); if (btn) btn.disabled = !v.available;
  }
  function stickyBuyOnScroll() {
    if (!stickyBuy || !mainBuy) return;
    var r = mainBuy.getBoundingClientRect();
    var footer = $('.es-footer'); var fr = footer ? footer.getBoundingClientRect().top : Infinity;
    // Visible dès que le bouton d'ajout n'est plus à l'écran (passé sous l'en-tête ou hors champ), masquée au pied de page.
    var headerH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--header-h'), 10) || 0;
    var inView = r.top < window.innerHeight && r.bottom > headerH;
    stickyBuy.classList.toggle('is-visible', !inView && window.scrollY > 120 && fr > window.innerHeight);
  }

  /* ---------- Présentation au défilement ---------- */
  function initStory() {
    $$('[data-scroll-story]').forEach(function (s) {
      var steps = $$('[data-story-step]', s);
      var layers = $$('[data-story-layer]', s);
      var dots = $$('[data-story-dot]', s);
      function activate(i) {
        steps.forEach(function (st, j) { st.classList.toggle('is-active', j === i); });
        layers.forEach(function (l) { l.classList.toggle('is-active', parseInt(l.getAttribute('data-story-layer'), 10) === i); });
        dots.forEach(function (d, j) { d.classList.toggle('is-active', j === i); });
      }
      activate(0);
      if (!('IntersectionObserver' in window)) return;
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) { if (e.isIntersecting) activate(parseInt(e.target.getAttribute('data-story-step'), 10)); });
      }, { rootMargin: '-45% 0px -45% 0px' });
      steps.forEach(function (st) { io.observe(st); });
    });
  }

  /* ---------- Routine en gestes : un geste par portion de défilement ---------- */
  function initRoutine() {
    $$('[data-routine]').forEach(function (s) {
      if (s.__routine) return; s.__routine = true;
      var steps = $$('[data-routine-step]', s), shots = $$('[data-routine-shot]', s);
      var cur = $('[data-routine-current]', s), bar = $('[data-routine-bar]', s), track = $('.es-routine__track', s);
      var n = steps.length, last = -1;
      function show(i, p) {
        if (i !== last) {
          last = i;
          steps.forEach(function (x, j) { x.classList.toggle('is-active', j === i); });
          shots.forEach(function (x, j) { x.classList.toggle('is-active', j === i); });
          if (cur) cur.textContent = (i + 1 < 10 ? '0' : '') + (i + 1);
        }
        if (bar) bar.style.width = Math.round(p * 100) + '%';
      }
      if (reduce || !n) { show(0, 1); return; }
      function onScroll() {
        var r = track.getBoundingClientRect();
        var total = Math.max(1, r.height - window.innerHeight);
        var p = Math.min(1, Math.max(0, -r.top / total));
        show(Math.min(n - 1, Math.floor(p * n)), p);
      }
      window.addEventListener('scroll', onScroll, { passive: true });
      window.addEventListener('resize', onScroll);
      onScroll();
    });
  }

  /* ---------- Carrousel horizontal ---------- */
  function initHGallery() {
    $$('[data-hgallery]').forEach(function (g) {
      var track = $('[data-hg-track]', g); if (!track) return;
      function step(dir) { var item = track.children[0]; var w = item ? item.getBoundingClientRect().width + 20 : 300; track.scrollBy({ left: dir * w, behavior: reduce ? 'auto' : 'smooth' }); }
      var p = $('[data-hg-prev]', g), n = $('[data-hg-next]', g);
      p && p.addEventListener('click', function () { step(-1); });
      n && n.addEventListener('click', function () { step(1); });
    });
  }

  /* ---------- Vidéos ---------- */
  function initVideos() {
    $$('video[data-autoplay]').forEach(function (v) {
      if (reduce) { v.removeAttribute('autoplay'); v.pause(); v.controls = true; return; }
      var io = 'IntersectionObserver' in window ? new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) v.play().catch(function () {}); else v.pause(); }); }, { threshold: 0.2 }) : null;
      io && io.observe(v);
    });
    $$('[data-video-toggle]').forEach(function (b) {
      var v = b.parentElement.querySelector('video'); if (!v) return;
      b.addEventListener('click', function () {
        if (v.paused) { v.play(); b.classList.remove('is-paused'); } else { v.pause(); b.classList.add('is-paused'); }
      });
    });
  }

  /* ---------- Divers ---------- */
  function initMisc() {
    $$('[data-autosubmit]').forEach(function (s) { s.addEventListener('change', function () { s.form.submit(); }); });
    $$('[data-filters] input[type=checkbox]').forEach(function (c) { c.addEventListener('change', function () { c.form.submit(); }); });
    $$('[data-recos]').forEach(function (el) {
      var url = el.getAttribute('data-url'); if (!url || el.children.length) return;
      fetch(url).then(function (r) { return r.text(); }).then(function (html) {
        var tmp = document.createElement('div'); tmp.innerHTML = html;
        var fresh = tmp.querySelector('[data-recos]'); if (fresh && fresh.innerHTML.trim()) { el.innerHTML = fresh.innerHTML; initReveal(el); }
      }).catch(function () {});
    });
  }

  /* ---------- Couche premium : mots, zoom, texte allumé, compteurs, comparateur, néon, boutons flottants ---------- */
  function splitWords(el) {
    if (el.getAttribute('data-split') === '1') return;
    var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
    var nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
    var wi = 0;
    nodes.forEach(function (n) {
      if (!n.nodeValue.trim()) return;
      var frag = document.createDocumentFragment();
      n.nodeValue.split(/(\s+)/).forEach(function (part) {
        if (!part) return;
        if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(part)); return; }
        var w = document.createElement('span'); w.className = 'es-w'; w.style.setProperty('--wi', wi++); w.textContent = part; frag.appendChild(w);
      });
      n.parentNode.replaceChild(frag, n);
    });
    el.setAttribute('data-split', '1');
  }
  function initWords(root) {
    if (!motion) return;
    $$('[data-reveal="words"], [data-scroll-words]', root).forEach(splitWords);
  }

  var zoomItems = [], wordBlocks = [];
  function initScrollEffects() {
    if (!motion) return;
    zoomItems = $$('[data-scroll-zoom]');
    wordBlocks = $$('[data-scroll-words]').map(function (el) { return { el: el, words: $$('.es-w', el) }; });
  }
  function scrollEffects() {
    var vh = window.innerHeight;
    zoomItems.forEach(function (el) {
      var r = el.getBoundingClientRect(); if (r.bottom < 0 || r.top > vh) return;
      var p = Math.min(1, Math.max(0, (vh - r.top) / (vh + r.height)));
      el.style.setProperty('--sz', (1.18 - p * 0.18).toFixed(4));
    });
    wordBlocks.forEach(function (b) {
      var r = b.el.getBoundingClientRect(); if (r.bottom < -vh || r.top > vh * 1.5) return;
      var p = Math.min(1, Math.max(0, (vh * 0.85 - r.top) / (r.height + vh * 0.35)));
      var lit = Math.round(p * b.words.length);
      b.words.forEach(function (w, i) { w.classList.toggle('is-lit', i < lit); });
    });
    var top = $('[data-back-to-top]'); if (top) top.classList.toggle('is-visible', window.scrollY > vh * 0.8);
  }

  function initCounters(root) {
    $$('[data-count]', root).forEach(function (el) {
      var raw = el.getAttribute('data-count'); var m = raw.match(/^(\D*)(\d+(?:[.,]\d+)?)(.*)$/);
      if (!m || !motion || !('IntersectionObserver' in window)) return;
      var target = parseFloat(m[2].replace(',', '.')); var dec = (m[2].split(/[.,]/)[1] || '').length; var sep = m[2].indexOf(',') > -1 ? ',' : '.';
      el.textContent = m[1] + (0).toFixed(dec).replace('.', sep) + m[3];
      var io = new IntersectionObserver(function (es) {
        if (!es[0].isIntersecting) return; io.disconnect();
        var t0 = performance.now();
        (function step(t) {
          var k = Math.min(1, (t - t0) / 1600); var e = 1 - Math.pow(1 - k, 3);
          el.textContent = m[1] + (target * e).toFixed(dec).replace('.', sep) + m[3];
          if (k < 1) requestAnimationFrame(step);
        })(t0);
      }, { threshold: 0.6 });
      io.observe(el);
    });
  }

  function initCompare(root) {
    $$('[data-compare]', root).forEach(function (c) {
      var range = $('input[type=range]', c); if (!range || range._es) return; range._es = true;
      function set() { c.style.setProperty('--pos', range.value + '%'); }
      range.addEventListener('input', set); set();
    });
  }

  function initGlow(root) {
    var cards = $$('.es-glow', root);
    cards.forEach(function (card) {
      card.addEventListener('pointermove', function (e) {
        var r = card.getBoundingClientRect();
        card.style.setProperty('--mx', (e.clientX - r.left) + 'px'); card.style.setProperty('--my', (e.clientY - r.top) + 'px');
      });
    });
    // Sur écran tactile, la carte au centre de l'écran s'illumine.
    if (!('IntersectionObserver' in window) || window.matchMedia('(hover: hover)').matches) return;
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { e.target.classList.toggle('is-lit', e.isIntersecting); }); }, { rootMargin: '-35% 0px -35% 0px' });
    cards.forEach(function (c) { io.observe(c); });
  }

  /* ---------- Frise d'étapes, texte en courbe, vidéos verticales ---------- */
  var timelines = [], curves = [], curveT0 = 0;
  function initNarrative(root) {
    timelines = $$('[data-timeline]').map(function (el) { return { el: el, steps: $$('[data-timeline-step]', el) }; });
    curves = $$('[data-curve-text]').map(function (tp) {
      var path = document.getElementById((tp.getAttribute('href') || '').slice(1));
      var text = tp.parentNode; var rep = 50;
      try { rep = (text.getComputedTextLength() / 8) / path.getTotalLength() * 100; } catch (e) {}
      return { tp: tp, rep: rep > 0 && rep < 100 ? rep : 50 };
    });
    if (curves.length && motion && !curveT0) {
      curveT0 = performance.now();
      (function loop(t) {
        var base = (t - curveT0) / 1000 * 2.2 + lastScrollBoost;
        curves.forEach(function (c) { c.tp.setAttribute('startOffset', (-(base % c.rep)).toFixed(3) + '%'); });
        requestAnimationFrame(loop);
      })(curveT0);
    }
    $$('[data-reels]', root).forEach(initReels);
  }
  var lastScrollBoost = 0;
  function narrativeOnScroll() {
    var vh = window.innerHeight;
    lastScrollBoost = window.scrollY / 40;
    timelines.forEach(function (t) {
      var r = t.el.getBoundingClientRect();
      var p = Math.min(1, Math.max(0, (vh * 0.6 - r.top) / Math.max(1, r.height)));
      t.el.style.setProperty('--tl', p.toFixed(3));
      t.steps.forEach(function (s) { s.classList.toggle('is-lit', !motion || s.getBoundingClientRect().top < vh * 0.62); });
    });
  }
  function initReels(section) {
    if (section._es) return; section._es = true;
    var track = $('[data-reels-track]', section), items = $$('[data-reel]', section), bar = $('[data-reels-progress]', section);
    if (!track || !items.length) return;
    items.forEach(function (it) {
      var v = $('video', it); if (!v) return;
      v.muted = true; v.loop = true; v.playsInline = true;
      var snd = $('[data-reel-sound]', it), play = $('[data-reel-play]', it);
      snd && snd.addEventListener('click', function () { v.muted = !v.muted; snd.setAttribute('aria-pressed', String(!v.muted)); snd.setAttribute('aria-label', v.muted ? (strings.unmute || 'Unmute') : (strings.mute || 'Mute')); });
      play && play.addEventListener('click', function () { if (v.paused) { v.play().catch(function () {}); play.classList.remove('is-paused'); it._userPaused = false; } else { v.pause(); play.classList.add('is-paused'); it._userPaused = true; } });
    });
    function update() {
      var c = track.scrollLeft + track.clientWidth / 2, best = null, bd = 1e9;
      items.forEach(function (it) { var d = Math.abs(it.offsetLeft + it.offsetWidth / 2 - c); if (d < bd) { bd = d; best = it; } });
      items.forEach(function (it) {
        var v = $('video', it); it.classList.toggle('is-active', it === best);
        if (!v) return;
        if (it === best && !it._userPaused && !reduce) v.play().catch(function () {}); else v.pause();
      });
      if (bar) { var max = track.scrollWidth - track.clientWidth; bar.style.setProperty('--p', (max > 0 ? 15 + 85 * track.scrollLeft / max : 100) + '%'); }
    }
    track.addEventListener('scroll', function () { requestAnimationFrame(update); }, { passive: true });
    // Sur grand écran, la vidéo du milieu est centrée d'emblée (pas de vide à gauche de la première).
    var mid = items[Math.floor((items.length - 1) / 2)];
    if (items.length > 2 && window.innerWidth >= 750) track.scrollLeft = Math.max(0, mid.offsetLeft + mid.offsetWidth / 2 - track.clientWidth / 2);
    // Centre la première vidéo et ne lit qu'à l'écran.
    if ('IntersectionObserver' in window) new IntersectionObserver(function (es) { if (es[0].isIntersecting) update(); else items.forEach(function (it) { var v = $('video', it); v && v.pause(); }); }, { threshold: 0.3 }).observe(track);
    update();
  }

  /* Téléphone : les boutons flottants (contact, haut de page) s'effacent tant qu'un bouton d'achat ou un formulaire
     est à l'écran — un élément fixe ne masque jamais l'action principale. */
  function initFabAvoid() {
    var fab = $('.es-fab');
    if (!fab || !('IntersectionObserver' in window)) return;
    var seen = new Set();
    var mq = window.matchMedia('(max-width: 749px)');
    var apply = function () { fab.classList.toggle('is-avoiding', mq.matches && seen.size > 0); };
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) seen.add(e.target); else seen.delete(e.target); });
      apply();
    }, { rootMargin: '0px 0px -40px 0px' });
    $$('[data-add-button], .es-sticky-buy .es-button, main form button[type=submit], .es-footer__inline, .es-product__thumbs, .ed-opening__copy, .es-hero__copy, .cv-banner__copy').forEach(function (el) { io.observe(el); });
    if (mq.addEventListener) mq.addEventListener('change', apply);
  }

  /* ---------- Calendrier de réservation ----------
     Jours ouverts, fermetures, délai minimum et horizon réglés dans la section ; créneaux entre l'ouverture et la
     fermeture (pause exclue, créneaux passés masqués). Les champs date / heure natifs restent la source envoyée. */
  function initBookingCal(root) {
    $$('[data-booking-cal]', root).forEach(function (box) {
      if (box.__bcal) return; box.__bcal = true;
      var lang = doc.lang || undefined;
      var A = function (k) { return box.getAttribute('data-' + k) || ''; };
      var mins = function (v) { var m = /^(\d{1,2})\s*[:hH]\s*(\d{2})?$/.exec((v || '').trim()); return m ? (+m[1]) * 60 + (+(m[2] || 0)) : null; };
      var hhmm = function (m) { return ('0' + Math.floor(m / 60)).slice(-2) + ':' + ('0' + (m % 60)).slice(-2); };
      var iso = function (d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); };
      var days = A('days').split(',').filter(Boolean).map(Number);
      var closed = A('closed').split(',').filter(Boolean);
      var open = mins(A('open')), close = mins(A('close'));
      if (open == null) open = 9 * 60; if (close == null || close <= open) close = 18 * 60;
      var bs = mins(A('break-start')), be = mins(A('break-end'));
      var slot = Math.max(5, parseInt(A('slot'), 10) || 60);
      var today = new Date(); today.setHours(0, 0, 0, 0);
      var first = new Date(today); first.setDate(first.getDate() + (parseInt(A('notice'), 10) || 0));
      var last = new Date(today); last.setDate(last.getDate() + (parseInt(A('horizon'), 10) || 90));
      var form = box.closest('form');
      var when = $('.es-bcal__when', box), cal = $('[data-bcal-calendar]', box), slotsBox = $('[data-bcal-slots]', box);
      var dayLabel = $('[data-bcal-day-label]', box);
      var dateIn = $('[data-bcal-date]', box), timeIn = $('[data-bcal-time]', box), people = $('[data-bcal-people]', box);
      var err = $('[data-bcal-error]', box);
      if (!cal || !dateIn || !timeIn) return;
      dateIn.min = iso(first); dateIn.max = iso(last);
      function slotsFor(d) {
        var out = [], now = new Date(), isToday = iso(d) === iso(now), nowM = now.getHours() * 60 + now.getMinutes();
        for (var m = open; m + slot <= close; m += slot) {
          if (bs != null && be != null && m < be && m + slot > bs) continue;
          if (isToday && m <= nowM) continue;
          out.push(m);
        }
        return out;
      }
      function isOpen(d) { return d >= first && d <= last && days.indexOf(d.getDay()) !== -1 && closed.indexOf(iso(d)) === -1 && slotsFor(d).length > 0; }
      // Premier mois affiché : celui du premier jour réservable.
      var view = new Date(first.getFullYear(), first.getMonth(), 1);
      for (var probe = new Date(first), n = 0; n < 400 && probe <= last; n++, probe.setDate(probe.getDate() + 1)) if (isOpen(probe)) { view = new Date(probe.getFullYear(), probe.getMonth(), 1); break; }
      var picked = null;
      function renderMonth() {
        var y = view.getFullYear(), mo = view.getMonth();
        var title = view.toLocaleDateString(lang, { month: 'long', year: 'numeric' });
        var monday = new Date(2024, 0, 1); // un lundi
        var html = '<div class="es-bcal__cal-head"><button type="button" class="es-bcal__nav" data-nav="-1" aria-label="' + A('label-prev') + '"' + (new Date(y, mo, 1) <= new Date(first.getFullYear(), first.getMonth(), 1) ? ' disabled' : '') + '>‹</button>'
          + '<span class="es-bcal__cal-title" aria-live="polite">' + title + '</span>'
          + '<button type="button" class="es-bcal__nav" data-nav="1" aria-label="' + A('label-next') + '"' + (new Date(y, mo + 1, 1) > last ? ' disabled' : '') + '>›</button></div><div class="es-bcal__grid" role="grid">';
        for (var i = 0; i < 7; i++) { var wd = new Date(monday); wd.setDate(monday.getDate() + i); html += '<span class="es-bcal__dow" aria-hidden="true">' + wd.toLocaleDateString(lang, { weekday: 'short' }).replace('.', '') + '</span>'; }
        var lead = (new Date(y, mo, 1).getDay() + 6) % 7;
        for (i = 0; i < lead; i++) html += '<span></span>';
        var count = new Date(y, mo + 1, 0).getDate();
        for (var d = 1; d <= count; d++) {
          var dt = new Date(y, mo, d), ok = isOpen(dt), id = iso(dt);
          html += '<button type="button" class="es-bcal__day' + (id === iso(today) ? ' is-today' : '') + '" data-day="' + id + '" aria-pressed="' + (picked === id) + '" aria-label="' + dt.toLocaleDateString(lang, { weekday: 'long', day: 'numeric', month: 'long' }) + '"' + (ok ? '' : ' disabled') + '>' + d + '</button>';
        }
        cal.innerHTML = html + '</div>';
      }
      function renderSlots() {
        slotsBox.innerHTML = '';
        if (!picked) { dayLabel.textContent = A('label-pick-date'); return; }
        var parts = picked.split('-'), d = new Date(+parts[0], +parts[1] - 1, +parts[2]);
        var list = slotsFor(d);
        var dayText = d.toLocaleDateString(lang, { weekday: 'long', day: 'numeric', month: 'long' });
        dayLabel.textContent = list.length ? dayText.charAt(0).toUpperCase() + dayText.slice(1) : A('label-no-slot');
        list.forEach(function (m) {
          var b = document.createElement('button');
          b.type = 'button'; b.className = 'es-bcal__slot'; b.textContent = hhmm(m); b.setAttribute('data-slot', hhmm(m));
          b.setAttribute('aria-pressed', String(timeIn.value === hhmm(m)));
          slotsBox.appendChild(b);
        });
      }
      function sum(key, val) { var el = $('[data-bcal-sum="' + key + '"]', box); if (el) el.textContent = val || '—'; }
      function update() {
        var item = $('[data-bcal-item]:checked', box);
        sum('item', item && item.value);
        if (picked) { var p = picked.split('-'); sum('date', new Date(+p[0], +p[1] - 1, +p[2]).toLocaleDateString(lang, { weekday: 'short', day: 'numeric', month: 'long' })); } else sum('date', '');
        sum('time', timeIn.value);
        var dur = $('[data-bcal-duration]', box); if (dur) sum('duration', dur.value);
        if (people) sum('people', people.value);
        sum('options', $$('[data-bcal-option]:checked', box).map(function (o) { return o.getAttribute('data-bcal-option'); }).join(', '));
        // Capacité : une salle trop petite pour le nombre de personnes n'est plus proposée.
        var n = people ? parseInt(people.value, 10) || 0 : 0;
        $$('.es-bcal__item', box).forEach(function (card) {
          var cap = parseInt(card.getAttribute('data-capacity'), 10) || 0, full = cap > 0 && n > cap;
          var r = $('[data-bcal-item]', card);
          card.classList.toggle('is-full', full); r.disabled = full; if (full && r.checked) r.checked = false;
          var note = $('[data-bcal-full]', card); if (note) note.hidden = !full;
        });
      }
      when.classList.add('is-enhanced');
      // Les champs natifs masqués ne bloquent plus l'envoi : la vérification se fait ci-dessous, avec un message clair.
      dateIn.required = false; timeIn.required = false;
      renderMonth(); renderSlots(); update();
      cal.addEventListener('click', function (e) {
        var nav = e.target.closest('[data-nav]');
        if (nav && !nav.disabled) { view = new Date(view.getFullYear(), view.getMonth() + (+nav.getAttribute('data-nav')), 1); renderMonth(); return; }
        var day = e.target.closest('[data-day]'); if (!day || day.disabled) return;
        picked = day.getAttribute('data-day'); dateIn.value = picked; timeIn.value = '';
        renderMonth(); renderSlots(); update();
        var firstSlot = $('.es-bcal__slot', slotsBox); if (firstSlot && window.matchMedia('(max-width: 749px)').matches) slotsBox.scrollIntoView({ block: 'nearest', behavior: reduce ? 'auto' : 'smooth' });
      });
      slotsBox.addEventListener('click', function (e) {
        var b = e.target.closest('[data-slot]'); if (!b) return;
        timeIn.value = b.getAttribute('data-slot');
        $$('.es-bcal__slot', slotsBox).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
        if (err) err.hidden = true;
        update();
      });
      $$('[data-bcal-people-step]', box).forEach(function (b) {
        b.addEventListener('click', function () {
          var min = parseInt(people.min, 10) || 1, max = parseInt(people.max, 10) || 999;
          people.value = String(Math.min(max, Math.max(min, (parseInt(people.value, 10) || min) + (+b.getAttribute('data-bcal-people-step')))));
          update();
        });
      });
      box.addEventListener('change', update);
      box.addEventListener('input', update);
      if (form) form.addEventListener('submit', function (e) {
        if (dateIn.value && timeIn.value) return;
        e.preventDefault();
        if (err) { err.textContent = A('label-missing'); err.hidden = false; }
        cal.scrollIntoView({ block: 'center', behavior: reduce ? 'auto' : 'smooth' });
      });
    });
  }

  function init() {
    initBookingCal(document);
    initWords(document);
    initReveal(document);
    initParallax();
    initScrollEffects();
    initCounters(document);
    initCompare(document);
    initGlow(document);
    initNarrative(document);
    if ($('.es-sticky-buy')) document.body.classList.add('has-sticky-buy');
    initMenu();
    initCart();
    initBuy(document);
    initOffers(document);
    initEta(document);
    initGallery();
    initStickyBuy();
    initFabAvoid();
    initStory();
    initRoutine();
    initHGallery();
    initVideos();
    initMisc();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    onScroll();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  /* Éditeur de thème Shopify : réinitialise les sections rechargées. */
  document.addEventListener('shopify:section:load', function (e) { initBookingCal(e.target); initNarrative(e.target); initWords(e.target); initCounters(e.target); initCompare(e.target); initGlow(e.target); initScrollEffects(); initReveal(e.target); initBuy(e.target); initOffers(e.target); initEta(e.target); initStory(); initRoutine(); initHGallery(); initParallax(); initVideos(); initGallery(); });
})();

;
/* Offres : sélection seulement. Le serveur d'aperçu ou la plateforme décide du prix du panier. */
(function () {
 'use strict';
 function init(root) {
  root.querySelectorAll('[data-purchase]').forEach(function (box) {
   if (box.dataset.ready) return; box.dataset.ready = 'true';
   var variants = JSON.parse(box.querySelector('[data-purchase-variants]').textContent), strings = JSON.parse(box.querySelector('[data-purchase-strings]').textContent);
   var radios = Array.from(box.querySelectorAll('.purchase__offers input[type=radio]')), selected = radios.find(function (r) { return r.checked; }) || radios[0], retained = [], area = box.querySelector('[data-offer-variants]'), button = box.querySelector('[data-purchase-add]'), error = box.querySelector('[data-purchase-error]');
   if (!selected) return;
   var params=new URLSearchParams(location.search),requestedVariant=params.get('variant'),requestedOffer=params.get('offer');if(variants.some(function(v){return String(v.id)===requestedVariant&&v.available;}))retained[0]=requestedVariant;
   if(requestedOffer){var wanted=radios.find(function(r){return r.value===requestedOffer;});if(wanted)selected=wanted;}
   function money(n) { return new Intl.NumberFormat(box.dataset.language || 'fr', { style: 'currency', currency: box.dataset.currency || 'EUR' }).format(n / 100); }
   function priceFor(r) {
    var count = +r.dataset.quantity, sum = 0, ref = 0;
    for (var i = 0; i < count; i++) { var v = variants.find(function (v) { return String(v.id) === retained[i]; }) || variants.find(function (v) { return v.available; }) || variants[0]; if (v.price == null) return null; sum += v.price; ref += v.compare_at_price && v.compare_at_price > v.price ? v.compare_at_price : v.price; }
    var total = r.hasAttribute('data-fixed-total') ? +r.dataset.fixedTotal : Math.round(sum * (100 - +r.dataset.discount) / 100);
    if (!Number.isSafeInteger(total) || total < 0) return null;
    return { base: sum, ref: ref, total: total, count: count };
   }
   function update() {
    retained = Array.from(area.querySelectorAll('select')).map(function (s) { return s.value; });
    radios.forEach(function (r) { var p = priceFor(r), card = r.closest('label'); card.classList.toggle('is-selected', r === selected); card.querySelector('[data-offer-total]').textContent = p ? money(p.total) : strings.unavailable; card.querySelector('[data-offer-unit]').textContent = p ? money(Math.round(p.total / p.count)) + ' ' + strings.unit : ''; var save = card.querySelector('[data-offer-saving]'); save.hidden = !p || p.ref <= p.total; save.textContent = p && p.ref > p.total ? strings.save + ' ' + money(p.ref - p.total) : ''; var compare = card.querySelector('[data-offer-compare]'); if (compare) { compare.hidden = !p || p.ref <= p.total; compare.textContent = p && p.ref > p.total ? money(p.ref) : ''; } });
    var p = priceFor(selected); box.querySelector('[data-purchase-total]').textContent = p ? money(p.total) : strings.unavailable;
    var selectedLabel = (selected.closest('label').querySelector('.purchase__offer-copy>strong') || {}).textContent || '';
    var summaryLabel = box.querySelector('[data-purchase-summary-label]'), unitNode = box.querySelector('[data-purchase-unit-price]');
    if (summaryLabel && strings.total) summaryLabel.textContent = strings.total + (selectedLabel ? ' · ' + selectedLabel : '');
    if (unitNode) unitNode.textContent = p ? money(Math.round(p.total / p.count)) + ' ' + strings.unit + (p.count > 1 ? ' × ' + p.count : '') : '';
    var counts = {}; retained.forEach(function(id) { counts[id] = (counts[id] || 0) + 1; });
    button.disabled = !p || !retained.length || retained.some(function (id) { var v = variants.find(function (v) { return String(v.id) === id; }); return !v || !v.available || (v.inventory_management && v.inventory_quantity < counts[id]); });
    box.querySelectorAll('[data-gift]').forEach(function (g) { var eligible = +selected.dataset.quantity >= +g.dataset.threshold, available = g.dataset.available === 'true' && (!g.dataset.stock || +g.dataset.stock >= +g.dataset.giftQuantity); g.classList.toggle('is-unlocked', eligible && available); g.querySelector('[data-gift-state]').textContent = !available ? strings.unavailable : eligible ? strings.included : strings.locked + ' ' + g.dataset.threshold + ' ' + strings.items; });
    box.dispatchEvent(new CustomEvent('es:offer-total',{bubbles:true,detail:{total:p?money(p.total):strings.unavailable,unit:p?money(Math.round(p.total/p.count))+' '+strings.unit:'',count:p?p.count:0,offer:selected.value,label:selectedLabel,ready:!button.disabled}}));
   }
   function announce() { var v = variants.find(function(v){return String(v.id)===retained[0];}); box.dispatchEvent(new CustomEvent('es:offer-variant',{bubbles:true,detail:v})); box.querySelectorAll('[data-finish-id]').forEach(function(r){r.checked=r.value===retained[0];}); }
   var finishes=box.querySelector('[data-purchase-finishes]'),colorNode=box.querySelector('[data-purchase-colors]'),colors={};
   if(colorNode) String(JSON.parse(colorNode.textContent)||'').split(/\n/).forEach(function(line){var cut=line.lastIndexOf('=');if(cut>0&&/^#[0-9a-f]{6}$/i.test(line.slice(cut+1).trim()))colors[line.slice(0,cut).trim()]=line.slice(cut+1).trim();});
   if(finishes)finishes.className='purchase__finish-options';
   if(finishes) variants.forEach(function(v){var label=document.createElement('label'),input=document.createElement('input'),dot=document.createElement('i'),text=document.createElement('span');label.className='purchase__finish';dot.className='purchase__swatch';input.type='radio';input.name='finish-'+radios[0].name;input.value=v.id;input.dataset.finishId=v.id;input.disabled=!v.available;dot.setAttribute('aria-hidden','true');if(colors[v.title])dot.style.backgroundColor=colors[v.title];text.textContent=v.title;label.append(input,dot,text);finishes.append(label);input.addEventListener('change',function(){retained=Array.from(area.querySelectorAll('select')).map(function(s){return s.value;});retained[0]=String(v.id);choose();announce();});});
   function choose() {
    area.replaceChildren(); selected.checked = true; var variantBox = box.querySelector('.purchase__variants'); if (variantBox) variantBox.hidden = variants.length < 2;
    for (var i = 0; i < +selected.dataset.quantity; i++) {
     var label = document.createElement('label'), select = document.createElement('select'), span = document.createElement('span'); span.textContent = (i + 1) + ' / ' + selected.dataset.quantity; label.append(span, select);
     variants.forEach(function (v) { var option = document.createElement('option'); option.value = v.id; option.textContent = v.title + (!v.available ? ' — ' + strings.unavailable : ''); option.disabled = !v.available; select.append(option); });
     select.value = retained[i] || String((variants.find(function (v) { return v.available; }) || variants[0]).id); select.addEventListener('change', function(){update();announce();}); area.append(label);
    }
    update();announce();
   }
   radios.forEach(function (r) { r.addEventListener('change', function () { selected = r; choose(); }); }); choose();
   button.addEventListener('click', function () {
    error.hidden = true; button.disabled = true; button.setAttribute('aria-busy', 'true');
    var nativeItems = []; retained.forEach(function (id) { var line = nativeItems.find(function (item) { return item.id === +id; }); if (line) line.quantity++; else nativeItems.push({ id: +id, quantity: 1 }); });
    var payload = box.dataset.preview === 'true' ? { offer: selected.value, target: box.dataset.target, variants: retained.map(Number) } : { items: nativeItems };
    fetch(box.dataset.addUrl + '.js', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload) }).then(function (r) { return r.json().then(function (data) { if (!r.ok) throw new Error(data.description || data.error || strings.unavailable); return data; }); }).then(function () { window.location.assign(box.dataset.cartUrl); }).catch(function (e) { error.textContent = e.message; error.hidden = false; }).finally(function () { button.removeAttribute('aria-busy'); update(); });
   });
  });
 }
 if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(document); }); else init(document);
 document.addEventListener('shopify:section:load', function (e) { init(e.target); });
})();

;
/* Chapitres natifs <details> : clavier et contenu restent utilisables sans JavaScript. */
(function () {
 function init(root) { root.querySelectorAll('[data-narrative]').forEach(function (box) {
  if (box.dataset.ready) return; box.dataset.ready = 'true';
  var chapters = Array.from(box.querySelectorAll('[data-narrative-chapter]'));
  chapters.forEach(function (chapter) { chapter.addEventListener('toggle', function () {
   if (!chapter.open) return;
   chapters.forEach(function (other) { if (other !== chapter) other.open = false; });
   box.querySelectorAll('[data-narrative-image]').forEach(function (image) { image.hidden = image.dataset.narrativeImage !== chapter.dataset.narrativeChapter; });
  }); });
 }); }
 if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(document); }); else init(document);
 document.addEventListener('shopify:section:load', function (e) { init(e.target); });
})();

;
/* Mouvement éditorial borné et formulaire de démonstration explicitement autorisé. */
(function(){'use strict';
 var reduced=window.matchMedia('(prefers-reduced-motion: reduce)'),animations=[];
 function moving(el){var section=el.closest('[data-ed-motion]');return document.body.classList.contains('motion-on')&&!reduced.matches&&(!section||section.dataset.edMotion!=='none');}
 function animate(el,frames,options){if(!moving(el)||!el.animate)return;var a=el.animate(frames,options);animations.push(a);a.finished.catch(function(){});}
 function init(root){
  root.querySelectorAll('[data-ed-title]').forEach(function(title){if(title.dataset.edReady)return;title.dataset.edReady='true';var lines=title.innerText.split(/\n/).filter(Boolean);title.replaceChildren();lines.forEach(function(text,i){var line=document.createElement('span');line.style.display='block';line.textContent=i<lines.length-1?text+' ':text;title.append(line);animate(line,[{opacity:0,transform:'translateY(16px)'},{opacity:1,transform:'translateY(0)'}],{duration:document.body.dataset.editorial==='journal'?650:600,delay:i*70,easing:'cubic-bezier(.22,.61,.36,1)',fill:'backwards'});});});
  var observer=window.IntersectionObserver?new IntersectionObserver(function(entries){entries.forEach(function(entry){if(!entry.isIntersecting)return;var el=entry.target;observer.unobserve(el);animate(el,[{opacity:.15,transform:'translateY(14px)'},{opacity:1,transform:'translateY(0)'}],{duration:550,easing:'cubic-bezier(.22,.61,.36,1)'});});},{threshold:.12}):null;
  root.querySelectorAll('.ed-section:not(.ed-opening) .ed-title,.ed-diptych__frame,.ed-scene__media,.fp__media,.fp__body,.ed-points li').forEach(function(el){if(observer&&moving(el))observer.observe(el);});
  root.querySelectorAll('.ed-opening__media .ed-media').forEach(function(el){if(window.innerWidth<750&&document.body.dataset.editorial==='journal')return;animate(el,[{transform:document.body.dataset.editorial==='journal'?'scale(.96)':'scale(1.03)'},{transform:'scale(1)'}],{duration:800,easing:'cubic-bezier(.22,.61,.36,1)'});});
  /* Déplacement léger (16–24 px) d'une photographie au défilement : jamais de verrouillage, désactivable (motion « none » ou réduction du mouvement). */
  var drifting=Array.from(root.querySelectorAll('[data-ed-motion="drift"] .ed-scene__media .ed-media, [data-ed-motion="drift"] .ed-opening__media .ed-media')).filter(function(el){return !el.dataset.edDrift&&moving(el)&&window.innerWidth>=750;});
  if(drifting.length){drifting.forEach(function(el){el.dataset.edDrift='true';el.style.willChange='transform';});var ticking=false;function drift(){ticking=false;var vh=window.innerHeight;drifting.forEach(function(el){var r=el.parentElement.getBoundingClientRect();if(r.bottom<0||r.top>vh)return;var progress=(r.top+r.height/2-vh/2)/(vh/2+r.height/2);var y=Math.max(-1,Math.min(1,progress))*-20;el.style.transform='translate3d(0,'+y.toFixed(1)+'px,0) scale(1.06)';});}
   window.addEventListener('scroll',function(){if(!ticking){ticking=true;requestAnimationFrame(drift);}},{passive:true});drift();}
  root.querySelectorAll('[data-ed-comparison]').forEach(function(el){var range=el.querySelector('[data-ed-range]');if(range)range.addEventListener('input',function(){el.style.setProperty('--ed-compare',range.value+'%');});});
  root.querySelectorAll('[data-ed-finishes]').forEach(function(el){el.querySelectorAll('[data-finish-view]').forEach(function(view){view.addEventListener('click',function(){var input=el.querySelector('input[type=radio][value="'+view.dataset.finishView+'"]');if(input&&!input.checked){input.checked=true;input.dispatchEvent(new Event('change',{bubbles:true}));}});});el.querySelectorAll('input[type=radio]').forEach(function(radio){radio.addEventListener('change',function(){el.querySelectorAll('[data-finish-view]').forEach(function(view){view.classList.toggle('is-active',view.dataset.finishView===radio.value);});var link=el.querySelector('[data-finish-link]');if(link){var url=new URL(link.href);url.searchParams.set('variant',radio.value);link.href=url.href;}var primary=document.querySelector('[data-purchase-finishes] input[value="'+radio.value+'"]');if(primary){primary.checked=true;primary.dispatchEvent(new Event('change',{bubbles:true}));}});});});
  var requested=new URLSearchParams(location.search).get('media');if(requested&&/^[a-z0-9-]{1,80}$/.test(requested)){var slides=Array.from(root.querySelectorAll('[data-main-product] [data-media-id]')),index=slides.findIndex(function(slide){var img=slide.querySelector('img');return img&&(img.getAttribute('src')||'').includes(requested);}),thumb=root.querySelector('[data-gallery-go="'+index+'"]');if(thumb)thumb.click();}
  /* Produit à la une : galerie à fondu croisé, vignettes, variante sélectionnée → son visuel, lien vers la fiche avec la sélection. */
  root.querySelectorAll('[data-featured-purchase]').forEach(function(section){
   if(section.dataset.fpReady)return;section.dataset.fpReady='true';
   var slides=Array.from(section.querySelectorAll('[data-fp-slide]')),thumbs=Array.from(section.querySelectorAll('[data-fp-go]')),link=section.querySelector('[data-fp-link]');
   function show(id,focusThumb){var target=slides.find(function(s){return s.dataset.mediaId===id;});if(!target||!target.hidden)return;slides.forEach(function(s){s.hidden=s!==target;});thumbs.forEach(function(t){var on=t.dataset.fpGo===id;t.classList.toggle('is-active',on);if(on)t.setAttribute('aria-current','true');else t.removeAttribute('aria-current');});var img=target.querySelector('img');if(img)animate(img,[{opacity:.35},{opacity:1}],{duration:200,easing:'ease-out'});if(focusThumb){var t=thumbs.find(function(x){return x.dataset.fpGo===id;});if(t)t.focus();}}
   thumbs.forEach(function(t,i){t.addEventListener('click',function(){show(t.dataset.fpGo,false);});t.addEventListener('keydown',function(e){if(e.key!=='ArrowRight'&&e.key!=='ArrowLeft')return;e.preventDefault();var next=thumbs[(i+(e.key==='ArrowRight'?1:thumbs.length-1))%thumbs.length];show(next.dataset.fpGo,true);});});
   section.addEventListener('es:offer-variant',function(e){var v=e.detail;if(!v)return;if(v.featured_media)show(String(v.featured_media.id),false);if(link){var url=new URL(link.href,location.href);url.searchParams.set('variant',v.id);link.href=url.href;}});
   section.addEventListener('es:offer-total',function(e){if(!link||!e.detail)return;var url=new URL(link.href,location.href);url.searchParams.set('offer',e.detail.offer);link.href=url.href;});
  });
  /* Barre d'achat fixe sur mobile : visible quand le vrai bouton est hors écran. Son bouton ajoute réellement la sélection valide par le parcours existant (même requête, mêmes contrôles de stock, de prix serveur et de cadeau) ; si la sélection n'est pas prête, il conduit aux options. Prix unitaire et total affichés et synchronisés ; cachée si un dialogue ou le panier est ouvert ; espace réservé. */
  root.querySelectorAll('[data-main-product] [data-purchase]').forEach(function(box){
   if(box.dataset.barReady||!window.IntersectionObserver)return;box.dataset.barReady='true';
   var button=box.querySelector('[data-purchase-add]'),strings=JSON.parse(box.querySelector('[data-purchase-strings]').textContent||'{}');if(!button)return;
   var bar=document.createElement('div');bar.className='purchase-bar';bar.hidden=true;bar.setAttribute('data-purchase-bar','');
   var meta=document.createElement('p');meta.className='purchase-bar__meta';var line=document.createElement('span');line.setAttribute('data-bar-line','');var total=document.createElement('strong');total.setAttribute('data-bar-total','');meta.append(line,total);
   var go=document.createElement('button');go.type='button';go.className='es-button purchase-bar__button';go.setAttribute('data-purchase-bar-add','');
   bar.append(meta,go);box.closest('[data-main-product]').append(bar);
   /* La barre ne recouvre jamais la galerie (visuel et vignettes) : tant qu'une partie de la galerie est à l'écran, elle reste cachée, même sur une petite hauteur (360 × 560). */
   var galleryEl=box.closest('[data-main-product]').querySelector('.es-product__gallery'),galleryVisible=false;
   var visible=true,state={ready:false,busy:false};
   function read(){var checked=box.querySelector('.purchase__offers input:checked'),fin=box.querySelector('[data-finish-id]:checked'),tot=box.querySelector('[data-purchase-total]'),unit=box.querySelector('[data-purchase-unit-price]');
    var label=checked&&checked.closest('label').querySelector('.purchase__offer-copy>strong')?checked.closest('label').querySelector('.purchase__offer-copy>strong').textContent:'';
    line.textContent=[label,fin?fin.parentElement.textContent.trim():'',unit?unit.textContent.split(' × ')[0]:''].filter(Boolean).join(' · ');total.textContent=(strings.total?strings.total+' ':'')+(tot?tot.textContent:'');
    state.ready=!button.disabled;state.busy=button.getAttribute('aria-busy')==='true';go.textContent=state.ready?button.textContent:(strings.choose_options||button.textContent);go.classList.toggle('purchase-bar__button--guide',!state.ready);go.disabled=state.busy;}
   go.addEventListener('click',function(){if(state.busy)return;if(state.ready){button.click();}else{box.scrollIntoView({behavior:reduced.matches?'auto':'smooth',block:'start'});var first=box.querySelector('.purchase__offers input:checked')||box.querySelector('.purchase__offers input');if(first)first.focus({preventScroll:true});}});
   function render(){var open=document.querySelector('dialog[open],.es-cart-drawer.is-open,.es-mobile-menu.is-open');var show=!visible&&!galleryVisible&&!open&&window.innerWidth<990;if(bar.hidden===show)bar.hidden=!show;if(document.body.classList.contains('has-purchase-bar')!==show)document.body.classList.toggle('has-purchase-bar',show);}
   read();
   box.addEventListener('es:offer-total',function(){read();render();});box.addEventListener('es:offer-variant',read);
   new MutationObserver(read).observe(button,{attributes:true,attributeFilter:['disabled','aria-busy']});
   new IntersectionObserver(function(entries){entries.forEach(function(entry){visible=entry.isIntersecting||entry.boundingClientRect.top<0&&entry.boundingClientRect.bottom>0;if(entry.boundingClientRect.top>window.innerHeight)visible=false;});render();},{threshold:0}).observe(button);
   if(galleryEl)new IntersectionObserver(function(entries){entries.forEach(function(entry){galleryVisible=entry.isIntersecting;});render();},{threshold:0}).observe(galleryEl);
   document.addEventListener('toggle',render,true);window.addEventListener('resize',render);new MutationObserver(function(records){if(records.some(function(r){return r.target!==bar&&r.target!==go&&r.target!==document.body&&r.target!==button;}))render();}).observe(document.body,{attributes:true,attributeFilter:['class','open','hidden'],subtree:true});
  });
  root.querySelectorAll('[data-ed-contact][data-preview-test=true]').forEach(function(wrap){var form=wrap.querySelector('form');if(!form||form.dataset.demoContact)return;form.dataset.demoContact='true';form.addEventListener('submit',function(e){e.preventDefault();var button=form.querySelector('button[type=submit]'),status=form.querySelector('[data-contact-status]');if(button.disabled)return;button.disabled=true;button.setAttribute('aria-busy','true');status.textContent='';var data=Object.fromEntries(new FormData(form).entries());data.submission_id=form.dataset.submissionId||(form.dataset.submissionId=crypto.randomUUID());fetch(form.action,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(data)}).then(function(r){return r.json().then(function(data){if(!r.ok)throw new Error(data.error||data.description||wrap.dataset.errorMessage);return data;});}).then(function(data){status.textContent=data.message;status.dataset.receipt=data.id;delete form.dataset.submissionId;}).catch(function(error){status.textContent=error.message;status.setAttribute('tabindex','-1');status.focus();}).finally(function(){button.disabled=false;button.removeAttribute('aria-busy');});});});
 }
 document.addEventListener('es:offer-variant',function(e){var section=e.target.closest('[data-main-product]'),v=e.detail;if(!section||!v||!v.featured_media)return;var slides=Array.from(section.querySelectorAll('[data-media-id]')),index=slides.findIndex(function(s){return s.dataset.mediaId===String(v.featured_media.id);}),thumb=section.querySelector('[data-gallery-go="'+index+'"]');if(thumb){thumb.click();var image=slides[index].querySelector('img');if(image)animate(image,[{opacity:.4},{opacity:1}],{duration:180});}});
 if(reduced.addEventListener)reduced.addEventListener('change',function(){if(reduced.matches)animations.forEach(function(a){a.cancel();});});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){init(document);});else init(document);
 document.addEventListener('shopify:section:load',function(e){init(e.target);});
})();

;
/* Profil « conversion » : carrousels (avis, stories), lecteur de stories, panier (compte à rebours de démonstration,
   code de réduction, interrupteur de protection). Aucune donnée n'est inventée ici : les montants viennent du serveur. */
(function () {
  'use strict';
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  /* Carrousel à défilement : flèches, points, clavier (flèches gauche/droite sur la piste). */
  function carousel(root) {
    if (root.dataset.cvReady) return; root.dataset.cvReady = 'true';
    var track = $('[data-cv-track]', root), slides = $$('[data-cv-slide]', root), dots = $$('[data-cv-dot]', root), prev = $('[data-cv-prev]', root), next = $('[data-cv-next]', root);
    if (!track || !slides.length) return;
    var current = 0;
    function width() { var r = slides[0].getBoundingClientRect(); return r.width + 16; }
    function setDots(i) { current = i; dots.forEach(function (d, k) { d.classList.toggle('is-active', k === i); d.setAttribute('aria-selected', k === i ? 'true' : 'false'); }); if (prev) prev.disabled = i === 0; if (next) next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 4; }
    function go(i) { i = Math.max(0, Math.min(slides.length - 1, i)); track.scrollTo({ left: slides[i].offsetLeft - track.offsetLeft, behavior: reduced ? 'auto' : 'smooth' }); setDots(i); }
    var t; track.addEventListener('scroll', function () { clearTimeout(t); t = setTimeout(function () { setDots(Math.round(track.scrollLeft / width())); }, 80); }, { passive: true });
    if (prev) prev.addEventListener('click', function () { go(current - 1); });
    if (next) next.addEventListener('click', function () { go(current + 1); });
    dots.forEach(function (d, k) { d.addEventListener('click', function () { go(k); }); });
    track.addEventListener('keydown', function (e) { if (e.key === 'ArrowRight') { e.preventDefault(); go(current + 1); } else if (e.key === 'ArrowLeft') { e.preventDefault(); go(current - 1); } else if (e.key === 'Home') { e.preventDefault(); go(0); } else if (e.key === 'End') { e.preventDefault(); go(slides.length - 1); } });
    setDots(0);
  }

  /* Lecteur de stories : source chargée à l'ouverture seulement, lecture/pause, son, précédent/suivant, fermeture. */
  function stories(root) {
    var dialog = $('[data-cv-player]', root), video = $('[data-cv-video]', root), buttons = $$('[data-cv-story-open]', root);
    if (!dialog || !video || !buttons.length || typeof dialog.showModal !== 'function') return;
    var index = 0, pause = $('[data-cv-player-pause]', root), sound = $('[data-cv-player-sound]', root), close = $('[data-cv-player-close]', root), prev = $('[data-cv-player-prev]', root), next = $('[data-cv-player-next]', root), title = $('[data-cv-player-title]', root), subtitle = $('[data-cv-player-subtitle]', root), link = $('[data-cv-player-link]', root), opener = null;
    function load(i) {
      index = Math.max(0, Math.min(buttons.length - 1, i)); var b = buttons[index];
      video.pause(); video.removeAttribute('src'); video.load();
      if (b.dataset.poster) video.poster = b.dataset.poster; else video.removeAttribute('poster');
      video.src = b.dataset.src; title.textContent = b.dataset.title || ''; subtitle.textContent = b.dataset.subtitle || '';
      if (b.dataset.link && b.dataset.linkLabel) { link.href = b.dataset.link; link.textContent = b.dataset.linkLabel; link.hidden = false; } else { link.hidden = true; }
      prev.disabled = index === 0; next.disabled = index === buttons.length - 1;
      var p = video.play(); if (p && p.catch) p.catch(function () { setPaused(true); }); else setPaused(false);
    }
    function setPaused(flag) { pause.classList.toggle('is-paused', flag); pause.setAttribute('aria-label', flag ? pause.dataset.labelPlay : pause.dataset.labelPause); }
    video.addEventListener('play', function () { setPaused(false); });
    video.addEventListener('pause', function () { setPaused(true); });
    video.addEventListener('ended', function () { if (index < buttons.length - 1) load(index + 1); else setPaused(true); });
    pause.addEventListener('click', function () { if (video.paused) video.play(); else video.pause(); });
    sound.addEventListener('click', function () { video.muted = !video.muted; sound.setAttribute('aria-pressed', video.muted ? 'false' : 'true'); sound.setAttribute('aria-label', video.muted ? sound.dataset.labelUnmute : sound.dataset.labelMute); });
    prev.addEventListener('click', function () { load(index - 1); });
    next.addEventListener('click', function () { load(index + 1); });
    close.addEventListener('click', function () { dialog.close(); });
    dialog.addEventListener('click', function (e) { if (e.target === dialog) dialog.close(); });
    dialog.addEventListener('keydown', function (e) { if (e.key === 'ArrowRight') load(index + 1); else if (e.key === 'ArrowLeft') load(index - 1); else if (e.key === ' ') { e.preventDefault(); if (video.paused) video.play(); else video.pause(); } });
    dialog.addEventListener('close', function () { video.pause(); video.removeAttribute('src'); video.load(); document.body.style.overflow = ''; if (opener) opener.focus(); });
    buttons.forEach(function (b, k) { b.addEventListener('click', function () { opener = b; dialog.showModal(); document.body.style.overflow = 'hidden'; load(k); }); });
  }

  /* Panier : compte à rebours de démonstration (toujours étiqueté fictif), code de réduction, protection visuelle. */
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function reserve(el) {
    if (el.dataset.cvReady) return; el.dataset.cvReady = 'true';
    var minutes = parseInt(el.dataset.minutes, 10) || 10, key = 'es-cart-reserve', start = 0;
    try { start = parseInt(sessionStorage.getItem(key) || '0', 10); if (!start || Date.now() - start > minutes * 60000) { start = Date.now(); sessionStorage.setItem(key, String(start)); } } catch (e) { start = Date.now(); }
    var text = $('[data-cart-reserve-text]', el), template = el.dataset.template || '%';
    function tick() { var left = Math.max(0, minutes * 60000 - (Date.now() - start)), m = Math.floor(left / 60000), s = Math.floor((left % 60000) / 1000); text.textContent = template.replace('%', m + ' min ' + pad(s) + ' s'); if (left > 0) setTimeout(tick, 1000); }
    tick();
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Enter' && e.target.matches && e.target.matches('[data-cart-discount-input]')) { e.preventDefault(); var b = e.target.closest('[data-cart-discount]').querySelector('[data-cart-discount-apply]'); if (b) b.click(); } });
  document.addEventListener('click', function (e) {
    var apply = e.target.closest && e.target.closest('[data-cart-discount-apply]');
    if (apply) { var box = apply.closest('[data-cart-discount]'), input = $('[data-cart-discount-input]', box), note = $('[data-cart-discount-note]', box), code = (input.value || '').trim(); if (!code) { input.focus(); return; } if (box.dataset.preview === 'true') { note.hidden = false; return; } window.location.href = box.dataset.discountUrl + '/' + encodeURIComponent(code) + '?redirect=' + encodeURIComponent(window.routes && window.routes.cart || '/cart'); return; }
    var toggle = e.target.closest && e.target.closest('[data-cart-protect-toggle]');
    if (toggle) { var on = toggle.getAttribute('aria-checked') !== 'true'; toggle.setAttribute('aria-checked', on ? 'true' : 'false'); var n = $('[data-cart-protect-note]', toggle.closest('[data-cart-protect]')); if (n) n.hidden = !on; }
  });

  /* Points interactifs : un seul ouvert à la fois, fermeture par Échap ou clic hors de la bulle, bulle rabattue près des bords. */
  function hotspots(root) {
    if (root.dataset.cvReady) return; root.dataset.cvReady = 'true';
    var dots = $$('[data-cv-hotspot]', root);
    function closeAll(except) { dots.forEach(function (d) { if (d === except) return; d.setAttribute('aria-expanded', 'false'); var c = document.getElementById(d.getAttribute('aria-controls')); if (c) c.hidden = true; }); }
    dots.forEach(function (d) {
      var card = document.getElementById(d.getAttribute('aria-controls')), spot = d.parentElement;
      d.addEventListener('click', function () { var open = d.getAttribute('aria-expanded') === 'true'; closeAll(d); d.setAttribute('aria-expanded', open ? 'false' : 'true'); if (card) { card.hidden = open; if (!open) { var x = parseFloat(spot.style.getPropertyValue('--x')), y = parseFloat(spot.style.getPropertyValue('--y')); spot.classList.toggle('cv-hotspot--flip', y > 65); spot.classList.toggle('cv-hotspot--left', x < 30); spot.classList.toggle('cv-hotspot--right', x > 70); } } });
      if (card) $$('[data-cv-hotspot-close]', card).forEach(function (b) { b.addEventListener('click', function () { closeAll(); d.focus(); }); });
    });
    root.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeAll(); } });
    document.addEventListener('click', function (e) { if (!root.contains(e.target)) closeAll(); });
  }

  /* Galerie : visionneuse en boîte de dialogue (précédent / suivant, Échap), image chargée à l'ouverture. */
  function gallery(root) {
    var dialog = $('[data-cv-lightbox]', root), img = $('[data-cv-lightbox-img]', root), cap = $('[data-cv-lightbox-caption]', root), opens = $$('[data-cv-gallery-open]', root);
    if (!dialog || !img || !opens.length || typeof dialog.showModal !== 'function') return;
    var index = 0, opener = null;
    function show(i) { index = (i + opens.length) % opens.length; var src = $('img', opens[index]); if (!src) return; img.src = src.currentSrc || src.src; img.alt = src.alt || ''; img.hidden = false; var fig = opens[index].closest('figure'), c = fig && $('figcaption span', fig); cap.textContent = c ? c.textContent : ''; }
    opens.forEach(function (b, k) { b.addEventListener('click', function () { opener = b; show(k); dialog.showModal(); document.body.style.overflow = 'hidden'; }); });
    $$('[data-cv-lightbox-close]', root).forEach(function (b) { b.addEventListener('click', function () { dialog.close(); }); });
    $$('[data-cv-lightbox-prev]', root).forEach(function (b) { b.addEventListener('click', function () { show(index - 1); }); });
    $$('[data-cv-lightbox-next]', root).forEach(function (b) { b.addEventListener('click', function () { show(index + 1); }); });
    dialog.addEventListener('click', function (e) { if (e.target === dialog) dialog.close(); });
    dialog.addEventListener('keydown', function (e) { if (e.key === 'ArrowRight') show(index + 1); else if (e.key === 'ArrowLeft') show(index - 1); });
    dialog.addEventListener('close', function () { img.removeAttribute('src'); img.hidden = true; document.body.style.overflow = ''; if (opener) opener.focus(); });
  }

  function init(root) {
    $$('[data-cv-reviews], [data-cv-stories], [data-cv-gallery]', root).forEach(carousel);
    $$('[data-cv-hotspots]', root).forEach(hotspots);
    $$('[data-cv-gallery]', root).forEach(gallery);
    $$('[data-cv-stories]', root).forEach(stories);
    $$('[data-cart-reserve]', root).forEach(reserve);
  }
  function ready() { init(document); new MutationObserver(function (records) { records.forEach(function (r) { r.addedNodes.forEach(function (n) { if (n.nodeType === 1) init(n.parentElement || n); }); }); }).observe(document.body, { childList: true, subtree: true }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready); else ready();
  document.addEventListener('shopify:section:load', function (e) { init(e.target); });
})();

;
/* Sections de bibliothèque par famille (issue #141) : carrousel, comparaison avant/après, repères produits, image qui
   suit le récit, frise qui progresse, vidéo en lecture automatique, défilement des références.
   Aucune dépendance. Respecte « réduire les animations » et le réglage « animations » du thème ; chaque interaction
   reste utilisable au clavier et sans JavaScript (contenu visible, défilement natif). */
(function () {
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var motion = (window.themeSettings || {}).motion !== false && !reduce;
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function carousel(root) {
    var track = root.querySelector('[data-fs-track]'); if (!track) return;
    var prev = root.querySelector('[data-fs-prev]'), next = root.querySelector('[data-fs-next]');
    function step(dir) {
      var slide = track.querySelector('[data-fs-slide]'); var w = slide ? slide.getBoundingClientRect().width + parseFloat(getComputedStyle(track).columnGap || 0) : track.clientWidth;
      track.scrollBy({ left: dir * w, behavior: reduce ? 'auto' : 'smooth' });
    }
    function sync() {
      var max = track.scrollWidth - track.clientWidth - 2;
      if (prev) prev.disabled = track.scrollLeft <= 2;
      if (next) next.disabled = track.scrollLeft >= max;
      var nav = root.querySelector('.fs-carousel__nav'); if (nav) nav.hidden = max <= 0;
    }
    if (prev) prev.addEventListener('click', function () { step(-1); });
    if (next) next.addEventListener('click', function () { step(1); });
    track.addEventListener('keydown', function (e) { if (e.key === 'ArrowRight') { e.preventDefault(); step(1); } else if (e.key === 'ArrowLeft') { e.preventDefault(); step(-1); } });
    track.addEventListener('scroll', sync, { passive: true });
    window.addEventListener('resize', sync);
    sync();
  }

  function compare(fig) {
    var range = fig.querySelector('[data-fs-compare-range]'), stage = fig.querySelector('.fs-compare__stage'); if (!range || !stage) return;
    function set(v) { stage.style.setProperty('--fs-pos', v + '%'); }
    range.addEventListener('input', function () { set(range.value); });
    set(range.value);
  }

  function hotspots(scene) {
    var buttons = $$('[data-fs-hotspot]', scene);
    function close(except) { buttons.forEach(function (b) { if (b === except) return; b.setAttribute('aria-expanded', 'false'); var c = document.getElementById(b.getAttribute('aria-controls')); if (c) c.hidden = true; }); }
    buttons.forEach(function (b) {
      b.addEventListener('click', function () {
        var open = b.getAttribute('aria-expanded') === 'true'; close(b);
        b.setAttribute('aria-expanded', String(!open)); var c = document.getElementById(b.getAttribute('aria-controls')); if (c) c.hidden = open;
      });
    });
    scene.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return; var openBtn = buttons.filter(function (b) { return b.getAttribute('aria-expanded') === 'true'; })[0];
      if (openBtn) { close(); openBtn.focus(); }
    });
    document.addEventListener('click', function (e) { if (!scene.contains(e.target)) close(); });
  }

  function stickySteps(section) {
    var visual = section.querySelector('[data-fs-sticky-visual]'), steps = $$('[data-fs-step]', section);
    if (!visual || !steps.length || !('IntersectionObserver' in window)) return;
    var frames = $$('.fs-making__frame', visual);
    var holder = visual.closest('.fs-making, .fs-case') || section;
    function show(i) {
      var target = visual.querySelector('[data-fs-step-visual="' + i + '"]');
      if (!target) { var prior = steps.slice(0, i + 1).map(function (s) { return visual.querySelector('[data-fs-step-visual="' + s.getAttribute('data-fs-step') + '"]'); }).filter(Boolean); target = prior[prior.length - 1] || frames[0]; }
      frames.forEach(function (f) { f.classList.toggle('is-current', f === target); });
      steps.forEach(function (s) { s.classList.toggle('is-current', s.getAttribute('data-fs-step') === String(i)); });
    }
    if (window.matchMedia('(max-width: 749px)').matches) return;
    visual.classList.add('is-live'); holder.classList.add('is-live');
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) show(+e.target.getAttribute('data-fs-step')); });
    }, { rootMargin: '-45% 0px -45% 0px' });
    steps.forEach(function (s) { io.observe(s); });
    show(0);
  }

  function progress(list) {
    if (!motion) { list.style.setProperty('--fs-progress', 1); return; }
    var ticking = false;
    function update() {
      ticking = false; var r = list.getBoundingClientRect(), vh = window.innerHeight;
      var p = Math.min(1, Math.max(0, (vh * .6 - r.top) / Math.max(1, r.height)));
      list.style.setProperty('--fs-progress', p.toFixed(3));
    }
    window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(update); } }, { passive: true });
    update();
  }

  function autoplay(v) {
    if (!motion) { v.removeAttribute('autoplay'); v.pause(); v.controls = true; return; }
    if (!('IntersectionObserver' in window)) { v.play().catch(function () {}); return; }
    new IntersectionObserver(function (entries) { entries.forEach(function (e) { if (e.isIntersecting) v.play().catch(function () {}); else v.pause(); }); }, { threshold: .35 }).observe(v);
  }

  function marquee(m) { if (!motion) m.classList.add('is-paused'); }

  function init(root) {
    $$('[data-fs-carousel]', root).forEach(carousel);
    $$('[data-fs-compare]', root).forEach(compare);
    $$('[data-fs-hotspots]', root).forEach(hotspots);
    $$('.fs-making--sticky, .fs-case--sticky', root).forEach(function (s) { stickySteps(s.closest('.fs') || s); });
    $$('[data-fs-progress]', root).forEach(progress);
    $$('[data-fs-autoplay]', root).forEach(autoplay);
    $$('[data-fs-marquee]', root).forEach(marquee);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(document); }); else init(document);
  document.addEventListener('shopify:section:load', function (e) { init(e.target); });
})();

;
/* section content-tabs */
(function () {
  if (window.esContentTabs) return; window.esContentTabs = true;
  function init(root) {
    Array.prototype.forEach.call((root || document).querySelectorAll('[data-ctabs]'), function (s) {
      if (s._es) return; s._es = true;
      var list = s.querySelector('[data-ctabs-list]'), ink = s.querySelector('[data-ctabs-ink]');
      var tabs = Array.prototype.slice.call(s.querySelectorAll('[data-ctabs-tab]')), panels = Array.prototype.slice.call(s.querySelectorAll('[data-ctabs-panel]'));
      if (!list || !tabs.length) return;
      list.hidden = false; s.classList.add('is-ready');
      function moveInk() {
        var t = tabs.filter(function (x) { return x.getAttribute('aria-selected') === 'true'; })[0]; if (!t || !ink) return;
        ink.style.setProperty('--x', t.offsetLeft + 'px'); ink.style.setProperty('--w', t.offsetWidth + 'px');
      }
      function select(i, focus) {
        tabs.forEach(function (t, j) { var on = i === j; t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1; });
        panels.forEach(function (p, j) { var on = i === j; p.hidden = !on; p.classList.toggle('is-active', on); });
        if (focus) tabs[i].focus();
        tabs[i].scrollIntoView({ block: 'nearest', inline: 'nearest' });
        moveInk();
      }
      tabs.forEach(function (t, i) {
        t.addEventListener('click', function () { select(i, false); });
        t.addEventListener('keydown', function (e) {
          var k = e.key, n = tabs.length, j = null;
          if (k === 'ArrowRight' || k === 'ArrowDown') j = (i + 1) % n;
          else if (k === 'ArrowLeft' || k === 'ArrowUp') j = (i - 1 + n) % n;
          else if (k === 'Home') j = 0; else if (k === 'End') j = n - 1;
          if (j !== null) { e.preventDefault(); select(j, true); }
        });
      });
      panels.forEach(function (p, j) { p.hidden = j !== 0; });
      moveInk();
      window.addEventListener('resize', moveInk);
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(moveInk);
      s.addEventListener('shopify:block:select', function (e) { var k = tabs.indexOf(e.target); if (k > -1) select(k, false); });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(document); }); else init(document);
  document.addEventListener('shopify:section:load', function (e) { init(e.target); });
})();
;
/* section faq */
(function () {
  if (window.EsFaq) return;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches || (window.themeSettings && window.themeSettings.motion === false);
  function norm(s) { return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function animate(item, open) {
    var panel = item.querySelector('[data-faq-panel]');
    if (reduce || !panel || !panel.animate) { item.open = open; return; }
    if (item._anim) item._anim.cancel();
    var start = panel.offsetHeight;
    if (open) item.open = true;
    var end = open ? panel.scrollHeight : 0;
    if (!open) start = panel.scrollHeight;
    item.classList.add(open ? 'is-opening' : 'is-closing');
    requestAnimationFrame(function () { item.classList.remove('is-opening'); });
    item._anim = panel.animate([{ height: (open ? 0 : start) + 'px' }, { height: end + 'px' }], { duration: open ? 480 : 360, easing: 'cubic-bezier(.16, 1, .3, 1)' });
    item._anim.onfinish = function () { item._anim = null; item.classList.remove('is-closing'); if (!open) item.open = false; };
    item._anim.oncancel = function () { item.classList.remove('is-closing', 'is-opening'); };
  }
  function init(root) {
    if (!root || root._esFaq) return;
    root._esFaq = true;
    var items = Array.prototype.slice.call(root.querySelectorAll('[data-faq-item]'));
    items.forEach(function (item) {
      var summary = item.querySelector('summary');
      summary.addEventListener('click', function (e) { e.preventDefault(); animate(item, !item.open || item.classList.contains('is-closing')); });
    });
    var input = root.querySelector('[data-faq-search]');
    if (!input) return;
    var empty = root.querySelector('[data-faq-empty]');
    var status = root.querySelector('[data-faq-status]');
    var texts = items.map(function (item) { return norm(item.textContent); });
    var t;
    input.addEventListener('input', function () {
      clearTimeout(t);
      t = setTimeout(function () {
        var q = norm(input.value.trim());
        var shown = 0;
        items.forEach(function (item, i) {
          var ok = !q || q.split(/\s+/).every(function (w) { return texts[i].indexOf(w) !== -1; });
          item.hidden = !ok;
          if (ok) shown++;
        });
        if (empty) empty.hidden = shown > 0;
        if (status) status.textContent = q ? status.getAttribute('data-template').replace('__n__', shown) : '';
      }, 120);
    });
  }
  function initAll(ctx) { Array.prototype.forEach.call((ctx || document).querySelectorAll('[data-es-faq]'), init); }
  window.EsFaq = { init: initAll };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { initAll(); }); else initAll();
  document.addEventListener('shopify:section:load', function (e) { initAll(e.target); });
  document.addEventListener('shopify:block:select', function (e) { if (e.target.matches && e.target.matches('[data-faq-item]')) e.target.open = true; });
})();
;
/* section product-recommendations */
(function () {
  function bind(s) {
    var track = s.querySelector('[data-recos-track]'); if (!track) return;
    var bar = s.querySelector('.es-recos__progress');
    var prev = s.querySelector('[data-recos-prev]'), next = s.querySelector('[data-recos-next]');
    function step() { var it = track.querySelector('.es-recos__item'); return it ? (it.getBoundingClientRect().width + 20) * (window.innerWidth > 989 ? 2 : 1) : track.clientWidth * .8; }
    function update() {
      var max = track.scrollWidth - track.clientWidth;
      s.classList.toggle('is-static', max < 4);
      if (bar) bar.style.setProperty('--p', (max > 4 ? Math.max(12, 100 * track.clientWidth / track.scrollWidth) + (100 - Math.max(12, 100 * track.clientWidth / track.scrollWidth)) * track.scrollLeft / max : 100) + '%');
      if (prev) prev.disabled = track.scrollLeft < 4;
      if (next) next.disabled = track.scrollLeft > max - 4;
    }
    if (!s._esRecos) {
      s._esRecos = true;
      prev && prev.addEventListener('click', function () { track.scrollBy({ left: -step(), behavior: 'smooth' }); });
      next && next.addEventListener('click', function () { track.scrollBy({ left: step(), behavior: 'smooth' }); });
      window.addEventListener('resize', function () { requestAnimationFrame(update); });
    }
    track.addEventListener('scroll', function () { requestAnimationFrame(update); }, { passive: true });
    update();
  }
  function load(s) {
    var url = s.getAttribute('data-url'); if (!url || s._esRecosLoaded) return; s._esRecosLoaded = true;
    fetch(url).then(function (r) { return r.text(); }).then(function (html) {
      var tmp = document.createElement('div'); tmp.innerHTML = html;
      var fresh = tmp.querySelector('[data-recos-track][data-source="recommendations"]');
      var cur = s.querySelector('[data-recos-track]');
      if (!fresh || !cur || !fresh.children.length) return;
      cur.innerHTML = fresh.innerHTML; cur.setAttribute('data-source', 'recommendations');
      cur.querySelectorAll('[data-reveal]').forEach(function (el) { el.classList.add('is-in'); });
      bind(s);
    }).catch(function () {});
  }
  function init(root) {
    (root || document).querySelectorAll('[data-es-recos]').forEach(function (s) {
      bind(s);
      if (!('IntersectionObserver' in window)) return load(s);
      var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); load(s); } }, { rootMargin: '0px 0px 400px 0px' });
      io.observe(s);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(); }); else init();
  document.addEventListener('shopify:section:load', function (e) { init(e.target); });
})();