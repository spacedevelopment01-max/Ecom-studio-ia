{literal}<div id="shopify-section-template--es__title" class="shopify-section " data-es-section="page.carnet-de-route:title" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--wide" style="--pt: 48px; --pb: 0px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">En situation</h1>
    <div class="es-rte es-page__content" data-reveal="up"></div>
  </div>
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Maison Basalte", "item": "/" },
        { "@type": "ListItem", "position": 2, "name": "En situation", "item": "/pages/carnet-de-route" }
      ]
    }
  </script>
</section>


</div>
<div id="shopify-section-template--es__intro" class="shopify-section es-section-wrapper" data-es-section="page.carnet-de-route:intro" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--plain color-scheme-1" style="--pt: 24px; --pb: 32px;">
  <div class="es-container es-richtext__inner es-richtext__inner--left"><h2 class="es-heading es-h2" data-reveal="words" data-es-block="client_0">Votre façon d’aborder Théière Anse.</h2><div class="es-rte es-lead" data-reveal="up" data-es-block="client_1"><p>Maison Basalte dessine des objets pour le temps partagé autour de la table. La théière Anse associe une silhouette arrondie à un émail bleu ardoise.</p></div></div>
</section>


</div>
<div id="shopify-section-template--es__etapes" class="shopify-section es-section-wrapper" data-es-section="page.carnet-de-route:etapes" data-es-type="cv-alternating"><section class="es-section cv-alt cv-alt--image-left cv-alt--landscape cv-anim cv-anim--normal color-scheme-1" style="--pt:64px;--pb:64px;">
  <div class="es-container cv-alt__inner"><header class="cv-head"data-reveal="up"><h2 class="es-heading cv-title cv-title--h2">Matière : Grès émaillé</h2></header><div class="cv-alt__row cv-alt__row--left" data-es-block="b0">
        <div class="cv-alt__media cv-zoomable"data-reveal="up" data-d="0"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-3hd5hbnth65aobrc.jpg" alt="La théière Anse au centre de la table" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div>
        <div class="cv-alt__copy"data-reveal="up" data-d="0"><h3 class="es-heading cv-alt__title">Préparer la théière</h3><div class="es-rte cv-alt__text"><p>Composer son propre univers avec Théière Anse ; porter son attention sur matière : Grès émaillé plutôt que sur une course aux performances. Retirer le couvercle amovible pour préparer le thé.</p></div></div>
      </div><div class="cv-alt__row cv-alt__row--left" data-es-block="b1">
        <div class="cv-alt__media cv-zoomable"data-reveal="up" data-d="1"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-8rno3l05fnr23h3k.jpg" alt="Anse dans la lumière du matin" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div>
        <div class="cv-alt__copy"data-reveal="up" data-d="1"><h3 class="es-heading cv-alt__title">Partager le moment</h3><div class="es-rte cv-alt__text"><p>Poser Anse sur la table pour servir le thé.</p></div></div>
      </div><div class="cv-alt__row cv-alt__row--left" data-es-block="b2">
        <div class="cv-alt__media cv-zoomable"data-reveal="up" data-d="2"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-hs7qqbk0a8m6umvk.jpg" alt="Anse dans la lumière du matin" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div>
        <div class="cv-alt__copy"data-reveal="up" data-d="2"><h3 class="es-heading cv-alt__title">Nettoyer après usage</h3><div class="es-rte cv-alt__text"><p>Laver à la main avec une éponge douce.</p></div></div>
      </div></div>
</section>


</div>
<div id="shopify-section-template--es__cta" class="shopify-section es-section-wrapper" data-es-section="page.carnet-de-route:cta" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-2 es-cta--left" style="--pt: 88px; --pb: 88px; --overlay: 0.35;"><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Théière Anse</h2><div class="es-rte es-lead" data-reveal="up"><p>Une théière en grès émaillé bleu ardoise, avec une anse arrondie et un couvercle amovible, pour partager le thé autour de la table. Découvrez les détails qui vous parlent, sans vous laisser imposer un style.</p></div><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-button" data-reveal="up" style="--d: 1">Explorer les finitions <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>





</div>{/literal}