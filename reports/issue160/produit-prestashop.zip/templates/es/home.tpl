{literal}<div id="shopify-section-template--es__cv_banner_1" class="shopify-section es-section-wrapper" data-es-section="index:cv_banner_1" data-es-type="cv-banner"><section class="es-section cv-banner cv-banner--image-left cv-anim cv-anim--normal color-scheme-1" style="--pt:64px;--pb:64px;">
  <div class="es-container">
    <div class="cv-banner__inner"data-reveal="fade">
      <div class="cv-banner__media cv-zoomable"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-g6puda17ju0xau27.jpg" alt="La théière Anse au centre de la table" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div>
      <div class="cv-banner__copy"><p class="cv-eyebrow">Maison Basalte</p><h1 class="es-heading cv-title cv-banner__title">Théière Anse, dans votre univers.</h1><div class="es-rte cv-banner__text"><p>Une théière en grès émaillé bleu ardoise, avec une anse arrondie et un couvercle amovible, pour partager le thé autour de la table. Découvrez les détails qui vous parlent, sans vous laisser imposer un style.</p></div><p class="cv-banner__price">68,00 €</p><a class="es-button cv-button cv-banner__button" href="{/literal}{$urls.base_url}{literal}products/theiere-anse">Explorer les finitions</a></div>
    </div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__features_grid_2" class="shopify-section es-section-wrapper" data-es-section="index:features_grid_2" data-es-type="features-grid"><section data-layout="grid" data-cols-m="1" class="es-section cv-anim cv-anim--normal es-features es-features--lines color-scheme-4" style="--pt: 96px; --pb: 96px;">
  <div class="es-container">
    <header class="es-section-head es-section-head--left"><p class="es-eyebrow"data-reveal="up">Maison Basalte</p><h2 class="es-heading es-h2" data-reveal="words">Ce qui compte pour votre choix <em>en un coup d'œil.</em></h2><a class="es-link-arrow" href="{/literal}{$urls.base_url}{literal}collections/all"data-reveal="up">Découvrir Théière Anse <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></header>
    <div class="es-features__grid" style="--cols: 1; --cols-m: 1; --cols-t: 1" data-reveal-stagger><article class="es-feature"data-reveal="up" style="--i: 0" data-es-block="client_0"><span class="es-feature__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Matière</h3>
          <div class="es-rte es-muted"><p>Matière : Grès émaillé</p></div></article><article class="es-feature"data-reveal="up" style="--i: 1" data-es-block="client_1"><span class="es-feature__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Contenance</h3>
          <div class="es-rte es-muted"><p>Contenance : 700 ml</p></div></article><article class="es-feature"data-reveal="up" style="--i: 2" data-es-block="client_2"><span class="es-feature__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Finition</h3>
          <div class="es-rte es-muted"><p>Finition : Bleu ardoise satiné</p></div></article><article class="es-feature"data-reveal="up" style="--i: 3" data-es-block="client_3"><span class="es-feature__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Anse</h3>
          <div class="es-rte es-muted"><p>Anse : Anse arrondie</p></div></article><article class="es-feature"data-reveal="up" style="--i: 4" data-es-block="client_4"><span class="es-feature__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Couvercle</h3>
          <div class="es-rte es-muted"><p>Couvercle : Amovible</p></div></article><article class="es-feature"data-reveal="up" style="--i: 5" data-es-block="client_5"><span class="es-feature__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span><h3 class="es-heading es-h4">Entretien</h3>
          <div class="es-rte es-muted"><p>Entretien : Laver à la main avec une éponge douce</p></div></article></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__cv_alternating_1" class="shopify-section es-section-wrapper" data-es-section="index:cv_alternating_1" data-es-type="cv-alternating"><section class="es-section cv-alt cv-alt--alternate cv-alt--portrait cv-anim cv-anim--normal color-scheme-1" style="--pt:64px;--pb:64px;">
  <div class="es-container cv-alt__inner"><header class="cv-head"data-reveal="up"><h2 class="es-heading cv-title cv-title--h2">Matière : Grès émaillé</h2></header><div class="cv-alt__row cv-alt__row--left" data-es-block="b0">
        <div class="cv-alt__media cv-zoomable"data-reveal="up" data-d="0"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-3hd5hbnth65aobrc.jpg" alt="La théière Anse au centre de la table" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div>
        <div class="cv-alt__copy"data-reveal="up" data-d="0"><h3 class="es-heading cv-alt__title">Préparer la théière</h3><div class="es-rte cv-alt__text"><p>Composer son propre univers avec Théière Anse ; porter son attention sur matière : Grès émaillé plutôt que sur une course aux performances. Retirer le couvercle amovible pour préparer le thé.</p></div></div>
      </div><div class="cv-alt__row cv-alt__row--right" data-es-block="b1">
        <div class="cv-alt__media cv-zoomable"data-reveal="up" data-d="1"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-8rno3l05fnr23h3k.jpg" alt="Anse dans la lumière du matin" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div>
        <div class="cv-alt__copy"data-reveal="up" data-d="1"><h3 class="es-heading cv-alt__title">Partager le moment</h3><div class="es-rte cv-alt__text"><p>Poser Anse sur la table pour servir le thé.</p></div></div>
      </div><div class="cv-alt__row cv-alt__row--left" data-es-block="b2">
        <div class="cv-alt__media cv-zoomable"data-reveal="up" data-d="2"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-hs7qqbk0a8m6umvk.jpg" alt="Anse dans la lumière du matin" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div>
        <div class="cv-alt__copy"data-reveal="up" data-d="2"><h3 class="es-heading cv-alt__title">Nettoyer après usage</h3><div class="es-rte cv-alt__text"><p>Laver à la main avec une éponge douce.</p></div></div>
      </div></div>
</section>


</div>
<div id="shopify-section-template--es__cv_ingredients_1" class="shopify-section es-section-wrapper" data-es-section="index:cv_ingredients_1" data-es-type="cv-ingredients"><section class="es-section cv-ingr cv-ingr--split cv-ingr--square cv-anim cv-anim--normal color-scheme-4" style="--pt:64px;--pb:64px;--cols:3" data-cv-ingredients>
  <div class="es-container cv-ingr__inner">
    <header class="cv-head cv-ingr__head"data-reveal="up"><p class="cv-eyebrow">Composition</p><h2 class="es-heading cv-title cv-title--h2">Composition et matières</h2><div class="es-rte cv-head__text"><p>Une théière en grès émaillé bleu ardoise, avec une anse arrondie et un couvercle amovible, pour partager le thé autour de la table. Matière : Grès émaillé Contenance : 700 ml Finition : Bleu ardoise satiné Anse : Anse arrondie Couvercle : Amovible Entretien : Laver à la main avec une éponge douce Garantie : 12 mois selon les conditions fournies pour cet exemple fictif Livraison : Livraison en France métropolitaine selon les conditions du projet fictif</p></div></header><div class="cv-ingr__media cv-zoomable"data-reveal="up"><div class="ed-media" style="--ed-fx:50%;--ed-fy:50%;--ed-fxm:50%;--ed-fym:50%;"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-dgzwgev8q4tff4wy.jpg" alt="Le couvercle amovible et sa prise arrondie" class="ed-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
</div><ul class="cv-ingr__list" role="list"><li class="cv-ingr__item" data-es-block="client_0"data-reveal="up" data-d="0">
          <div class="cv-ingr__visual"><span class="cv-ingr__icon" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14Z"/><path d="M5 19 13 11"/></svg></span></div>
          <div class="cv-ingr__copy">
            <p class="cv-ingr__name">Matière</p><p class="cv-ingr__role">Grès émaillé</p></div>
        </li><li class="cv-ingr__item" data-es-block="client_1"data-reveal="up" data-d="1">
          <div class="cv-ingr__visual"><span class="cv-ingr__icon" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14Z"/><path d="M5 19 13 11"/></svg></span></div>
          <div class="cv-ingr__copy">
            <p class="cv-ingr__name">Finition</p><p class="cv-ingr__role">Bleu ardoise satiné</p></div>
        </li></ul></div>
</section>


</div>
<div id="shopify-section-template--es__image_with_text_2" class="shopify-section es-section-wrapper" data-es-section="index:image_with_text_2" data-es-type="image-with-text"><section class="es-section es-iwt es-iwt--image-left color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-iwt__grid">
    <div class="es-iwt__media es-media-frame es-media-frame--landscape" data-reveal="curtain" data-scroll-zoom>
      <img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-uv0e7i6xxoqpjekp.jpg" alt="Une silhouette accueillante" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async">
    </div>
    <div class="es-iwt__content"><p class="es-eyebrow" data-reveal="up">Maison Basalte</p><h2 class="es-heading es-h2" data-reveal="words">Une silhouette accueillante</h2>
      <div class="es-rte" data-reveal="up" style="--d: 1"><p>L’anse arrondie et le couvercle composent un volume simple à retrouver sur la table.</p></div><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-button es-button--secondary" data-reveal="up" style="--d: 2">Découvrir Théière Anse</a></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__featured_purchase_1" class="shopify-section es-section-wrapper" data-es-section="index:featured_purchase_1" data-es-type="featured-purchase"><section class="ed-section fp fp--contain color-scheme-1" data-ed-motion="reveal" data-featured-purchase style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell fp__grid"><header class="fp__head">
    <p class="ed-kicker">Maison Basalte</p>
    <h2 class="ed-title fp__title">Faire une place à Théière Anse</h2>
    <div class="fp__price" data-fp-price><div class="es-price" data-price><span class="es-price__current">68,00 €</span></div>
<span class="fp__price-note" data-price-note>par article</span></div>
  </header>
  <div class="fp__media" data-gallery data-fp-gallery>
    <div class="fp__stage" aria-live="polite"><figure class="fp__slide fp__slide--packshot" data-media-id="m1-1" data-fp-slide><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-5fke4hzcvday9jq9.jpg?width=1400" srcset="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-5fke4hzcvday9jq9.jpg?width=550 550w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-5fke4hzcvday9jq9.jpg?width=750 750w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-5fke4hzcvday9jq9.jpg?width=1100 1100w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-5fke4hzcvday9jq9.jpg?width=1400 1400w" sizes="(min-width: 990px) 55vw, 100vw" alt="Théière Anse entière, émail bleu ardoise et couvercle amovible" class="fp__img" loading="eager" decoding="async"><button type="button" class="es-product__zoom" data-zoom-open data-zoom-src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-5fke4hzcvday9jq9.jpg?width=2400" data-zoom-alt="Théière Anse entière, émail bleu ardoise et couvercle amovible" aria-label="Agrandir l'image"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg></button></figure><figure class="fp__slide" data-media-id="m1-2" data-fp-slide hidden><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-qiu5sf7zlwxjy9b3.jpg?width=1400" srcset="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-qiu5sf7zlwxjy9b3.jpg?width=550 550w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-qiu5sf7zlwxjy9b3.jpg?width=750 750w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-qiu5sf7zlwxjy9b3.jpg?width=1100 1100w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-qiu5sf7zlwxjy9b3.jpg?width=1400 1400w" sizes="(min-width: 990px) 55vw, 100vw" alt="Théière Anse entière, émail bleu ardoise et couvercle amovible" class="fp__img" loading="lazy" decoding="async"><button type="button" class="es-product__zoom" data-zoom-open data-zoom-src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-qiu5sf7zlwxjy9b3.jpg?width=2400" data-zoom-alt="Théière Anse entière, émail bleu ardoise et couvercle amovible" aria-label="Agrandir l'image"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg></button></figure><figure class="fp__slide" data-media-id="m1-3" data-fp-slide hidden><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-dgzwgev8q4tff4wy.jpg?width=1400" srcset="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-dgzwgev8q4tff4wy.jpg?width=550 550w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-dgzwgev8q4tff4wy.jpg?width=750 750w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-dgzwgev8q4tff4wy.jpg?width=1100 1100w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-dgzwgev8q4tff4wy.jpg?width=1400 1400w" sizes="(min-width: 990px) 55vw, 100vw" alt="Le couvercle amovible et sa prise arrondie" class="fp__img" loading="lazy" decoding="async"><button type="button" class="es-product__zoom" data-zoom-open data-zoom-src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-dgzwgev8q4tff4wy.jpg?width=2400" data-zoom-alt="Le couvercle amovible et sa prise arrondie" aria-label="Agrandir l'image"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg></button></figure><figure class="fp__slide" data-media-id="m1-4" data-fp-slide hidden><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-kprwi8yvrozd4och.jpg?width=1400" srcset="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-kprwi8yvrozd4och.jpg?width=550 550w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-kprwi8yvrozd4och.jpg?width=750 750w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-kprwi8yvrozd4och.jpg?width=1100 1100w, {/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-kprwi8yvrozd4och.jpg?width=1400 1400w" sizes="(min-width: 990px) 55vw, 100vw" alt="L’émail bleu ardoise, vu de près" class="fp__img" loading="lazy" decoding="async"><button type="button" class="es-product__zoom" data-zoom-open data-zoom-src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-kprwi8yvrozd4och.jpg?width=2400" data-zoom-alt="L’émail bleu ardoise, vu de près" aria-label="Agrandir l'image"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg></button></figure></div><div class="fp__thumbs" role="list" aria-label="Galerie du produit"><button type="button" class="fp__thumb fp__thumb--packshot is-active" data-fp-go="m1-1" aria-label="Afficher l'image 1" aria-current="true"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-5fke4hzcvday9jq9.jpg?width=240" alt="" loading="lazy" decoding="async"></button><button type="button" class="fp__thumb" data-fp-go="m1-2" aria-label="Afficher l'image 2"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-qiu5sf7zlwxjy9b3.jpg?width=240" alt="" loading="lazy" decoding="async"></button><button type="button" class="fp__thumb" data-fp-go="m1-3" aria-label="Afficher l'image 3"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-dgzwgev8q4tff4wy.jpg?width=240" alt="" loading="lazy" decoding="async"></button><button type="button" class="fp__thumb" data-fp-go="m1-4" aria-label="Afficher l'image 4"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-kprwi8yvrozd4och.jpg?width=240" alt="" loading="lazy" decoding="async"></button></div><dialog class="es-zoom" data-zoom aria-label="Galerie du produit">
        <div class="es-zoom__stage" data-zoom-stage></div>
        <button type="button" class="es-zoom__btn es-zoom__close" data-zoom-close aria-label="Fermer l'agrandissement"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 5 14 14M19 5 5 19"/></svg></button>
        <button type="button" class="es-zoom__btn es-zoom__prev" data-zoom-step="-1" aria-label="Image précédente"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 12H4M10 6l-6 6 6 6"/></svg></button>
        <button type="button" class="es-zoom__btn es-zoom__next" data-zoom-step="1" aria-label="Image suivante"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></button>
      </dialog></div>
  <div class="fp__body">
    <div class="ed-prose fp__text"><p>Découvrir comment Théière Anse dialogue avec votre univers.</p></div>
    <div class="fp__buy" id="FeaturedBuy-template--es__featured_purchase_1"><div class="es-buy" data-product-buy data-section="template--es__featured_purchase_1" data-product-url="/products/theiere-anse"><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" enctype="multipart/form-data" id="product-form-template--es__featured_purchase_1" class="es-buy__form" data-product-form=""><input type="hidden" name="form_type" value="product"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><input type="hidden" name="id" value="1000" data-variant-id>
    <div class="es-buy__row"><div class="es-qty">
          <button type="button" data-qty-step="-1" aria-label="Diminuer la quantité"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 12h14"/></svg></button>
          <label class="visually-hidden" for="Quantity-template--es__featured_purchase_1">Quantité</label>
          <input id="Quantity-template--es__featured_purchase_1" type="number" name="quantity" value="1" min="1" inputmode="numeric">
          <button type="button" data-qty-step="1" aria-label="Augmenter la quantité"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg></button>
        </div><button type="submit" name="add" class="es-button es-button--grow" data-add-button>
        <span data-add-label>Ajouter au panier</span>
      </button>
    </div><p class="es-form-error" role="alert" data-form-error hidden></p></form><script type="application/json" data-variants>[{"id":1000,"title":"Default Title","options":["Default Title"],"option1":"Default Title","option2":null,"option3":null,"price":6800,"compare_at_price":null,"available":true,"sku":"","inventory_management":null,"url":"/products/theiere-anse?variant=1000","featured_media":{"src":"/assets/es-client-5fke4hzcvday9jq9.jpg","width":1000,"height":1000,"alt":"Théière Anse entière, émail bleu ardoise et couvercle amovible","id":"m1-1","aspect_ratio":1,"media_type":"image","preview_image":{"src":"/assets/es-client-5fke4hzcvday9jq9.jpg","width":1000,"height":1000,"alt":"Théière Anse entière, émail bleu ardoise et couvercle amovible","id":"m1-1","aspect_ratio":1,"media_type":"image"}},"unit_price_measurement":null}]</script>
</div>
</div><a class="ed-text-link fp__link" href="{/literal}{$urls.base_url}{literal}products/theiere-anse" data-fp-link>Explorer les finitions<span aria-hidden="true">↗</span></a></div></div></section>

</div>
<div id="shopify-section-template--es__faq_2" class="shopify-section es-section-wrapper" data-es-section="index:faq_2" data-es-type="faq"><section class="es-section es-faq es-faq--lines es-faq--side es-faq--cols-1 color-scheme-1" style="--pt: 96px; --pb: 96px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><p class="es-eyebrow" data-reveal="up">Besoin d'aide ?</p><h2 class="es-heading es-h2" data-reveal="words">Vos questions</h2><div class="es-faq__contact" data-reveal="up"><p class="es-faq__contact-text">Une autre question ?</p><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-button es-button--secondary es-button--small">Découvrir Théière Anse <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a>
        </div></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_2"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="client_0">
          <summary><span class="es-faq__q">Est-ce que cette offre correspond à mes préférences ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Une théière en grès émaillé bleu ardoise, avec une anse arrondie et un couvercle amovible, pour partager le thé autour de la table. Matière : Grès émaillé Contactez-nous pour préciser les points qui ne figurent pas dans ces informations.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="client_1">
          <summary><span class="es-faq__q">Quelle est la contenance ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>La contenance confirmée est de 700 ml.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="client_2">
          <summary><span class="es-faq__q">Comment nettoyer Anse ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Laver à la main avec une éponge douce.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 3" data-faq-item data-es-block="client_3">
          <summary><span class="es-faq__q">Le couvercle est-il amovible ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Oui, le couvercle est amovible.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 4" data-faq-item data-es-block="client_4">
          <summary><span class="es-faq__q">Quelle finition est présentée ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>La finition présentée est bleu ardoise satiné.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Est-ce que cette offre correspond à mes préférences ?", "acceptedAnswer": { "@type": "Answer", "text": "Une théière en grès émaillé bleu ardoise, avec une anse arrondie et un couvercle amovible, pour partager le thé autour de la table. Matière : Grès émaillé Contactez-nous pour préciser les points qui ne figurent pas dans ces informations." } },{ "@type": "Question", "name": "Quelle est la contenance ?", "acceptedAnswer": { "@type": "Answer", "text": "La contenance confirmée est de 700 ml." } },{ "@type": "Question", "name": "Comment nettoyer Anse ?", "acceptedAnswer": { "@type": "Answer", "text": "Laver à la main avec une éponge douce." } },{ "@type": "Question", "name": "Le couvercle est-il amovible ?", "acceptedAnswer": { "@type": "Answer", "text": "Oui, le couvercle est amovible." } },{ "@type": "Question", "name": "Quelle finition est présentée ?", "acceptedAnswer": { "@type": "Answer", "text": "La finition présentée est bleu ardoise satiné." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__seo_home_body" class="shopify-section es-section-wrapper" data-es-section="index:seo_home_body" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--plain color-scheme-1" style="--pt: 48px; --pb: 48px;">
  <div class="es-container es-richtext__inner es-richtext__inner--left"><div class="es-rte es-lead" data-reveal="up" data-es-block="body"><p>Découvrir comment Théière Anse dialogue avec votre univers.</p>
<h2>Ce que ça change pour vous</h2>
<ul><li><strong>Matière</strong> : Grès émaillé</li><li><strong>Contenance</strong> : 700 ml</li><li><strong>Finition</strong> : Bleu ardoise satiné</li><li><strong>Anse</strong> : Anse arrondie</li></ul>
<p class="cta"><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse">Voir le produit</a></p></div></div>
</section>


</div>{/literal}