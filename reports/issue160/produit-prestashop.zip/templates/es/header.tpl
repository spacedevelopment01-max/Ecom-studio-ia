{literal}<div id="shopify-section-template--es__announce" class="shopify-section es-announcement-section" data-es-section="group:header:announce" data-es-type="announcement-bar"><div class="es-announcement es-announcement--static color-scheme-3" role="region" aria-label="Annonce"><div class="es-announcement__track" style="--count: 1"><p class="es-announcement__item" data-es-block="b0">Bienvenue dans notre boutique</p></div></div>
</div><div id="shopify-section-template--es__header" class="shopify-section es-header-section" data-es-section="group:header:header" data-es-type="header"><header class="es-header es-header--two-rows es-header--shape-bar es-header--icons-plain es-header--sticky color-scheme-1" data-header>
  <div class="es-header__inner es-container">
    <button class="es-header__burger es-icon-button" type="button" aria-controls="MobileMenu" aria-expanded="false" data-menu-open>
      <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7h18M3 12h18M3 17h18"/></svg><span class="visually-hidden">Menu</span>
    </button>

    <a href="{/literal}{$urls.base_url}{literal}" class="es-header__logo" aria-label="Maison Basalte"><img src="{/literal}{$urls.base_url}{literal}themes/esmaisonbasaltee7ee2574/assets/es/es-client-ot1vqu9xjazpt54t.png" alt="Maison Basalte" class="es-header__logo-img" width="170" height="57" loading="eager"></a>

    <nav class="es-header__nav" aria-label="Navigation principale">
      <ul role="list"><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}" class="es-nav__link"><span>Accueil</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-nav__link"><span>Théière Anse</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/carnet-de-route" class="es-nav__link"><span>En situation</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/aide" class="es-nav__link"><span>Questions et contact</span></a></li></ul>
    </nav>

    <div class="es-header__icons"><a href="{/literal}{$urls.pages.search}{literal}" class="es-icon-button" aria-label="Rechercher"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg></a><a href="{/literal}{$urls.pages.cart}{literal}" class="es-icon-button es-cart-link" data-cart-open aria-label="Panier">
          <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 7h14l-1.2 12.1a1 1 0 0 1-1 .9H7.2a1 1 0 0 1-1-.9L5 7Z"/><path d="M9 7V6a3 3 0 0 1 6 0v1"/></svg>
          <span class="es-cart-count" data-cart-count{/literal}{if $cart.products_count == 0} hidden{/if}{literal}>{/literal}{$cart.products_count}{literal}</span>
        </a></div>
  </div>

  <div class="es-mobile-menu es-mobile-menu--cards es-mobile-menu--sub-accordion color-scheme-1" id="MobileMenu" hidden data-mobile-menu>
    <div class="es-mobile-menu__head">
      <span class="es-header__wordmark">Maison Basalte</span>
      <button type="button" class="es-icon-button" data-menu-close aria-label="Fermer"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 5 14 14M19 5 5 19"/></svg></button>
    </div><div class="es-mobile-menu__promos"><a href="{/literal}{$urls.base_url}{literal}collections/all" class="es-menu-promo es-menu-promo--small" data-es-block="promo1">
        <span class="es-menu-promo__media"><div class="es-placeholder es-cover" role="img" aria-label="Image à venir">
    <svg class="es-placeholder__svg" viewBox="0 0 525 525" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect width="525" height="525" fill="none"/><path d="M180 330l60-80 50 60 35-40 70 60H180z" fill="currentColor" opacity=".35"/><circle cx="215" cy="215" r="24" fill="currentColor" opacity=".35"/><title>image</title></svg>
  </div></span>
        <span class="es-menu-promo__body"><span class="es-menu-promo__eyebrow">Nouveauté</span><span class="es-menu-promo__title">Découvrez la collection</span><span class="es-menu-promo__cta">Voir <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></span></span>
      </a><a href="{/literal}{$urls.base_url}{literal}collections/all" class="es-menu-promo es-menu-promo--small" data-es-block="promo2">
        <span class="es-menu-promo__media"><div class="es-placeholder es-cover" role="img" aria-label="Image à venir">
    <svg class="es-placeholder__svg" viewBox="0 0 525 525" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect width="525" height="525" fill="none"/><path d="M180 330l60-80 50 60 35-40 70 60H180z" fill="currentColor" opacity=".35"/><circle cx="215" cy="215" r="24" fill="currentColor" opacity=".35"/><title>image</title></svg>
  </div></span>
        <span class="es-menu-promo__body"><span class="es-menu-promo__eyebrow">Nouveauté</span><span class="es-menu-promo__title">Découvrez la collection</span><span class="es-menu-promo__cta">Voir <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></span></span>
      </a></div><ul role="list" class="es-mobile-menu__list"><li style="--i: 1"><a href="{/literal}{$urls.base_url}{literal}" class="es-mm__link"><span>Accueil</span></a></li><li style="--i: 2"><a href="{/literal}{$urls.base_url}{literal}products/theiere-anse" class="es-mm__link"><span>Théière Anse</span></a></li><li style="--i: 3"><a href="{/literal}{$urls.base_url}{literal}pages/carnet-de-route" class="es-mm__link"><span>En situation</span></a></li><li style="--i: 4"><a href="{/literal}{$urls.base_url}{literal}pages/aide" class="es-mm__link"><span>Questions et contact</span></a></li></ul><ul class="es-social" role="list"></ul>

  </div>
</header>




</div>{/literal}