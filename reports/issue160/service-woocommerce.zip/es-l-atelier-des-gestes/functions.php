<?php
/** L’Atelier des Gestes — thème généré par E-COM STUDIO IA (CMS Engine V2). */
require_once __DIR__ . '/inc/es-theme.php';
