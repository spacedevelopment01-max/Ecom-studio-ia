{literal}<div id="shopify-section-template--es__ref_hero_1" class="shopify-section reference-section" data-es-section="index:ref_hero_1" data-es-type="ref-hero"><section class="ref-section ref-hero ref-hero--landscape color-scheme-1" data-reference="hero" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;" aria-labelledby="RefTitle-template--es__ref_hero_1">
  <div class="ref-shell ref-hero__grid">
    <div class="ref-hero__copy">
      <p class="ref-label">Racines &amp; Pierres</p>
      <h1 id="RefTitle-template--es__ref_hero_1" class="ref-hero__title">Des jardins qui donnent envie de rester.</h1>
      <div class="ref-prose ref-hero__text"><p>Du premier échange aux plantations, un projet d’extérieur pensé pour votre terrain et votre façon de vivre dehors.</p></div>
      <div class="ref-actions"><a class="ref-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Demander un devis<span aria-hidden="true">↗</span></a><a class="ref-link" href="{/literal}{$urls.base_url}{literal}pages/prestations">Voir les prestations</a></div>
    </div>
    <figure class="ref-hero__media"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-1-6or3rn.jpg" alt="Vue de l&#39;activité" class="ref-image" width="1600" height="1600" loading="eager" decoding="async" fetchpriority="high"><figcaption>Création et entretien de jardins</figcaption></figure>
  </div>
</section>

</div>
<div id="shopify-section-template--es__ref_editorial_1" class="shopify-section reference-section" data-es-section="index:ref_editorial_1" data-es-type="ref-editorial"><section class="ref-section ref-editorial ref-editorial--inset color-scheme-1" data-reference="editorial" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;">
  <div class="ref-shell ref-editorial__grid">
    <figure class="ref-editorial__media"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-2-59h1zd.jpg" alt="Le jardin commence par vous." class="ref-image" width="1600" height="1600" loading="lazy" decoding="async"></figure>
    <div class="ref-editorial__copy"><h2 class="ref-heading">Le jardin commence par vous.</h2><div class="ref-prose"><p>Un jardin se dessine à partir d’un lieu, d’usages et d’envies. Nous relions les matières et le végétal pour faire de l’extérieur un espace à vivre.</p></div></div>
  </div>
</section>

</div>
<div id="shopify-section-template--es__ref_offers_1" class="shopify-section reference-section" data-es-section="index:ref_offers_1" data-es-type="ref-offers"><section class="ref-section ref-offers ref-offers--studio color-scheme-1" data-reference="offers" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;">
  <div class="ref-shell">
    <div class="ref-section-head"><h2 class="ref-heading" data-reveal="up">Une réponse à votre projet</h2><div class="ref-prose"></div></div>
    
      <div class="ref-offers__list"><article class="ref-offer" data-es-block="offer_1">
        <div class="ref-offer__media"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-prestation-qt5oi1-qt5oi1.jpg" alt="Création de jardin" class="ref-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
        <div class="ref-offer__copy"><h3>Création de jardin</h3><div class="ref-prose"><p>Dessiner les volumes, choisir les végétaux et organiser les cheminements. Un projet pensé pour votre terrain et votre façon de vivre dehors.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/texte-service-creation"><span class="visually-hidden">Création de jardin</span><span aria-hidden="true">↗</span></a>
      </article><article class="ref-offer" data-es-block="offer_2">
        <div class="ref-offer__media"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-prestation-lp3pbh-lp3pbh.jpg" alt="Terrasses et aménagements" class="ref-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
        <div class="ref-offer__copy"><h3>Terrasses et aménagements</h3><div class="ref-prose"><p>Bois, pierre sèche, jardinières et éclairage : composer des espaces où l’on aime s’installer, recevoir et circuler.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/texte-service-terrasse"><span class="visually-hidden">Terrasses et aménagements</span><span aria-hidden="true">↗</span></a>
      </article><article class="ref-offer" data-es-block="offer_3">
        <div class="ref-offer__media"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-prestation-qxk5rr-qxk5rr.jpg" alt="Entretien à l’année" class="ref-image" width="1600" height="1600" loading="lazy" decoding="async"></div>
        <div class="ref-offer__copy"><h3>Entretien à l’année</h3><div class="ref-prose"><p>Taille, tonte, désherbage et suivi des plantations. Accompagner le jardin au fil des saisons, selon ses besoins.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/texte-service-entretien"><span class="visually-hidden">Entretien à l’année</span><span aria-hidden="true">↗</span></a>
      </article></div>
    
    <div class="ref-offers__action"><a class="ref-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Demander un devis<span aria-hidden="true">↗</span></a></div>
  </div>
</section>

</div>
<div id="shopify-section-template--es__ref_editorial_2" class="shopify-section reference-section" data-es-section="index:ref_editorial_2" data-es-type="ref-editorial"><section class="ref-section ref-editorial ref-editorial--wide color-scheme-3" data-reference="editorial" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;">
  <div class="ref-shell ref-editorial__grid">
    <figure class="ref-editorial__media"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-3-rjkr27.jpg" alt="Du bois, de la pierre, du végétal." class="ref-image" width="1600" height="1600" loading="lazy" decoding="async"></figure>
    <div class="ref-editorial__copy"><h2 class="ref-heading">Du bois, de la pierre, du végétal.</h2><div class="ref-prose"><p>Une terrasse prolonge la maison. Un muret dessine une limite. Les plantations relient les espaces et accompagnent les saisons.</p></div></div>
  </div>
</section>

</div>
<div id="shopify-section-template--es__ref_notes_1" class="shopify-section reference-section" data-es-section="index:ref_notes_1" data-es-type="ref-notes"><section class="ref-section ref-notes ref-notes--rows color-scheme-1" data-reference="notes" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;"><div class="ref-shell"><h2 class="ref-heading" data-reveal="up">Notre façon de travailler</h2><div class="ref-notes__grid"><article class="ref-note" data-es-block="note_1"><h3>Partir de vos usages</h3><div class="ref-prose"><p>Circuler, s’asseoir, recevoir : le projet commence par votre façon d’habiter le jardin.</p></div></article><article class="ref-note" data-es-block="note_2"><h3>Faire dialoguer les matières</h3><div class="ref-prose"><p>Bois, pierre et végétaux composent les volumes du projet.</p></div></article><article class="ref-note" data-es-block="note_3"><h3>Accompagner les saisons</h3><div class="ref-prose"><p>L’entretien prolonge le travail de conception et de plantation.</p></div></article></div></div></section>

</div>
<div id="shopify-section-template--es__v2_steps_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_steps_1" data-es-type="v2-steps"><section class="v2-steps v2-steps--line color-scheme-1" style="--pt: 104px; --pb: 104px; --n: 3;">
  <div class="es-container">
    <header class="v2-head"><h2 class="v2-h2" data-reveal="up">Du premier échange au jardin vivant.</h2></header>
    <ol class="v2-steps__list"><li class="v2-steps__item" data-reveal="up" style="--i: 0" data-es-block="step_4">
          <span class="v2-steps__num">01</span>
          <h3 class="v2-h3">Comprendre le lieu</h3><div class="v2-rte"><p>Échanger sur vos envies, observer les usages et les contraintes du terrain.</p></div></li><li class="v2-steps__item" data-reveal="up" style="--i: 1" data-es-block="step_5">
          <span class="v2-steps__num">02</span>
          <h3 class="v2-h3">Composer le projet</h3><div class="v2-rte"><p>Préciser les volumes, les matières, les végétaux et le périmètre du devis.</p></div></li><li class="v2-steps__item" data-reveal="up" style="--i: 2" data-es-block="step_6">
          <span class="v2-steps__num">03</span>
          <h3 class="v2-h3">Créer et accompagner</h3><div class="v2-rte"><p>Mettre en place les aménagements retenus puis organiser leur entretien.</p></div></li></ol>
  </div>
</section>


</div>
<div id="shopify-section-template--es__v2_media_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_media_1" data-es-type="v2-media"><section class="v2-media v2-media--rail color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container">
    <header class="v2-head"><h2 class="v2-h2" data-reveal="up">Des idées pour vos extérieurs.</h2></header>
    <div class="v2-media__grid" tabindex="0" aria-label="Des idées pour vos extérieurs."><figure class="v2-media__tile" data-reveal="up" style="--i: 0" data-es-block="image_1">
          <img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-2-59h1zd.jpg" alt="Jardin de démonstration" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"><figcaption>Jardin de démonstration</figcaption></figure><figure class="v2-media__tile" data-reveal="up" style="--i: 1" data-es-block="image_2">
          <img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-3-rjkr27.jpg" alt="Terrasse de démonstration" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"><figcaption>Terrasse de démonstration</figcaption></figure><figure class="v2-media__tile" data-reveal="up" style="--i: 2" data-es-block="image_3">
          <img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-4-ft8gxd.jpg" alt="Matières et outils" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"><figcaption>Matières et outils</figcaption></figure></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__v2_faq_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_faq_1" data-es-type="v2-faq"><section class="v2-faq v2-faq--center color-scheme-1" style="--pt: 80px; --pb: 80px;">
  <div class="es-container v2-faq__grid">
    <header class="v2-head v2-faq__head"><h2 class="v2-h2" data-reveal="up">Avant de nous rencontrer.</h2></header>
    <div class="v2-faq__list"><details class="v2-faq__item" data-reveal="up" style="--i: 0" data-es-block="question_5">
          <summary><span>Comment commencer un projet ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Décrivez le lieu, vos envies et les aménagements envisagés. Cet exemple utilise une demande de devis ; aucun professionnel réel n’est contacté.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 1" data-es-block="question_6">
          <summary><span>Peut-on demander uniquement de l’entretien ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Oui, l’entretien à l’année fait partie des prestations de cette entreprise fictive.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 2" data-es-block="question_7">
          <summary><span>Dans quelle zone intervenez-vous ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>La zone indiquée pour cette démonstration est Aix-en-Provence et ses alentours.</p></div>
        </details></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__v2_facts_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_facts_1" data-es-type="v2-facts"><section class="v2-facts v2-facts--ledger color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container v2-facts__grid">
    <header class="v2-head"><h2 class="v2-h2" data-reveal="up">Infos pratiques</h2></header>
    <dl class="v2-facts__list"><div class="v2-facts__item" data-reveal="up" style="--i: 0" data-es-block="fact_1">
          <dt><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>Zone d'intervention</dt>
          <dd>Aix-en-Provence et alentours</dd>
        </div><div class="v2-facts__item" data-reveal="up" style="--i: 1" data-es-block="fact_2">
          <dt><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Horaires</dt>
          <dd>Du lundi au vendredi, de 8 h à 18 h</dd>
        </div></dl>
  </div>
</section>


</div>
<div id="shopify-section-template--es__v2_cta_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_cta_1" data-es-type="v2-cta"><section class="v2-cta v2-cta--split color-scheme-3" style="--pt: 112px; --pb: 112px;">
  <div class="es-container">
    <div class="v2-cta__inner">
      <div class="v2-cta__copy"><h2 class="v2-h2 v2-cta__title" data-reveal="up">Et si l’on parlait de votre jardin ?</h2><div class="v2-rte v2-lead-sm" data-reveal="up"><p>Un lieu, quelques envies, un premier échange pour préciser votre projet.</p></div><div class="v2-actions" data-reveal="up"><a class="v2-btn v2-btn--primary" href="{/literal}{$urls.base_url}{literal}pages/contact">Demander un devis<span class="v2-btn__arrow" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></span></a><a class="v2-btn v2-btn--ghost" href="{/literal}{$urls.base_url}{literal}pages/prestations">Nos prestations</a></div>
      </div><dl class="v2-cta__facts" data-reveal="up"><div data-es-block="fact_3"><dt>Zone d'intervention</dt><dd>Aix-en-Provence et alentours</dd></div></dl></div>
  </div>
</section>


</div>{/literal}