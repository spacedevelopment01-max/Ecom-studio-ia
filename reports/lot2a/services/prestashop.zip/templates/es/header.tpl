{literal}<div id="shopify-section-template--es__announcement_bar_1" class="shopify-section es-announcement-section" data-es-section="group:header:announcement_bar_1" data-es-type="announcement-bar"><div class="es-announcement es-announcement--rotate color-scheme-3" role="region" aria-label="Annonce"><div class="es-announcement__track es-announcement__track--rotate" style="--count: 2"><p class="es-announcement__item" data-es-block="announcement_1">Aix-en-Provence et alentours</p><p class="es-announcement__item" data-es-block="announcement_2">Du lundi au vendredi, de 8 h à 18 h</p></div></div>
</div><div id="shopify-section-template--es__header_1" class="shopify-section es-header-section" data-es-section="group:header:header_1" data-es-type="header"><header class="es-header es-header--reference-studio es-header--shape-bar es-header--icons-plain es-header--sticky color-scheme-1" data-header>
  <div class="es-header__inner es-container">
    <button class="es-header__burger es-icon-button" type="button" aria-controls="MobileMenu" aria-expanded="false" data-menu-open>
      <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7h18M3 12h18M3 17h18"/></svg><span class="visually-hidden">Menu</span>
    </button>

    <a href="{/literal}{$urls.base_url}{literal}" class="es-header__logo" aria-label="Racines & Pierres"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-logo-xijm8l.png" alt="Racines &amp; Pierres" class="es-header__logo-img" width="150" height="50" loading="eager"></a>

    <nav class="es-header__nav" aria-label="Navigation principale">
      <ul role="list"><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}" class="es-nav__link"><span>Accueil</span></a></li><li class="es-nav__item es-nav__item--parent">
            <a href="{/literal}{$urls.base_url}{literal}pages/prestations" class="es-nav__link" aria-haspopup="true"><span>Prestations</span><span class="es-nav__caret" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg></span></a><ul class="es-dropdown color-scheme-1" role="list"><li>
                      <a href="{/literal}{$urls.base_url}{literal}pages/prestations"><span>Création de jardin</span></a></li><li>
                      <a href="{/literal}{$urls.base_url}{literal}pages/prestations"><span>Terrasses et aménagements</span></a></li><li>
                      <a href="{/literal}{$urls.base_url}{literal}pages/prestations"><span>Entretien à l’année</span></a></li></ul></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/a-propos" class="es-nav__link"><span>À propos</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/faq" class="es-nav__link"><span>FAQ</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-nav__link"><span>Demande de devis</span></a></li></ul>
    </nav>

    <div class="es-header__icons"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button es-button--small es-header__cta"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><span>Demander un devis</span></a></div>
  </div>

  <div class="es-mobile-menu es-mobile-menu--sheet es-mobile-menu--sub-accordion color-scheme-1" id="MobileMenu" hidden data-mobile-menu>
    <div class="es-mobile-menu__head">
      <span class="es-header__wordmark">Racines & Pierres</span>
      <button type="button" class="es-icon-button" data-menu-close aria-label="Fermer"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 5 14 14M19 5 5 19"/></svg></button>
    </div><ul role="list" class="es-mobile-menu__list"><li style="--i: 1"><a href="{/literal}{$urls.base_url}{literal}" class="es-mm__link"><span>Accueil</span></a></li><li style="--i: 2"><details class="es-mm__group">
              <summary class="es-mm__link"><span>Prestations</span><span class="es-mm__caret" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg></span></summary>
              <ul role="list" class="es-mm__sub"><li>
                    <a href="{/literal}{$urls.base_url}{literal}pages/prestations"><span>Création de jardin</span></a></li><li>
                    <a href="{/literal}{$urls.base_url}{literal}pages/prestations"><span>Terrasses et aménagements</span></a></li><li>
                    <a href="{/literal}{$urls.base_url}{literal}pages/prestations"><span>Entretien à l’année</span></a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/prestations" class="es-mm__all">Tout voir</a></li>
              </ul>
            </details></li><li style="--i: 3"><a href="{/literal}{$urls.base_url}{literal}pages/a-propos" class="es-mm__link"><span>À propos</span></a></li><li style="--i: 4"><a href="{/literal}{$urls.base_url}{literal}pages/faq" class="es-mm__link"><span>FAQ</span></a></li><li style="--i: 5"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-mm__link"><span>Demande de devis</span></a></li></ul><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button es-button--full es-mobile-menu__cta"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg><span>Demander un devis</span></a><ul class="es-social" role="list"></ul>

  </div>
</header>




</div>{/literal}