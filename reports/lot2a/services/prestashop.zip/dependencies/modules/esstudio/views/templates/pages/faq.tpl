{literal}<div id="shopify-section-template--es__faq_4" class="shopify-section es-section-wrapper" data-es-section="page.faq:faq_4" data-es-type="faq"><section class="es-section es-faq es-faq--cards es-faq--side es-faq--cols-1 color-scheme-1" style="--pt: 104px; --pb: 104px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Questions fréquentes</h2></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_4"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="question_16">
          <summary><span class="es-faq__q">Comment obtenir un devis ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Décrivez votre projet dans le formulaire de la page Contact ; nous revenons vers vous avec une proposition détaillée.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="question_17">
          <summary><span class="es-faq__q">Où intervenez-vous ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Aix-en-Provence et alentours</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="question_18">
          <summary><span class="es-faq__q">Quels sont vos horaires ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Du lundi au vendredi, de 8 h à 18 h</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 3" data-faq-item data-es-block="question_19">
          <summary><span class="es-faq__q">Quels sont vos tarifs ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : vos tarifs, ou la façon dont ils sont établis]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 4" data-faq-item data-es-block="question_20">
          <summary><span class="es-faq__q">Comment se déroule une première prestation ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : le déroulement d'une première prestation]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 5" data-faq-item data-es-block="question_21">
          <summary><span class="es-faq__q">Quels moyens de paiement acceptez-vous ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : les moyens de paiement acceptés]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 6" data-faq-item data-es-block="question_22">
          <summary><span class="es-faq__q">Comment commencer un projet ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Décrivez le lieu, vos envies et les aménagements envisagés. Cet exemple utilise une demande de devis ; aucun professionnel réel n’est contacté.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 7" data-faq-item data-es-block="question_23">
          <summary><span class="es-faq__q">Peut-on demander uniquement de l’entretien ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Oui, l’entretien à l’année fait partie des prestations de cette entreprise fictive.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Comment obtenir un devis ?", "acceptedAnswer": { "@type": "Answer", "text": "Décrivez votre projet dans le formulaire de la page Contact ; nous revenons vers vous avec une proposition détaillée." } },{ "@type": "Question", "name": "Où intervenez-vous ?", "acceptedAnswer": { "@type": "Answer", "text": "Aix-en-Provence et alentours" } },{ "@type": "Question", "name": "Quels sont vos horaires ?", "acceptedAnswer": { "@type": "Answer", "text": "Du lundi au vendredi, de 8 h à 18 h" } },{ "@type": "Question", "name": "Quels sont vos tarifs ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : vos tarifs, ou la façon dont ils sont établis]" } },{ "@type": "Question", "name": "Comment se déroule une première prestation ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : le déroulement d'une première prestation]" } },{ "@type": "Question", "name": "Quels moyens de paiement acceptez-vous ?", "acceptedAnswer": { "@type": "Answer", "text": "[À compléter : les moyens de paiement acceptés]" } },{ "@type": "Question", "name": "Comment commencer un projet ?", "acceptedAnswer": { "@type": "Answer", "text": "Décrivez le lieu, vos envies et les aménagements envisagés. Cet exemple utilise une demande de devis ; aucun professionnel réel n’est contacté." } },{ "@type": "Question", "name": "Peut-on demander uniquement de l’entretien ?", "acceptedAnswer": { "@type": "Answer", "text": "Oui, l’entretien à l’année fait partie des prestations de cette entreprise fictive." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__contact_form_3" class="shopify-section " data-es-section="page.faq:contact_form_3" data-es-type="contact-form"><section class="es-section es-contact color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-contact__grid">
    <header class="es-contact__intro"><h2 class="es-heading es-h2" data-reveal="words">Une autre question ?</h2><div class="es-rte es-contact__text" data-reveal="up"><p>Démonstration du studio : données de test uniquement. Aucun message n’est adressé à une entreprise réelle.</p></div><ul class="es-contact__details" role="list" data-reveal="up" style="--d: 1"><li><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span>Du lundi au vendredi, de 8 h à 18 h</span></li></ul></header><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="ContactForm" class="es-form es-contact__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><div class="es-form__row">
        <label>Nom<input type="text" name="contact[name]" autocomplete="name" value=""></label>
        <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label>
      </div>
      <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
      <label>Message<textarea name="contact[body]" rows="6" class="es-textarea"></textarea></label>
      <button type="submit" class="es-button">Envoyer</button></form></div>
</section>





</div>{/literal}