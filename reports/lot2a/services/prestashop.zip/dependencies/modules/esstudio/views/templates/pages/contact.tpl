{literal}<div id="shopify-section-template--es__booking_1" class="shopify-section es-section-wrapper" data-es-section="page.contact:booking_1" data-es-type="booking"><section class="es-section es-booking es-booking--form color-scheme-1" style="--pt: 96px; --pb: 96px; --embed-h: 700px;">
  <div class="es-container es-booking__grid">
    <div class="es-booking__intro"><p class="es-eyebrow" data-reveal="up">Devis</p><h2 class="es-heading es-h2" data-reveal="words">Demander un devis</h2><div class="es-rte es-lead" data-reveal="up"><p>Décrivez votre projet : nous revenons vers vous avec une proposition détaillée.</p></div><ol class="es-booking__steps" role="list" data-reveal="up" style="--d: 1"><li data-es-block="step_13"><span class="es-booking__step-num" aria-hidden="true">1</span><span><strong>Décrivez votre projet</strong><span class="es-booking__step-text">Quelques lignes suffisent : le besoin, le lieu, vos contraintes.</span></span></li><li data-es-block="step_14"><span class="es-booking__step-num" aria-hidden="true">2</span><span><strong>Recevez votre devis</strong><span class="es-booking__step-text">Une proposition détaillée, établie d'après votre demande.</span></span></li><li data-es-block="step_15"><span class="es-booking__step-num" aria-hidden="true">3</span><span><strong>Nous réalisons</strong><span class="es-booking__step-text">Le travail est réalisé selon ce qui a été convenu ensemble.</span></span></li></ol></div>

    <div class="es-booking__panel es-glow is-lit" data-reveal="up" style="--d: 1"><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="BookingForm-template--es__booking_1" class="es-form es-booking__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><input type="hidden" name="contact[Demande]" value="Demander un devis">
            <div class="es-form__row">
              <label>Nom *<input type="text" name="contact[name]" autocomplete="name" required value=""></label>
              <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
            </div>
            <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label><label>Prestation souhaitée
                <select name="contact[Prestation souhaitée]">
                  <option value="">Choisir une prestation</option><option value="Création de jardin">Création de jardin</option><option value="Terrasses et aménagements">Terrasses et aménagements</option><option value="Entretien à l’année">Entretien à l’année</option></select>
              </label><label>Message<textarea name="contact[body]" rows="4" class="es-textarea"></textarea></label>
            <button type="submit" class="es-button es-button--full">Envoyer ma demande</button></form></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__practical_info_1" class="shopify-section es-section-wrapper" data-es-section="page.contact:practical_info_1" data-es-type="practical-info"><section class="es-section es-info color-scheme-2" style="--pt: 104px; --pb: 104px;">
  <div class="es-container">
    <header class="es-info__head"><p class="es-eyebrow" data-reveal="up">Infos pratiques</p><h2 class="es-heading es-h2" data-reveal="words">Nous trouver, nous joindre</h2></header>

    <div class="es-info__grid">
      <div class="es-info__cards"><div class="es-info__card es-info__card--hours" data-reveal="up">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Horaires</h3>
            <dl class="es-info__hours"><div class="es-info__row"><dt>Du lundi au vendredi, de 8 h à 18 h</dt><dd></dd></div></dl></div><div class="es-info__card" data-reveal="up" style="--d: 1">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>Adresse</h3><p class="es-info__area"><span class="es-info__label">Zone d'intervention</span>Aix-en-Provence et alentours</p></div><div class="es-info__card es-info__card--contact" data-reveal="up" style="--d: 2">
            <h3 class="es-info__title"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg>Nous joindre</h3><a class="es-info__phone" href="tel:[Àcompléter:téléphone]"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg><span>[À compléter : téléphone]</span></a></div></div></div>
  </div>
</section>






</div>{/literal}