{literal}<div id="shopify-section-template--es__main_page_1" class="shopify-section " data-es-section="page:main_page_1" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--narrow" style="--pt: 64px; --pb: 96px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Conditions générales de prestation</h1>
    <div class="es-rte es-page__content" data-reveal="up"><p><strong>Prestations</strong><br>Création de jardin ; Terrasses et aménagements ; Entretien à l’année.</p><p><strong>Tarifs</strong><br>Chaque demande fait l'objet d'un devis. [À compléter : modalités du devis]</p><p><strong>Devis et réservation</strong><br>[À compléter : conditions de devis, d'acompte et de confirmation]</p><p><strong>Annulation et report</strong><br>[À compléter : délai et conditions d'annulation]</p><p><strong>Paiement</strong><br>[À compléter : moyens et échéances de paiement]</p><p><strong>Responsabilité et assurance</strong><br>[À compléter : assurance professionnelle et responsabilités]</p></div>
  </div>
</section>


</div>{/literal}