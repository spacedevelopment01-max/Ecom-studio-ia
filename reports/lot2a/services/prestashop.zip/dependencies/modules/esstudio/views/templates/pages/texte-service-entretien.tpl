{literal}<div id="shopify-section-template--es__reference_opening" class="shopify-section reference-section" data-es-section="page.seo-service-entretien:reference_opening" data-es-type="ref-hero"><section class="ref-section ref-hero ref-hero--landscape color-scheme-1" data-reference="hero" data-ref-motion="reveal" style="--ref-pt: 32px; --ref-pb: 32px;" aria-labelledby="RefTitle-template--es__reference_opening">
  <div class="ref-shell ref-hero__grid">
    <div class="ref-hero__copy">
      <p class="ref-label">Racines &amp; Pierres</p>
      <h1 id="RefTitle-template--es__reference_opening" class="ref-hero__title">Entretien à l’année</h1>
      
      <div class="ref-actions"><a class="ref-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Parlons de votre projet<span aria-hidden="true">↗</span></a></div>
    </div>
    <figure class="ref-hero__media"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-prestation-qxk5rr-qxk5rr.jpg" alt="Entretien à l’année" class="ref-image" width="1600" height="1600" loading="eager" decoding="async" fetchpriority="high"></figure>
  </div>
</section>

</div>
<div id="shopify-section-template--es__seo_body" class="shopify-section es-section-wrapper" data-es-section="page.seo-service-entretien:seo_body" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--plain color-scheme-1" style="--pt: 48px; --pb: 48px;">
  <div class="es-container es-richtext__inner es-richtext__inner--left"><div class="es-rte es-lead" data-reveal="up" data-es-block="body"><p>Taille, tonte, désherbage et suivi des plantations. Accompagner le jardin au fil des saisons, selon ses besoins.</p>
<h2>Un projet qui part de vos usages.</h2>
<p>Nous commençons par préciser les envies, les usages et les contraintes du lieu. Le périmètre des travaux et les matériaux sont discutés avant l’établissement du devis.</p>
<h2>Ce que nous préparons ensemble.</h2>
<ul><li>Les espaces à aménager et leur utilisation.</li><li>Les matières et les plantations à envisager.</li><li>Le périmètre de la prestation et les informations nécessaires au devis.</li></ul>
<p>Entreprise fictive et illustration de démonstration. Aucun engagement commercial réel.</p></div></div>
</section>


</div>{/literal}