{literal}<div id="shopify-section-template--es__legal_page_1" class="shopify-section es-section-wrapper" data-es-section="page.legal:legal_page_1" data-es-type="legal-page"><section class="es-section es-legal color-scheme-1" style="--pt: 64px; --pb: 96px;" data-legal>
  <div class="es-legal__progress" aria-hidden="true"><span data-legal-bar></span></div>
  <div class="es-container">
    <header class="es-legal__head"><p class="es-eyebrow">Informations légales</p><h1 class="es-heading es-h2 es-legal__title">Mentions légales</h1><div class="es-legal__meta"><p class="es-legal__date"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span>Dernière mise à jour : [À compléter : date]</span></p><button type="button" class="es-legal__print" data-legal-print>Imprimer</button></div></header>
    <div class="es-legal__layout"><nav class="es-legal__toc" aria-labelledby="LegalToc-template--es__legal_page_1" data-legal-toc>
          <details class="es-legal__details" open data-legal-details>
            <summary id="LegalToc-template--es__legal_page_1">Sommaire</summary>
            <ol class="es-legal__toclist" data-legal-toclist><li><a href="#template--es__legal_page_1-part-1">Éditeur du site</a></li><li><a href="#template--es__legal_page_1-part-2">Contact</a></li><li><a href="#template--es__legal_page_1-part-3">Directeur de la publication</a></li><li><a href="#template--es__legal_page_1-part-4">Hébergement</a></li><li><a href="#template--es__legal_page_1-part-5">Activité réglementée</a></li><li><a href="#template--es__legal_page_1-part-6">Propriété intellectuelle</a></li><li><a href="#template--es__legal_page_1-part-7">Données personnelles</a></li></ol>
          </details>
        </nav><article class="es-legal__body es-rte" data-legal-body><section class="es-legal__part" aria-labelledby="template--es__legal_page_1-part-1" data-es-block="part_1">
              <h2 id="template--es__legal_page_1-part-1">Éditeur du site</h2>
              <p>Racines &amp; Pierres — [À compléter : forme juridique, adresse du siège, numéro d'immatriculation (SIRET, RCS ou RM)]</p>
            </section><section class="es-legal__part" aria-labelledby="template--es__legal_page_1-part-2" data-es-block="part_2">
              <h2 id="template--es__legal_page_1-part-2">Contact</h2>
              <p>[À compléter : téléphone et e-mail]</p>
            </section><section class="es-legal__part" aria-labelledby="template--es__legal_page_1-part-3" data-es-block="part_3">
              <h2 id="template--es__legal_page_1-part-3">Directeur de la publication</h2>
              <p>[À compléter : prénom et nom]</p>
            </section><section class="es-legal__part" aria-labelledby="template--es__legal_page_1-part-4" data-es-block="part_4">
              <h2 id="template--es__legal_page_1-part-4">Hébergement</h2>
              <p>[À compléter : nom, adresse et téléphone de l'hébergeur du site]</p>
            </section><section class="es-legal__part" aria-labelledby="template--es__legal_page_1-part-5" data-es-block="part_5">
              <h2 id="template--es__legal_page_1-part-5">Activité réglementée</h2>
              <p>[À compléter : ordre ou chambre professionnelle, assurance, numéro d'inscription — le cas échéant]</p>
            </section><section class="es-legal__part" aria-labelledby="template--es__legal_page_1-part-6" data-es-block="part_6">
              <h2 id="template--es__legal_page_1-part-6">Propriété intellectuelle</h2>
              <p>Les textes, images et logos de ce site appartiennent à Racines &amp; Pierres ou sont utilisés avec l'accord de leurs auteurs. Toute reproduction sans autorisation est interdite.</p>
            </section><section class="es-legal__part" aria-labelledby="template--es__legal_page_1-part-7" data-es-block="part_7">
              <h2 id="template--es__legal_page_1-part-7">Données personnelles</h2>
              <p>Les informations transmises via les formulaires servent uniquement à répondre à votre demande. Voir la politique de confidentialité pour le détail de vos droits.</p>
            </section><p class="es-legal__top"><a href="#LegalTop-template--es__legal_page_1" data-legal-top><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20V4M6 10l6-6 6 6"/></svg>Revenir en haut de la page</a></p>
      </article>
    </div>
  </div>
  <span id="LegalTop-template--es__legal_page_1" class="es-legal__anchor"></span>
</section>






</div>{/literal}