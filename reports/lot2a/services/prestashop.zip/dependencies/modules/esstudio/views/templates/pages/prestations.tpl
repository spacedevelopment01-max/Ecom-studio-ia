{literal}<div id="shopify-section-template--es__services_list_1" class="shopify-section es-section-wrapper" data-es-section="page.services:services_list_1" data-es-type="services-list"><section class="es-section es-svc es-svc--list color-scheme-1" style="--pt: 104px; --pb: 104px; --cols: 3;">
  <div class="es-container"><header class="es-svc__head es-svc__head--split">
        <div><p class="es-eyebrow" data-reveal="up">Prestations</p><h2 class="es-heading es-h2" data-reveal="words">Nos prestations</h2></div></header><ul class="es-svc__list" role="list"><li class="es-svc__item es-glow" data-reveal="up" style="--i: 0" data-es-block="service_1"><div class="es-svc__body">
            <div class="es-svc__top"><span class="es-svc__num" aria-hidden="true">01</span></div>
            <h3 class="es-heading es-h4 es-svc__title">Création de jardin</h3><div class="es-rte es-svc__text"><p>Dessiner les volumes, choisir les végétaux et organiser les cheminements. Un projet pensé pour votre terrain et votre façon de vivre dehors.</p></div></div><div class="es-svc__action">
              <a class="es-link-arrow es-svc__link" href="{/literal}{$urls.base_url}{literal}pages/contact">
                <span>Demander un devis</span><span class="visually-hidden"> — Création de jardin</span><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>
              </a>
            </div></li><li class="es-svc__item es-glow" data-reveal="up" style="--i: 1" data-es-block="service_2"><div class="es-svc__body">
            <div class="es-svc__top"><span class="es-svc__num" aria-hidden="true">02</span></div>
            <h3 class="es-heading es-h4 es-svc__title">Terrasses et aménagements</h3><div class="es-rte es-svc__text"><p>Bois, pierre sèche, jardinières et éclairage : composer des espaces où l’on aime s’installer, recevoir et circuler.</p></div></div><div class="es-svc__action">
              <a class="es-link-arrow es-svc__link" href="{/literal}{$urls.base_url}{literal}pages/contact">
                <span>Demander un devis</span><span class="visually-hidden"> — Terrasses et aménagements</span><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>
              </a>
            </div></li><li class="es-svc__item es-glow" data-reveal="up" style="--i: 2" data-es-block="service_3"><div class="es-svc__body">
            <div class="es-svc__top"><span class="es-svc__num" aria-hidden="true">03</span></div>
            <h3 class="es-heading es-h4 es-svc__title">Entretien à l’année</h3><div class="es-rte es-svc__text"><p>Taille, tonte, désherbage et suivi des plantations. Accompagner le jardin au fil des saisons, selon ses besoins.</p></div></div><div class="es-svc__action">
              <a class="es-link-arrow es-svc__link" href="{/literal}{$urls.base_url}{literal}pages/contact">
                <span>Demander un devis</span><span class="visually-hidden"> — Entretien à l’année</span><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg>
              </a>
            </div></li></ul></div>
</section>




</div>
<div id="shopify-section-template--es__how_to_1" class="shopify-section es-section-wrapper" data-es-section="page.services:how_to_1" data-es-type="how-to"><section class="es-section es-howto es-howto--horizontal es-howto--landscape color-scheme-1" style="--pt: 104px; --pb: 104px; --n: 3;" data-howto>
  <div class="es-container">
    <header class="es-howto__head"><p class="es-eyebrow" data-reveal="up">Notre méthode</p><h2 class="es-heading es-h2" data-reveal="words">Comment ça se passe</h2></header>
    <ol class="es-howto__list" role="list" data-howto-list>
      <li class="es-howto__rail" aria-hidden="true"><span class="es-howto__fill"></span></li><li class="es-howto__step is-lit" data-howto-step style="--i: 0" data-es-block="step_7">
          <span class="es-howto__node" aria-hidden="true"><span>01</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 1</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Décrivez votre projet</h3><div class="es-rte"><p>Quelques lignes suffisent : le besoin, le lieu, vos contraintes.</p></div></div>
        </li><li class="es-howto__step" data-howto-step style="--i: 1" data-es-block="step_8">
          <span class="es-howto__node" aria-hidden="true"><span>02</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 2</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Recevez votre devis</h3><div class="es-rte"><p>Une proposition détaillée, établie d'après votre demande.</p></div></div>
        </li><li class="es-howto__step" data-howto-step style="--i: 2" data-es-block="step_9">
          <span class="es-howto__node" aria-hidden="true"><span>03</span></span><div class="es-howto__body">
            <p class="es-howto__kicker"><span>Étape 3</span></p>
            <h3 class="es-heading es-h4 es-howto__title">Nous réalisons</h3><div class="es-rte"><p>Le travail est réalisé selon ce qui a été convenu ensemble.</p></div></div>
        </li></ol><div class="es-actions es-actions--center"><a class="es-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Demander un devis</a></div></div>
</section>






</div>
<div id="shopify-section-template--es__faq_3" class="shopify-section es-section-wrapper" data-es-section="page.services:faq_3" data-es-type="faq"><section class="es-section es-faq es-faq--lines es-faq--side es-faq--cols-1 color-scheme-2" style="--pt: 96px; --pb: 96px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Bon à savoir</h2></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_3"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="question_13">
          <summary><span class="es-faq__q">Quels sont vos tarifs ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : vos tarifs, ou la façon dont ils sont établis]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="question_14">
          <summary><span class="es-faq__q">Comment se déroule une première prestation ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : le déroulement d'une première prestation]</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="question_15">
          <summary><span class="es-faq__q">Quels moyens de paiement acceptez-vous ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>[À compléter : les moyens de paiement acceptés]</p></div></div>
        </details></div>
  </div></section>






</div>
<div id="shopify-section-template--es__cta_banner_2" class="shopify-section es-section-wrapper" data-es-section="page.services:cta_banner_2" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-3 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.45;"><div class="es-cta__media" data-parallax="0.2"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-4-ft8gxd.jpg" alt="" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Et si l’on parlait de votre jardin ?</h2><div class="es-rte es-lead" data-reveal="up"><p>Un lieu, quelques envies, un premier échange pour préciser votre projet.</p></div><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button" data-reveal="up" style="--d: 1">Demander un devis <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>





</div>{/literal}