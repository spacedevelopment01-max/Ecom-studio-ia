{literal}<div id="shopify-section-template--es__footer_1" class="shopify-section es-footer-section" data-es-section="group:footer:footer_1" data-es-type="footer"><footer class="es-footer es-footer--reference-shop es-ambient color-scheme-3">
  <div class="es-container"><p class="ref-footer__signature" translate="no">ARVEN</p><div class="es-footer__layout"><div class="es-footer__brandcol">
          <a href="{/literal}{$urls.base_url}{literal}" class="es-footer__brand color-scheme-1 ref-footer__logo-surface"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-logo-bs2w9b.png" alt="ARVEN" width="150" height="50" loading="lazy"></a><ul class="es-social" role="list"></ul>

        </div><div class="es-footer__grid"><div class="es-footer__block es-footer__block--text" data-es-block="text_4"><h2 class="es-footer__heading">ARVEN</h2><div class="es-rte"><p>ARVEN, marque de démonstration. Acier et cuir véritable.</p></div></div><div class="es-footer__block es-footer__block--links" data-es-block="links_1"><h2 class="es-footer__heading">Boutique</h2>
                <ul role="list" class="es-footer__links"><li><a href="{/literal}{$urls.base_url}{literal}">Accueil</a></li><li><a href="{/literal}{$urls.base_url}{literal}collections/all">Boutique</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/notre-histoire">Notre histoire</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/faq">FAQ</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/contact">Contact</a></li></ul></div><div class="es-footer__block es-footer__block--links" data-es-block="links_2"><h2 class="es-footer__heading">Aide</h2>
                <ul role="list" class="es-footer__links"><li><a href="{/literal}{$urls.base_url}{literal}pages/livraison-et-retours">Livraison et retours</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/contact">Contact</a></li><li><a href="{/literal}{$urls.pages.search}{literal}">Recherche</a></li></ul></div><div class="es-footer__block es-footer__block--newsletter" data-es-block="newsletter_1"><h2 class="es-footer__heading">Restons en contact</h2><p class="es-muted">Démonstration — aucune inscription réelle.</p><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" class="es-newsletter-form" id="FooterNewsletter"><input type="hidden" name="form_type" value="customer"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><input type="hidden" name="contact[tags]" value="newsletter">
                  <label class="visually-hidden" for="FooterEmail">Votre adresse e-mail</label>
                  <div class="es-inline-field">
                    <input id="FooterEmail" type="email" name="contact[email]" required autocomplete="email" placeholder="Votre adresse e-mail">
                    <button type="submit" class="es-button es-button--small">S'inscrire</button>
                  </div></form></div></div></div><div class="es-footer__bottom">
      <p>&copy; 2026 ARVEN</p><ul role="list" class="es-footer__policies"><li><a href="{/literal}{$urls.base_url}{literal}policies/terms-of-service">Conditions générales de vente</a></li><li><a href="{/literal}{$urls.base_url}{literal}policies/privacy-policy">Politique de confidentialité</a></li><li><a href="{/literal}{$urls.base_url}{literal}policies/refund-policy">Politique de remboursement</a></li><li><a href="{/literal}{$urls.base_url}{literal}policies/legal-notice">Mentions légales</a></li></ul><ul class="es-footer__payment" role="list"></ul></div>
  </div>
</footer>




</div>
    <div class="es-toast" role="status" aria-live="polite" hidden></div>
  </body>
</html>{/literal}