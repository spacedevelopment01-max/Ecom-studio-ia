{literal}<div id="shopify-section-template--es__main_page_2" class="shopify-section " data-es-section="page.shipping:main_page_2" data-es-type="main-page"><section class="es-section es-page color-scheme-1 es-page--narrow" style="--pt: 64px; --pb: 96px;">
  <div class="es-container es-page__inner">
    <h1 class="es-heading es-h1" data-reveal="lines">Livraison et retours</h1>
    <div class="es-rte es-page__content" data-reveal="up"><p>Les conditions détaillées figurent ci-dessous.</p></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__rich_text_2" class="shopify-section es-section-wrapper" data-es-section="page.shipping:rich_text_2" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--plain color-scheme-2" style="--pt: 64px; --pb: 64px;">
  <div class="es-container es-richtext__inner es-richtext__inner--left"><h2 class="es-heading es-h3" data-reveal="words" data-es-block="heading_2">Livraison et retours</h2><div class="es-rte es-lead" data-reveal="up" data-es-block="text_3"><p><strong>Livraison :</strong> [À compléter : délais et tarifs de livraison]</p><p><strong>Retours :</strong> [À compléter : conditions de retour]</p><p><strong>Contact :</strong> [À compléter : adresse e-mail du service client]</p></div></div>
</section>


</div>{/literal}