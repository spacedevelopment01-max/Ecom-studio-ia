{literal}<div id="shopify-section-template--es__faq_2" class="shopify-section es-section-wrapper" data-es-section="page.faq:faq_2" data-es-type="faq"><section class="es-section es-faq es-faq--cards es-faq--side es-faq--cols-1 color-scheme-1" style="--pt: 96px; --pb: 96px;" data-es-faq>
  <div class="es-container es-faq__grid">
    <header class="es-faq__head"><h2 class="es-heading es-h2" data-reveal="words">Les réponses, simplement.</h2></header>
    <div class="es-faq__list" id="FaqList-template--es__faq_2"><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 0" data-faq-item data-es-block="question_7">
          <summary><span class="es-faq__q">Quelles matières sont présentées ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Le boîtier est en acier poli et le bracelet en cuir brun surpiqué, doublé de tissu bleu.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 1" data-faq-item data-es-block="question_8">
          <summary><span class="es-faq__q">Le prix affiché permet-il de commander ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Le prix de 129 € est fictif et sert uniquement à tester le parcours. Aucun paiement ni achat réel n’est possible dans cette démonstration.</p></div></div>
        </details><details class="es-accordion es-faq__item" data-reveal="up" style="--i: 2" data-faq-item data-es-block="question_9">
          <summary><span class="es-faq__q">Quelles informations restent à confirmer ?</span>
            <span class="es-faq__icon" aria-hidden="true"><i></i><i></i></span>
          </summary>
          <div class="es-faq__panel" data-faq-panel><div class="es-rte es-accordion__body"><p>Les dimensions, le mouvement, l’étanchéité et les conditions de livraison doivent être renseignés par le marchand avant toute publication.</p></div></div>
        </details></div>
  </div><script type="application/ld+json">
    { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "Quelles matières sont présentées ?", "acceptedAnswer": { "@type": "Answer", "text": "Le boîtier est en acier poli et le bracelet en cuir brun surpiqué, doublé de tissu bleu." } },{ "@type": "Question", "name": "Le prix affiché permet-il de commander ?", "acceptedAnswer": { "@type": "Answer", "text": "Le prix de 129 € est fictif et sert uniquement à tester le parcours. Aucun paiement ni achat réel n’est possible dans cette démonstration." } },{ "@type": "Question", "name": "Quelles informations restent à confirmer ?", "acceptedAnswer": { "@type": "Answer", "text": "Les dimensions, le mouvement, l’étanchéité et les conditions de livraison doivent être renseignés par le marchand avant toute publication." } }] }
  </script></section>






</div>
<div id="shopify-section-template--es__contact_form_1" class="shopify-section " data-es-section="page.faq:contact_form_1" data-es-type="contact-form"><section class="es-section es-contact color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-contact__grid">
    <header class="es-contact__intro"><h2 class="es-heading es-h2" data-reveal="words">Une autre question ?</h2><div class="es-rte es-contact__text" data-reveal="up"><p>Démonstration du studio : données de test uniquement. Aucun message n’est adressé à une entreprise réelle.</p></div></header><form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" id="ContactForm" class="es-form es-contact__form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓"><div class="es-form__row">
        <label>Nom<input type="text" name="contact[name]" autocomplete="name" value=""></label>
        <label>E-mail *<input type="email" name="contact[email]" autocomplete="email" required value=""></label>
      </div>
      <label>Téléphone<input type="tel" name="contact[phone]" autocomplete="tel" value=""></label>
      <label>Message<textarea name="contact[body]" rows="6" class="es-textarea"></textarea></label>
      <button type="submit" class="es-button">Envoyer</button></form></div>
</section>





</div>{/literal}