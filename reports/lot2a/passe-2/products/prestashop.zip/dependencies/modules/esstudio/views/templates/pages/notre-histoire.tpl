{literal}<div id="shopify-section-template--es__rich_text_1" class="shopify-section es-section-wrapper" data-es-section="page.about:rich_text_1" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--statement color-scheme-1" style="--pt: 120px; --pb: 64px;">
  <div class="es-container es-richtext__inner es-richtext__inner--center"><p class="es-eyebrow" data-reveal="up" data-es-block="eyebrow_2">Notre histoire</p><h2 class="es-heading es-h1" data-reveal="words" data-es-block="heading_1">Le goût des choses que l’on garde.</h2><div class="es-rte es-lead" data-reveal="up" data-es-block="text_2"><p>Un boîtier d’acier, un bracelet de cuir et des détails que l’on découvre en prenant le temps. ARVEN explore le caractère de l’objet au quotidien.</p></div></div>
</section>


</div>
<div id="shopify-section-template--es__image_with_text_1" class="shopify-section es-section-wrapper" data-es-section="page.about:image_with_text_1" data-es-type="image-with-text"><section class="es-section es-iwt es-iwt--image-left color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container es-iwt__grid">
    <div class="es-iwt__media es-media-frame es-media-frame--portrait" data-reveal="curtain" data-scroll-zoom>
      <img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-scene-1-n8quha.jpg" alt="Une présence au quotidien." class="es-cover" width="1600" height="1600" loading="lazy" decoding="async">
    </div>
    <div class="es-iwt__content"><h2 class="es-heading es-h2" data-reveal="words">Une présence au quotidien.</h2>
      <div class="es-rte" data-reveal="up" style="--d: 1"><p>ARVEN est une marque de démonstration du studio. Les matières décrites correspondent aux visuels ; les dimensions et performances restent à préciser par le marchand.</p></div></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__features_grid_1" class="shopify-section es-section-wrapper" data-es-section="page.about:features_grid_1" data-es-type="features-grid"><section class="es-section es-features es-features--glow es-ambient es-ambient--left color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container">
    <header class="es-section-head es-section-head--left"><h2 class="es-heading es-h2" data-reveal="words">Ce qui nous guide</h2></header>
    <div class="es-features__grid" style="--cols: 2" data-reveal-stagger><article class="es-feature es-glow" data-reveal="up" style="--i: 0" data-es-block="feature_1"><span class="es-feature__index">01</span><span class="es-feature__tile"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></svg></span><h3 class="es-heading es-h4">L’acier et le cuir</h3>
          <div class="es-rte es-muted"><p>Le contraste d’un boîtier poli et d’un bracelet brun surpiqué.</p></div></article><article class="es-feature es-glow" data-reveal="up" style="--i: 1" data-es-block="feature_2"><span class="es-feature__index">02</span><span class="es-feature__tile"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></svg></span><h3 class="es-heading es-h4">Le sens du détail</h3>
          <div class="es-rte es-muted"><p>Le cadran noir dialogue avec les compteurs argentés et la doublure bleue.</p></div></article></div>
  </div>
</section>




</div>
<div id="shopify-section-template--es__cta_banner_1" class="shopify-section es-section-wrapper" data-es-section="page.about:cta_banner_1" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-3 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.45;"><div class="es-cta__media" data-parallax="0.2"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-hero-n8quha.jpg" alt="" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Prenez le temps de la découvrir.</h2><div class="es-rte es-lead" data-reveal="up"><p>Retrouvez les photographies et les informations de la montre sur sa fiche.</p></div><a href="{/literal}{$urls.base_url}{literal}products/montre-acier-et-cuir" class="es-button" data-reveal="up" style="--d: 1">Découvrir la montre <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>





</div>{/literal}