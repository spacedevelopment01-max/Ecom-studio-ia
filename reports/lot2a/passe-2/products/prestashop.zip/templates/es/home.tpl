{literal}<div id="shopify-section-template--es__ref_hero_1" class="shopify-section reference-section" data-es-section="index:ref_hero_1" data-es-type="ref-hero"><section class="ref-section ref-hero ref-hero--object color-scheme-1" data-reference="hero" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;" aria-labelledby="RefTitle-template--es__ref_hero_1">
  <div class="ref-shell ref-hero__grid">
    <div class="ref-hero__copy">
      <p class="ref-label">ARVEN</p>
      <h1 id="RefTitle-template--es__ref_hero_1" class="ref-hero__title">Le temps, bien porté.</h1>
      <div class="ref-prose ref-hero__text"><p>L’acier poli, le cuir brun, un cadran que l’on aime regarder. Une montre qui se découvre dans les détails.</p></div>
      <div class="ref-actions"><a class="ref-button" href="{/literal}{$urls.base_url}{literal}products/montre-acier-et-cuir">Découvrir le produit<span aria-hidden="true">↗</span></a><a class="ref-link" href="{/literal}{$urls.base_url}{literal}collections/all">Voir la collection</a></div>
    </div>
    <figure class="ref-hero__media"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-en-situation-1-kj0a7v.jpg" alt="Montre acier et cuir" class="ref-image" width="1600" height="1600" loading="eager" decoding="async" fetchpriority="high"><figcaption>Acier et cuir véritable.</figcaption></figure>
  </div>
</section>

</div>
<div id="shopify-section-template--es__featured_collection_1" class="shopify-section es-section-wrapper" data-es-section="index:featured_collection_1" data-es-type="featured-collection"><section class="es-section es-fcoll color-scheme-1" style="--pt: 80px; --pb: 80px;">
  <div class="es-container"><header class="es-section-head es-section-head--split es-fcoll__head es-fcoll__head--few">
      <div><h2 class="es-heading es-h2" data-reveal="words">La collection</h2>
      </div>
      <a href="{/literal}{$urls.base_url}{literal}collections/selection-reference" class="es-link-arrow" data-reveal="up">Tout voir <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a>
    </header>
    <div class="es-product-grid es-fcoll__grid es-fcoll__grid--few es-fcoll__grid--one" style="--cols: 3; --n: 1;"><article class="es-card es-card--square" data-reveal="up">
  <a href="{/literal}{$urls.base_url}{literal}products/montre-acier-et-cuir" class="es-card__media" aria-label="Montre acier et cuir"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-galerie-packshot-ydmt8c.jpg?width=900" srcset="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-galerie-packshot-ydmt8c.jpg?width=360 360w, /assets/es-galerie-packshot-ydmt8c.jpg?width=540 540w, /assets/es-galerie-packshot-ydmt8c.jpg?width=720 720w, /assets/es-galerie-packshot-ydmt8c.jpg?width=900 900w" sizes="(min-width: 990px) 30vw, 50vw" alt="Montre acier et cuir" class="es-card__img" loading="lazy" decoding="async"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-galerie-lifestyle-kj0a-kj0a7v.jpg?width=900" sizes="(min-width: 990px) 30vw, 50vw" class="es-card__img es-card__img--hover" loading="lazy" decoding="async"></a>
  <div class="es-card__info">
    <h3 class="es-card__title"><a href="{/literal}{$urls.base_url}{literal}products/montre-acier-et-cuir">Montre acier et cuir</a></h3>
    <div class="es-price" data-price><span class="es-price__current">À partir de 129,00 €</span></div>

  </div>
</article>
</div>
  </div>
</section>





</div>
<div id="shopify-section-template--es__ref_editorial_1" class="shopify-section reference-section" data-es-section="index:ref_editorial_1" data-es-type="ref-editorial"><section class="ref-section ref-editorial ref-editorial--offset color-scheme-1" data-reference="editorial" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;">
  <div class="ref-shell ref-editorial__grid">
    <figure class="ref-editorial__media"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-hero-n8quha.jpg" alt="Montre acier et cuir" class="ref-image" width="1600" height="1600" loading="lazy" decoding="async"></figure>
    <div class="ref-editorial__copy"><h2 class="ref-heading">Le caractère est dans le détail.</h2><div class="ref-prose"><p>Le boîtier en acier poli encadre un cadran noir à trois compteurs argentés. Le bracelet en cuir brun surpiqué révèle une doublure bleue.</p></div></div>
  </div>
</section>

</div>
<div id="shopify-section-template--es__v2_benefits_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_benefits_1" data-es-type="v2-benefits"><section class="v2-benefits v2-benefits--images color-scheme-2" style="--pt: 96px; --pb: 96px; --cols: 3;">
  <div class="es-container"><header class="v2-head"><h2 class="v2-h2" data-reveal="up">La matière donne le ton.</h2></header><ul class="v2-benefits__list" role="list"><li class="v2-benefits__item" data-reveal="up" style="--i: 0" data-es-block="benefit_1"><div class="v2-benefits__media"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-detail-1-fkobnv.jpg" alt="L’éclat de l’acier" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><h3 class="v2-h3">L’éclat de l’acier</h3><div class="v2-rte">Un boîtier poli et une lunette graduée qui captent la lumière.</div></li><li class="v2-benefits__item" data-reveal="up" style="--i: 1" data-es-block="benefit_2"><div class="v2-benefits__media"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-scene-1-n8quha.jpg" alt="La présence du cuir" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><h3 class="v2-h3">La présence du cuir</h3><div class="v2-rte">Un bracelet brun surpiqué, avec une doublure de tissu bleu.</div></li><li class="v2-benefits__item" data-reveal="up" style="--i: 2" data-es-block="benefit_3"><div class="v2-benefits__media"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-packshot-ydmt8c.jpg" alt="Un contraste affirmé" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><h3 class="v2-h3">Un contraste affirmé</h3><div class="v2-rte">Un cadran noir ponctué de compteurs argentés.</div></li></ul>
  </div>
</section>


</div>
<div id="shopify-section-template--es__ref_editorial_2" class="shopify-section reference-section" data-es-section="index:ref_editorial_2" data-es-type="ref-editorial"><section class="ref-section ref-editorial ref-editorial--inset color-scheme-3" data-reference="editorial" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;">
  <div class="ref-shell ref-editorial__grid">
    <figure class="ref-editorial__media"><img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-detail-1-fkobnv.jpg" alt="Montre acier et cuir" class="ref-image" width="1600" height="1600" loading="lazy" decoding="async"></figure>
    <div class="ref-editorial__copy"><h2 class="ref-heading">Un objet, plusieurs regards.</h2><div class="ref-prose"><p>Une lumière sur le boîtier, une couture sur le cuir, une touche de bleu. Le caractère d’ARVEN se lit de près.</p></div></div>
  </div>
</section>

</div>
<div id="shopify-section-template--es__v2_specs_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_specs_1" data-es-type="v2-specs"><section class="v2-specs v2-specs--columns color-scheme-1" style="--pt: 104px; --pb: 104px;">
  <div class="es-container v2-specs__grid"><div>
      <header class="v2-head"><p class="v2-eyebrow" data-reveal="up">Fiche</p><h2 class="v2-h2" data-reveal="up">Caractéristiques</h2></header>
      <dl class="v2-specs__table"><div class="v2-specs__row" data-reveal="up" style="--i: 0" data-es-block="spec_4"><dt>Boîtier</dt><dd>Acier poli</dd></div><div class="v2-specs__row" data-reveal="up" style="--i: 1" data-es-block="spec_5"><dt>Bracelet</dt><dd>Cuir brun surpiqué</dd></div><div class="v2-specs__row" data-reveal="up" style="--i: 2" data-es-block="spec_6"><dt>Cadran</dt><dd>Noir, compteurs argentés</dd></div></dl></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__v2_media_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_media_1" data-es-type="v2-media"><section class="v2-media v2-media--rail color-scheme-2" style="--pt: 96px; --pb: 96px;">
  <div class="es-container">
    <header class="v2-head"><h2 class="v2-h2" data-reveal="up">L’objet en situation.</h2></header>
    <div class="v2-media__grid" tabindex="0" aria-label="L’objet en situation."><figure class="v2-media__tile" data-reveal="up" style="--i: 0" data-es-block="image_1">
          <img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-scene-1-n8quha.jpg" alt="Cuir et acier" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"><figcaption>Cuir et acier</figcaption></figure><figure class="v2-media__tile" data-reveal="up" style="--i: 1" data-es-block="image_2">
          <img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-detail-1-fkobnv.jpg" alt="Le cadran" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"><figcaption>Le cadran</figcaption></figure><figure class="v2-media__tile" data-reveal="up" style="--i: 2" data-es-block="image_3">
          <img src="{/literal}{$urls.base_url}{literal}themes/esarven/assets/es/es-packshot-ydmt8c.jpg" alt="La silhouette" class="v2-cover" width="1600" height="1600" loading="lazy" decoding="async"><figcaption>La silhouette</figcaption></figure></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__v2_faq_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_faq_1" data-es-type="v2-faq"><section class="v2-faq v2-faq--side color-scheme-1" style="--pt: 80px; --pb: 80px;">
  <div class="es-container v2-faq__grid">
    <header class="v2-head v2-faq__head"><h2 class="v2-h2" data-reveal="up">Les réponses, simplement.</h2></header>
    <div class="v2-faq__list"><details class="v2-faq__item" data-reveal="up" style="--i: 0" data-es-block="question_4">
          <summary><span>Quelles matières sont présentées ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Le boîtier est en acier poli et le bracelet en cuir brun surpiqué, doublé de tissu bleu.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 1" data-es-block="question_5">
          <summary><span>Le prix affiché permet-il de commander ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Le prix de 129 € est fictif et sert uniquement à tester le parcours. Aucun paiement ni achat réel n’est possible dans cette démonstration.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 2" data-es-block="question_6">
          <summary><span>Quelles informations restent à confirmer ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Les dimensions, le mouvement, l’étanchéité et les conditions de livraison doivent être renseignés par le marchand avant toute publication.</p></div>
        </details></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__v2_cta_1" class="shopify-section es-section-wrapper" data-es-section="index:v2_cta_1" data-es-type="v2-cta"><section class="v2-cta v2-cta--band color-scheme-3" style="--pt: 112px; --pb: 112px;">
  <div class="es-container">
    <div class="v2-cta__inner">
      <div class="v2-cta__copy"><h2 class="v2-h2 v2-cta__title" data-reveal="up">Prenez le temps de la découvrir.</h2><div class="v2-rte v2-lead-sm" data-reveal="up"><p>Retrouvez les photographies et les informations de la montre sur sa fiche.</p></div><div class="v2-actions" data-reveal="up"><a class="v2-btn v2-btn--primary" href="{/literal}{$urls.base_url}{literal}products/montre-acier-et-cuir">Découvrir la montre<span class="v2-btn__arrow" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></span></a><a class="v2-btn v2-btn--ghost" href="{/literal}{$urls.base_url}{literal}pages/notre-histoire">Notre histoire</a></div>
      </div></div>
  </div>
</section>


</div>{/literal}