{literal}<div id="shopify-section-template--es__reference_opening" class="shopify-section reference-section" data-es-section="page.seo-service-terrasse:reference_opening" data-es-type="ref-hero"><section class="ref-section ref-hero ref-hero--landscape color-scheme-1" data-reference="hero" data-ref-motion="reveal" style="--ref-pt: 32px; --ref-pb: 32px;" aria-labelledby="RefTitle-template--es__reference_opening">
  <div class="ref-shell ref-hero__grid">
    <div class="ref-hero__copy">
      <p class="ref-label">Racines &amp; Pierres</p>
      <h1 id="RefTitle-template--es__reference_opening" class="ref-hero__title">Terrasses et aménagements</h1>
      
      <div class="ref-actions"><a class="ref-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Parlons de votre projet<span aria-hidden="true">↗</span></a></div>
    </div>
    <figure class="ref-hero__media"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-prestation-sk5ku8-sk5ku8.jpg" alt="Terrasses et aménagements" class="ref-image" width="1600" height="1600" loading="eager" decoding="async" fetchpriority="high"></figure>
  </div>
</section>

</div>
<div id="shopify-section-template--es__seo_body" class="shopify-section es-section-wrapper" data-es-section="page.seo-service-terrasse:seo_body" data-es-type="rich-text"><section class="es-section es-ambient es-richtext es-richtext--plain color-scheme-1" style="--pt: 48px; --pb: 48px;">
  <div class="es-container es-richtext__inner es-richtext__inner--left"><div class="es-rte es-lead" data-reveal="up" data-es-block="body"><p>Bois, pierre sèche, jardinières et éclairage : composer des espaces où l’on aime s’installer, recevoir et circuler.</p>
<h2>Un projet qui part de vos usages.</h2>
<p>Nous commençons par préciser les envies, les usages et les contraintes du lieu. Le périmètre des travaux et les matériaux sont discutés avant l’établissement du devis.</p>
<h2>Ce que nous préparons ensemble.</h2>
<ul><li>Les espaces à aménager et leur utilisation.</li><li>Les matières et les plantations à envisager.</li><li>Le périmètre de la prestation et les informations nécessaires au devis.</li></ul>
<p>Entreprise fictive et illustration de démonstration. Aucun engagement commercial réel.</p></div></div>
</section>


</div>
<div id="shopify-section-template--es__reference_compare" class="shopify-section reference-section" data-es-section="page.seo-service-terrasse:reference_compare" data-es-type="ref-offers"><section class="ref-section ref-offers ref-offers--comparison color-scheme-2" data-reference="offers" data-ref-motion="none" style="--ref-pt: 64px; --ref-pb: 64px;">
  <div class="ref-shell">
    <div class="ref-section-head"><h2 class="ref-heading">Choisir la prestation adaptée</h2><div class="ref-prose"></div></div>
    
      <div class="ref-offers__list"><article class="ref-offer" data-es-block="service_0">
        
        <div class="ref-offer__copy"><h3>Création de jardin</h3><div class="ref-prose"><p>Dessiner les volumes, choisir les végétaux et organiser les cheminements. Un projet pensé pour votre terrain et votre façon de vivre dehors.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/texte-service-creation"><span class="visually-hidden">Création de jardin</span><span aria-hidden="true">↗</span></a>
      </article><article class="ref-offer" data-es-block="service_1">
        
        <div class="ref-offer__copy"><h3>Terrasses et aménagements</h3><div class="ref-prose"><p>Bois, pierre sèche, jardinières et éclairage : composer des espaces où l’on aime s’installer, recevoir et circuler.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/texte-service-terrasse"><span class="visually-hidden">Terrasses et aménagements</span><span aria-hidden="true">↗</span></a>
      </article><article class="ref-offer" data-es-block="service_2">
        
        <div class="ref-offer__copy"><h3>Entretien à l’année</h3><div class="ref-prose"><p>Taille, tonte, désherbage et suivi des plantations. Accompagner le jardin au fil des saisons, selon ses besoins.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/texte-service-entretien"><span class="visually-hidden">Entretien à l’année</span><span aria-hidden="true">↗</span></a>
      </article></div>
    
    <div class="ref-offers__action"></div>
  </div>
</section>

</div>
<div id="shopify-section-template--es__reference_practical" class="shopify-section reference-section" data-es-section="page.seo-service-terrasse:reference_practical" data-es-type="ref-notes"><section class="ref-section ref-notes ref-notes--columns color-scheme-1" data-reference="notes" data-ref-motion="reveal" style="--ref-pt: 64px; --ref-pb: 64px;"><div class="ref-shell"><h2 class="ref-heading" data-reveal="up">Préparer notre échange</h2><div class="ref-notes__grid"><article class="ref-note" data-es-block="fact_0"><h3>Zone d’intervention</h3><div class="ref-prose"><p>Aix-en-Provence et alentours</p></div></article><article class="ref-note" data-es-block="fact_1"><h3>Horaires</h3><div class="ref-prose"><p>Du lundi au vendredi, de 8 h à 18 h</p></div></article></div></div></section>

</div>
<div id="shopify-section-template--es__reference_contact" class="shopify-section reference-section" data-es-section="page.seo-service-terrasse:reference_contact" data-es-type="ref-editorial"><section class="ref-section ref-editorial ref-editorial--inset color-scheme-3 ref-editorial--text-only" data-reference="editorial" data-ref-motion="none" style="--ref-pt: 64px; --ref-pb: 64px;">
  <div class="ref-shell ref-editorial__grid">
    
    <div class="ref-editorial__copy"><h2 class="ref-heading">Parlons de votre projet</h2><a class="ref-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Demander un devis<span aria-hidden="true">↗</span></a></div>
  </div>
</section>

</div>{/literal}