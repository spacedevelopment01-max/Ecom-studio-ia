{literal}<div id="shopify-section-template--es__about_1" class="shopify-section es-section-wrapper" data-es-section="page.about:about_1" data-es-type="about"><section class="es-section es-about color-scheme-1" style="--pt: 120px; --pb: 104px;">
  <div class="es-container">
    <header class="es-about__head"><p class="es-eyebrow" data-reveal="up">À propos</p><h2 class="es-heading es-about__title" data-reveal="words">Le jardin commence par vous.</h2></header>

    <div class="es-about__intro">
      <figure class="es-about__media" data-reveal="curtain">
        <div class="es-about__img" data-parallax="0.06">
          <img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-1-ilyxw4.jpg" alt="Le jardin commence par vous." class="es-cover" width="1600" height="1600" loading="lazy" decoding="async">
        </div></figure>
      <div class="es-about__story"><div class="es-rte es-about__lead" data-reveal="up"><p>Un jardin se dessine à partir d’un lieu, d’usages et d’envies. Nous relions les matières et le végétal pour faire de l’extérieur un espace à vivre.</p></div><div class="es-about__pillars"><div class="es-about__pillar" data-reveal="up" style="--d: 1">
              <p class="es-about__kicker"><span>01</span>Habiter aussi l’extérieur.</p>
              <div class="es-rte"><p>Prendre le temps de comprendre un lieu, puis relier les gestes du quotidien aux aménagements du jardin.</p></div>
            </div><div class="es-about__pillar" data-reveal="up" style="--d: 2">
              <p class="es-about__kicker"><span>02</span>Notre engagement</p>
              <div class="es-rte"><p>[À compléter : un engagement réel et vérifiable.]</p></div>
            </div></div></div>
    </div><div class="es-about__values"><h3 class="es-heading es-h3 es-about__values-title" data-reveal="up">Ce qui nous guide</h3><ul class="es-about__cards" role="list" style="--count: 3;"><li class="es-about__card" data-reveal="up" style="--i: 0" data-es-block="value_1">
              <span class="es-about__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></svg></span>
              <h4 class="es-about__card-title">Partir de vos usages</h4><div class="es-rte es-about__card-text"><p>Circuler, s’asseoir, recevoir : le projet commence par votre façon d’habiter le jardin.</p></div></li><li class="es-about__card" data-reveal="up" style="--i: 1" data-es-block="value_2">
              <span class="es-about__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20s-7-4.4-9.2-9A4.8 4.8 0 0 1 12 6a4.8 4.8 0 0 1 9.2 5c-2.2 4.6-9.2 9-9.2 9Z"/></svg></span>
              <h4 class="es-about__card-title">Faire dialoguer les matières</h4><div class="es-rte es-about__card-text"><p>Bois, pierre et végétaux composent les volumes du projet.</p></div></li><li class="es-about__card" data-reveal="up" style="--i: 2" data-es-block="value_3">
              <span class="es-about__icon"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6l-7-3Z"/></svg></span>
              <h4 class="es-about__card-title">Accompagner les saisons</h4><div class="es-rte es-about__card-text"><p>L’entretien prolonge le travail de conception et de plantation.</p></div></li></ul>
      </div><div class="es-actions es-actions--center es-about__cta" data-reveal="up"><a href="{/literal}{$urls.base_url}{literal}pages/prestations" class="es-button">Découvrir nos prestations <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div></div>
</section>




</div>
<div id="shopify-section-template--es__team_1" class="shopify-section es-section-wrapper" data-es-section="page.about:team_1" data-es-type="team"><section class="es-section es-team es-team--cards color-scheme-2" style="--pt: 104px; --pb: 104px; --cols: 3;">
  <div class="es-container">
    <header class="es-team__head"><p class="es-eyebrow" data-reveal="up">L'équipe</p><h2 class="es-heading es-h2" data-reveal="words">Les personnes qui vous accueillent</h2></header>
    <ul class="es-team__grid" role="list"><li class="es-team__member" data-reveal="up" style="--i: 0" data-es-block="member_1">
          <div class="es-team__photo"><span class="es-team__monogram" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg></span></div>
          <div class="es-team__body">
            <h3 class="es-heading es-h4 es-team__name">[À compléter : prénom et nom]</h3><p class="es-team__role">[À compléter : rôle]</p><div class="es-rte es-team__bio"><p>[À compléter : parcours et spécialités réels]</p></div></div>
        </li><li class="es-team__member" data-reveal="up" style="--i: 1" data-es-block="member_2">
          <div class="es-team__photo"><span class="es-team__monogram" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg></span></div>
          <div class="es-team__body">
            <h3 class="es-heading es-h4 es-team__name">[À compléter : prénom et nom]</h3><p class="es-team__role">[À compléter : rôle]</p><div class="es-rte es-team__bio"><p>[À compléter : parcours et spécialités réels]</p></div></div>
        </li><li class="es-team__member" data-reveal="up" style="--i: 2" data-es-block="member_3">
          <div class="es-team__photo"><span class="es-team__monogram" aria-hidden="true"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg></span></div>
          <div class="es-team__body">
            <h3 class="es-heading es-h4 es-team__name">[À compléter : prénom et nom]</h3><p class="es-team__role">[À compléter : rôle]</p><div class="es-rte es-team__bio"><p>[À compléter : parcours et spécialités réels]</p></div></div>
        </li></ul>
  </div>
</section>




</div>
<div id="shopify-section-template--es__timeline_1" class="shopify-section es-section-wrapper" data-es-section="page.about:timeline_1" data-es-type="timeline"><section class="es-section es-timeline color-scheme-1" style="--pt: 104px; --pb: 104px;">
  <div class="es-container es-timeline__inner"><p class="es-eyebrow es-timeline__eyebrow" data-reveal="up">Notre méthode</p><h2 class="es-heading es-h2 es-timeline__heading" data-reveal="words">Comment ça se passe</h2><div class="es-timeline__media es-media-frame" data-scroll-zoom data-reveal="zoom"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-3-60zqyz.jpg" alt="Comment ça se passe" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><ol class="es-timeline__list" data-timeline>
      <span class="es-timeline__line" aria-hidden="true"><span class="es-timeline__fill"></span></span><li class="es-timeline__step" data-timeline-step data-es-block="step_7">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">01</span>
          <h3 class="es-heading es-h3">Décrivez votre projet</h3>
          <div class="es-rte"><p>Quelques lignes suffisent : le besoin, le lieu, vos contraintes.</p></div>
        </li><li class="es-timeline__step" data-timeline-step data-es-block="step_8">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">02</span>
          <h3 class="es-heading es-h3">Recevez votre devis</h3>
          <div class="es-rte"><p>Une proposition détaillée, établie d'après votre demande.</p></div>
        </li><li class="es-timeline__step" data-timeline-step data-es-block="step_9">
          <span class="es-timeline__dot" aria-hidden="true"></span>
          <span class="es-timeline__num" aria-hidden="true">03</span>
          <h3 class="es-heading es-h3">Nous réalisons</h3>
          <div class="es-rte"><p>Le travail est réalisé selon ce qui a été convenu ensemble.</p></div>
        </li></ol>
  </div>
</section>




</div>
<div id="shopify-section-template--es__cta_banner_3" class="shopify-section es-section-wrapper" data-es-section="page.about:cta_banner_3" data-es-type="cta-banner"><section class="es-section es-cta color-scheme-3 es-cta--center" style="--pt: 152px; --pb: 152px; --overlay: 0.45;"><div class="es-cta__media" data-parallax="0.2"><img src="{/literal}{$urls.base_url}{literal}themes/esracinespierres/assets/es/es-photo-4-wshpso.jpg" alt="" class="es-cover" width="1600" height="1600" loading="lazy" decoding="async"></div><div class="es-container es-cta__inner">
    <h2 class="es-heading es-h1" data-reveal="words">Et si l’on parlait de votre jardin ?</h2><div class="es-rte es-lead" data-reveal="up"><p>Un lieu, quelques envies, un premier échange pour préciser votre projet.</p></div><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button" data-reveal="up" style="--d: 1">Demander un devis <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 12h16M14 6l6 6-6 6"/></svg></a></div>
</section>





</div>{/literal}