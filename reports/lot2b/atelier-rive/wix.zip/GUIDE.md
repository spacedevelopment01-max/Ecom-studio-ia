# Kit de création Wix — Atelier Rive

Wix n'accepte pas l'import d'un thème externe : ce kit n'est pas un thème installable.
Il rassemble tout ce qu'il faut pour reproduire fidèlement le site conçu dans le studio, dans l'éditeur de la plateforme.

## Étapes
1. Dans l'éditeur Wix, créez un site vierge (pas de modèle Wix Stores : aucune boutique n'est nécessaire).
2. Thème du site › Couleurs : reportez la palette ci-dessous ; Thème du site › Texte : importez les polices du dossier « polices ».
3. Médias : importez le dossier « medias » dans le gestionnaire de médias.
4. Rendez-vous : ajoutez Wix Bookings, ou un bouton vers votre lien de réservation (Calendly, Planity, Doctolib…).
5. Reconstituez les pages avec « textes-des-pages.md » (accueil, prestations, à propos, contact / rendez-vous, FAQ, mentions légales).
6. Infos pratiques : ajoutez l'élément Google Maps avec votre adresse et un bouton « Appeler » (lien téléphone).

## Palette
- scheme-1 : fond #EEEAE2 · texte #243B32 · accent #243B32 · texte sur accent #EEEAE2
- scheme-2 : fond #243B32 · texte #EEEAE2 · accent #EEEAE2 · texte sur accent #243B32
- scheme-3 : fond #FFFFFF · texte #243B32 · accent #243B32 · texte sur accent #FFFFFF

## Typographies
- Titres : Archivo
- Texte : Work Sans
