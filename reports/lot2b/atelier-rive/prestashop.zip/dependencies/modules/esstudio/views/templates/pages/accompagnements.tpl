{literal}<div id="shopify-section-template--es__opening" class="shopify-section " data-es-section="page.accompagnements:opening" data-es-type="ed-opening">
<section class="ed-section ed-opening ed-opening--journal color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell">
 <header class="ed-opening__copy"><p class="ed-kicker">LES ACCOMPAGNEMENTS</p>
 <h1 class="ed-title ed-opening__title" data-ed-title>Une direction, à la bonne échelle.</h1>
 <div class="ed-prose"><p>Conseil, une pièce ou plusieurs espaces : choisissons le périmètre qui répond à votre besoin.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Parlons de votre intérieur<span aria-hidden="true">↗</span></a></header>
 <div class="ed-opening__media">
</div>
 
</div></section>

</div>
<div id="shopify-section-template--es__offers" class="shopify-section reference-section" data-es-section="page.accompagnements:offers" data-es-type="ref-narrative"><section class="ref-section ref-narrative color-scheme-1" style="--ref-pt:80px;--ref-pb:80px" data-narrative data-motion="reveal">
 <div class="ref-shell"><div class="ref-section-head"><h2 class="ref-heading">Trois façons d&#39;avancer.</h2></div>
  <div class="ref-narrative__grid">
   <div class="ref-narrative__chapters">
    <details class="ref-narrative__chapter" open data-es-block="b0" data-narrative-chapter="0">
     <summary><span>Conseil &amp; direction</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Préciser l'ambiance et les choix qui donneront une direction à votre intérieur.</p></div><a class="ed-text-link" href="{/literal}{$urls.base_url}{literal}pages/conseil">Découvrir l&#39;accompagnement ↗</a>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="b1" data-narrative-chapter="1">
     <summary><span>Aménagement d&#39;une pièce</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Organiser les usages, la circulation et les matières à l'échelle d'une pièce.</p></div><a class="ed-text-link" href="{/literal}{$urls.base_url}{literal}pages/amenagement-une-piece">Découvrir l&#39;accompagnement ↗</a>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="b2" data-narrative-chapter="2">
     <summary><span>Projet d&#39;ensemble</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Relier plusieurs espaces autour d'une intention commune, avec un périmètre à définir ensemble.</p></div><a class="ed-text-link" href="{/literal}{$urls.base_url}{literal}pages/ensemble">Découvrir l&#39;accompagnement ↗</a>
    </details>
   </div>
   <div class="ref-narrative__visuals">
    <figure data-narrative-image="0">
     <div class="ed-media ed-media--pending" role="img" aria-label="rive-08-plans"><p>Visuel à importer<span>rive-08-plans</span></p></div>

     <figcaption>Projet d&#39;intention — image de démonstration</figcaption>
    </figure>
    <figure data-narrative-image="1" hidden>
     <div class="ed-media ed-media--pending" role="img" aria-label="rive-06-bibliotheque"><p>Visuel à importer<span>rive-06-bibliotheque</span></p></div>

     <figcaption>Projet d&#39;intention — image de démonstration</figcaption>
    </figure>
    <figure data-narrative-image="2" hidden>
     <div class="ed-media ed-media--pending" role="img" aria-label="rive-11-repas"><p>Visuel à importer<span>rive-11-repas</span></p></div>

     <figcaption>Projet d&#39;intention — image de démonstration</figcaption>
    </figure></div>
  </div>
 </div>
</section>

</div>
<div id="shopify-section-template--es__method" class="shopify-section reference-section" data-es-section="page.accompagnements:method" data-es-type="ref-narrative"><section class="ref-section ref-narrative color-scheme-1" style="--ref-pt:80px;--ref-pb:80px" data-narrative data-motion="reveal">
 <div class="ref-shell"><div class="ref-section-head"><h2 class="ref-heading">Échanger. Clarifier. Concevoir. Vous accompagner.</h2></div>
  <div class="ref-narrative__grid">
   <div class="ref-narrative__chapters">
    <details class="ref-narrative__chapter" open data-es-block="b0" data-narrative-chapter="0">
     <summary><span>01 — Échanger</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Nous partons de votre quotidien : les gestes, les circulations et ce qui manque à la pièce. Vos priorités et les contraintes du lieu servent de point de départ, sans présumer du périmètre final.</p></div>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="b1" data-narrative-chapter="1">
     <summary><span>02 — Clarifier</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Nous mettons en relation les volumes, la lumière et les matières. Des pistes d'ambiance permettent de discuter de vos préférences avant de retenir une direction.</p></div>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="b2" data-narrative-chapter="2">
     <summary><span>03 — Concevoir</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>L'implantation donne une place à chaque usage. Le choix des matières et du mobilier s'organise autour de cette proposition, avec les éléments à conserver et ceux à faire évoluer.</p></div>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="b3" data-narrative-chapter="3">
     <summary><span>04 — Vous accompagner</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Nous reprenons ensemble les choix retenus et les points à approfondir. Le périmètre, le budget et le calendrier sont définis lors des échanges, sans engagement inventé dans cette démonstration.</p></div>
    </details>
   </div>
   <div class="ref-narrative__visuals"></div>
  </div>
 </div>
</section>

</div>
<div id="shopify-section-template--es__contact" class="shopify-section " data-es-section="page.accompagnements:contact" data-es-type="ed-contact">
<section class="ed-section ed-contact color-scheme-1" id="contact" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell ed-contact__grid"><header><p class="ed-kicker">PREMIER ÉCHANGE</p><h2 class="ed-title">Et si l&#39;on commençait par votre pièce ?</h2><div class="ed-prose"><p>Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.</p></div></header><div data-error-message="Vérifiez votre demande avant de réessayer." data-ed-contact data-preview-test="true">
 <form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" class="ed-form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓">
 
 <label>Nom<input name="contact[name]" autocomplete="name" value="" maxlength="160" required></label>
 <label>E-mail<input type="email" name="contact[email]" autocomplete="email" value="" maxlength="254" required></label>
 <label>Type de pièce<select name="contact[room]" required><option value="">Choisir une pièce</option><option value="Salon">Salon</option><option value="Cuisine">Cuisine</option><option value="Chambre">Chambre</option><option value="Entrée">Entrée</option><option value="Salle d&#39;eau">Salle d&#39;eau</option><option value="Autre">Autre</option></select></label>
 <label>Message<textarea name="contact[body]" rows="5" maxlength="4000" required></textarea></label>
 <button type="submit" class="ed-button">Demander un premier échange</button><p role="status" aria-live="polite" data-contact-status></p>
 </form>
 </div></div></section>

</div>{/literal}