{literal}<div id="shopify-section-template--es__opening" class="shopify-section " data-es-section="page.piece:opening" data-es-type="ed-opening">
<section class="ed-section ed-opening ed-opening--journal color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell">
 <header class="ed-opening__copy"><p class="ed-kicker">AMÉNAGEMENT D&#39;UNE PIÈCE</p>
 <h1 class="ed-title ed-opening__title" data-ed-title>Repensons la pièce que vous vivez le plus.</h1>
 <div class="ed-prose"><p>Une proposition d'aménagement pour faire dialoguer vos usages, la lumière et les matières.</p></div><a class="ed-button" href="#contact">Parler de ma pièce<span aria-hidden="true">↗</span></a></header>
 <div class="ed-opening__media"><div class="ed-media ed-media--pending" role="img" aria-label="rive-06-bibliotheque"><p>Visuel à importer<span>rive-06-bibliotheque</span></p></div>
</div>
 
</div></section>

</div>
<div id="shopify-section-template--es__for" class="shopify-section " data-es-section="page.piece:for" data-es-type="ed-statement">
<section class="ed-section ed-statement color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell ed-statement__grid"><header><h2 class="ed-title">Pour quel projet ?</h2><div class="ed-prose"><p>Un salon, une pièce de repas ou une entrée : l'échelle d'une pièce permet de travailler les relations entre usages et volumes.</p></div></header><div class="ed-statement__aside"><ul class="ed-points" role="list"><li data-es-block="b0"><h3>Salon — se retrouver, lire, recevoir</h3><div class="ed-prose"></div></li><li data-es-block="b1"><h3>Pièce de repas — partager et circuler</h3><div class="ed-prose"></div></li><li data-es-block="b2"><h3>Entrée — accueillir et organiser</h3><div class="ed-prose"></div></li></ul></div></div></section>

</div>
<div id="shopify-section-template--es__prepare" class="shopify-section " data-es-section="page.piece:prepare" data-es-type="ed-statement">
<section class="ed-section ed-statement color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell ed-statement__grid"><header><h2 class="ed-title">Ce que nous préparons ensemble.</h2><div class="ed-prose"><p>La proposition s'appuie sur les informations que vous partagez et sur le périmètre convenu. Les livrables ci-dessous constituent une intention de démonstration, à adapter au projet.</p></div></header><div class="ed-statement__aside"><ul class="ed-points" role="list"><li data-es-block="b0"><h3>Les besoins et les éléments à conserver</h3><div class="ed-prose"></div></li><li data-es-block="b1"><h3>Une direction d&#39;ambiance</h3><div class="ed-prose"></div></li><li data-es-block="b2"><h3>Une proposition d&#39;implantation</h3><div class="ed-prose"></div></li><li data-es-block="b3"><h3>Des pistes de matières et de mobilier</h3><div class="ed-prose"></div></li></ul></div></div></section>

</div>
<div id="shopify-section-template--es__method" class="shopify-section reference-section" data-es-section="page.piece:method" data-es-type="ref-narrative"><section class="ref-section ref-narrative color-scheme-1" style="--ref-pt:80px;--ref-pb:80px" data-narrative data-motion="reveal">
 <div class="ref-shell"><div class="ref-section-head"><h2 class="ref-heading">Échanger. Clarifier. Concevoir. Vous accompagner.</h2></div>
  <div class="ref-narrative__grid">
   <div class="ref-narrative__chapters">
    <details class="ref-narrative__chapter" open data-es-block="b0" data-narrative-chapter="0">
     <summary><span>01 — Échanger</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Nous partons de votre quotidien : les gestes, les circulations et ce qui manque à la pièce. Vos priorités et les contraintes du lieu servent de point de départ, sans présumer du périmètre final.</p></div>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="b1" data-narrative-chapter="1">
     <summary><span>02 — Clarifier</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Nous mettons en relation les volumes, la lumière et les matières. Des pistes d'ambiance permettent de discuter de vos préférences avant de retenir une direction.</p></div>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="b2" data-narrative-chapter="2">
     <summary><span>03 — Concevoir</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>L'implantation donne une place à chaque usage. Le choix des matières et du mobilier s'organise autour de cette proposition, avec les éléments à conserver et ceux à faire évoluer.</p></div>
    </details>
   
    <details class="ref-narrative__chapter" data-es-block="b3" data-narrative-chapter="3">
     <summary><span>04 — Vous accompagner</span><span aria-hidden="true">+</span></summary><div class="ref-prose"><p>Nous reprenons ensemble les choix retenus et les points à approfondir. Le périmètre, le budget et le calendrier sont définis lors des échanges, sans engagement inventé dans cette démonstration.</p></div>
    </details>
   </div>
   <div class="ref-narrative__visuals"></div>
  </div>
 </div>
</section>

</div>
<div id="shopify-section-template--es__plans" class="shopify-section " data-es-section="page.piece:plans" data-es-type="ed-diptych">
<section class="ed-section ed-diptych ed-diptych--pair color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker">ÉLÉMENTS D&#39;INTENTION — DÉMONSTRATION</p><h2 class="ed-title">Du plan aux matières.</h2><div class="ed-prose"></div></header><div class="ed-diptych__grid"><figure class="ed-diptych__frame ed-ratio--landscape" data-es-block="b0"><div class="ed-media ed-media--pending" role="img" aria-label="rive-08-plans"><p>Visuel à importer<span>rive-08-plans</span></p></div>
<figcaption><h3>L&#39;implantation</h3><div class="ed-prose"><p>Lire les passages, les proportions et les relations entre les usages.</p></div></figcaption></figure><figure class="ed-diptych__frame ed-ratio--portrait" data-es-block="b1"><div class="ed-media ed-media--pending" role="img" aria-label="rive-07-matieres"><p>Visuel à importer<span>rive-07-matieres</span></p></div>
<figcaption><h3>Les accords de matières</h3><div class="ed-prose"><p>Faire dialoguer la lumière, les textures et les teintes.</p></div></figcaption></figure></div></div></section>

</div>
<div id="shopify-section-template--es__compare" class="shopify-section reference-section" data-es-section="page.piece:compare" data-es-type="ref-offers"><section class="ref-section ref-offers ref-offers--comparison color-scheme-1" data-reference="offers" data-ref-motion="reveal" style="--ref-pt: 80px; --ref-pb: 80px;">
  <div class="ref-shell">
    <div class="ref-section-head"><h2 class="ref-heading" data-reveal="up">Choisir le bon périmètre.</h2><div class="ref-prose"><p>Trois échelles de travail. Le contenu, le budget et le calendrier sont définis lors du premier échange ; aucun tarif n'est validé ici.</p></div></div>
    
      <div class="ref-offers__list"><article class="ref-offer" data-es-block="b0">
        
        <div class="ref-offer__copy"><h3>Conseil &amp; direction</h3><div class="ref-prose"><p>Préciser l'ambiance et les choix qui donneront une direction à votre intérieur.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/conseil"><span class="visually-hidden">Conseil &amp; direction</span><span aria-hidden="true">↗</span></a>
      </article><article class="ref-offer" data-es-block="b1">
        
        <div class="ref-offer__copy"><h3>Aménagement d&#39;une pièce</h3><div class="ref-prose"><p>Organiser les usages, la circulation et les matières à l'échelle d'une pièce.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/amenagement-une-piece"><span class="visually-hidden">Aménagement d&#39;une pièce</span><span aria-hidden="true">↗</span></a>
      </article><article class="ref-offer" data-es-block="b2">
        
        <div class="ref-offer__copy"><h3>Projet d&#39;ensemble</h3><div class="ref-prose"><p>Relier plusieurs espaces autour d'une intention commune, avec un périmètre à définir ensemble.</p></div></div>
        <a class="ref-offer__link" href="{/literal}{$urls.base_url}{literal}pages/ensemble"><span class="visually-hidden">Projet d&#39;ensemble</span><span aria-hidden="true">↗</span></a>
      </article></div>
    
    <div class="ref-offers__action"></div>
  </div>
</section>

</div>
<div id="shopify-section-template--es__study" class="shopify-section " data-es-section="page.piece:study" data-es-type="ed-study">
<section class="ed-section ed-study color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker">ÉTUDE FICTIVE</p><h2 class="ed-title">D&#39;un volume à une intention.</h2><div class="ed-prose"><p>Deux vues d'intention pour discuter des usages et de la place du mobilier. Simulation de démonstration : ces images ne prouvent pas une réalisation client ni un avant/après parfaitement aligné.</p></div></header><div class="ed-study__views">
 <figure><div class="ed-media ed-media--pending" role="img" aria-label="rive-09-volume"><p>Visuel à importer<span>rive-09-volume</span></p></div>
<figcaption>Volume de départ — simulation</figcaption></figure>
 <figure><div class="ed-media ed-media--pending" role="img" aria-label="rive-01-salon"><p>Visuel à importer<span>rive-01-salon</span></p></div>
<figcaption>Proposition d&#39;aménagement — simulation</figcaption></figure>
 
</div></div></section>

</div>
<div id="shopify-section-template--es__faq" class="shopify-section es-section-wrapper" data-es-section="page.piece:faq" data-es-type="v2-faq"><section class="v2-faq v2-faq--side color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container v2-faq__grid">
    <header class="v2-head v2-faq__head"><h2 class="v2-h2" data-reveal="up">Préciser votre projet.</h2></header>
    <div class="v2-faq__list"><details class="v2-faq__item" data-reveal="up" style="--i: 0" data-es-block="b0">
          <summary><span>Puis-je commencer avec une seule pièce ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Oui. La page Aménagement d'une pièce présente cette approche ; le périmètre se précise au premier échange.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 1" data-es-block="b1">
          <summary><span>Faut-il déjà avoir un budget défini ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Une enveloppe ou des priorités permettent d'orienter la discussion. Aucun tarif ni budget de réalisation n'est validé dans cette démonstration.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 2" data-es-block="b2">
          <summary><span>Peut-on conserver du mobilier existant ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Les éléments à garder font partie des premières informations à partager pour organiser la proposition.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 3" data-es-block="b3">
          <summary><span>Les photographies présentent-elles des réalisations clients ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Non. Il s'agit de projets d'intention et d'images de démonstration, sans avis ni résultats clients revendiqués.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 4" data-es-block="b4">
          <summary><span>Quel est le délai pour mon projet ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Le calendrier dépend du périmètre défini ensemble. Aucun délai d'intervention ni disponibilité n'est promis ici.</p></div>
        </details></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__contact" class="shopify-section " data-es-section="page.piece:contact" data-es-type="ed-contact">
<section class="ed-section ed-contact color-scheme-1" id="contact" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell ed-contact__grid"><header><p class="ed-kicker">PREMIER ÉCHANGE</p><h2 class="ed-title">Et si l&#39;on commençait par votre pièce ?</h2><div class="ed-prose"><p>Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.</p></div></header><div data-error-message="Vérifiez votre demande avant de réessayer." data-ed-contact data-preview-test="true">
 <form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" class="ed-form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓">
 
 <label>Nom<input name="contact[name]" autocomplete="name" value="" maxlength="160" required></label>
 <label>E-mail<input type="email" name="contact[email]" autocomplete="email" value="" maxlength="254" required></label>
 <label>Type de pièce<select name="contact[room]" required><option value="">Choisir une pièce</option><option value="Salon">Salon</option><option value="Cuisine">Cuisine</option><option value="Chambre">Chambre</option><option value="Entrée">Entrée</option><option value="Salle d&#39;eau">Salle d&#39;eau</option><option value="Autre">Autre</option></select></label>
 <label>Message<textarea name="contact[body]" rows="5" maxlength="4000" required></textarea></label>
 <button type="submit" class="ed-button">Demander un premier échange</button><p role="status" aria-live="polite" data-contact-status></p>
 </form>
 </div></div></section>

</div>{/literal}