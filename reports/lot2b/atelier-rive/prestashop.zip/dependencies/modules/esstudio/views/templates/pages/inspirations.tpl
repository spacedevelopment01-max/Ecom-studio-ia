{literal}<div id="shopify-section-template--es__opening" class="shopify-section " data-es-section="page.inspirations:opening" data-es-type="ed-opening">
<section class="ed-section ed-opening ed-opening--journal color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell">
 <header class="ed-opening__copy"><p class="ed-kicker">INSPIRATIONS</p>
 <h1 class="ed-title ed-opening__title" data-ed-title>Des pistes pour habiter autrement.</h1>
 <div class="ed-prose"><p>Projets d'intention — images de démonstration.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}pages/contact">Parlons de votre intérieur<span aria-hidden="true">↗</span></a></header>
 <div class="ed-opening__media">
</div>
 
</div></section>

</div>
<div id="shopify-section-template--es__inspirations" class="shopify-section " data-es-section="page.inspirations:inspirations" data-es-type="ed-diptych">
<section class="ed-section ed-diptych ed-diptych--index color-scheme-1" id="inspirations" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker">PROJETS D&#39;INTENTION — IMAGES DE DÉMONSTRATION</p><h2 class="ed-title">Des volumes, des usages, des intentions.</h2><div class="ed-prose"></div></header><div class="ed-diptych__grid"><figure class="ed-diptych__frame ed-ratio--landscape" data-es-block="b0"><div class="ed-media ed-media--pending" role="img" aria-label="rive-02-cuisine"><p>Visuel à importer<span>rive-02-cuisine</span></p></div>
<figcaption><h3>Une cuisine qui ouvre la pièce.</h3><div class="ed-prose"><p>Des circulations lisibles et une place pour préparer, échanger, se retrouver.</p></div></figcaption></figure><figure class="ed-diptych__frame ed-ratio--portrait" data-es-block="b1"><div class="ed-media ed-media--pending" role="img" aria-label="rive-03-chambre"><p>Visuel à importer<span>rive-03-chambre</span></p></div>
<figcaption><h3>Une chambre pour ralentir.</h3><div class="ed-prose"><p>Une palette apaisée et des volumes qui laissent respirer les usages.</p></div></figcaption></figure><figure class="ed-diptych__frame ed-ratio--landscape" data-es-block="b2"><div class="ed-media ed-media--pending" role="img" aria-label="rive-04-entree"><p>Visuel à importer<span>rive-04-entree</span></p></div>
<figcaption><h3>Une entrée qui trouve sa place.</h3><div class="ed-prose"><p>Accueillir, déposer, circuler : organiser le seuil de la maison.</p></div></figcaption></figure></div></div></section>

</div>
<div id="shopify-section-template--es__study" class="shopify-section " data-es-section="page.inspirations:study" data-es-type="ed-study">
<section class="ed-section ed-study color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker">ÉTUDE FICTIVE</p><h2 class="ed-title">D&#39;un volume à une intention.</h2><div class="ed-prose"><p>Deux vues d'intention pour discuter des usages et de la place du mobilier. Simulation de démonstration : ces images ne prouvent pas une réalisation client ni un avant/après parfaitement aligné.</p></div></header><div class="ed-study__views">
 <figure><div class="ed-media ed-media--pending" role="img" aria-label="rive-09-volume"><p>Visuel à importer<span>rive-09-volume</span></p></div>
<figcaption>Volume de départ — simulation</figcaption></figure>
 <figure><div class="ed-media ed-media--pending" role="img" aria-label="rive-01-salon"><p>Visuel à importer<span>rive-01-salon</span></p></div>
<figcaption>Proposition d&#39;aménagement — simulation</figcaption></figure>
 
</div></div></section>

</div>{/literal}