{literal}<div id="shopify-section-template--es__opening" class="shopify-section " data-es-section="page.contact-test:opening" data-es-type="ed-opening">
<section class="ed-section ed-opening ed-opening--journal color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell">
 <header class="ed-opening__copy"><p class="ed-kicker">ATELIER RIVE</p>
 <h1 class="ed-title ed-opening__title" data-ed-title>Parlons de votre intérieur.</h1>
 <div class="ed-prose"><p>Un premier échange pour préciser ce que vous souhaitez faire évoluer.</p></div><a class="ed-button" href="#contact">Décrire ma pièce<span aria-hidden="true">↗</span></a></header>
 <div class="ed-opening__media">
</div>
 
</div></section>

</div>
<div id="shopify-section-template--es__contact" class="shopify-section " data-es-section="page.contact-test:contact" data-es-type="ed-contact">
<section class="ed-section ed-contact color-scheme-1" id="contact" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell ed-contact__grid"><header><p class="ed-kicker">PREMIER ÉCHANGE</p><h2 class="ed-title">Et si l&#39;on commençait par votre pièce ?</h2><div class="ed-prose"><p>Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.</p></div></header><div data-error-message="Vérifiez votre demande avant de réessayer." data-ed-contact data-preview-test="true">
 <form method="post" action="{/literal}{$link->getModuleLink('esstudio','form')}{literal}" accept-charset="UTF-8" class="ed-form"><input type="hidden" name="form_type" value="contact"><input type="hidden" name="token" value="{/literal}{$static_token}{literal}"><input type="hidden" name="back" value="{/literal}{$urls.current_url|escape:'html':'UTF-8'}{literal}"><input type="hidden" name="utf8" value="✓">
 
 <label>Nom<input name="contact[name]" autocomplete="name" value="" maxlength="160" required></label>
 <label>E-mail<input type="email" name="contact[email]" autocomplete="email" value="" maxlength="254" required></label>
 <label>Type de pièce<select name="contact[room]" required><option value="">Choisir une pièce</option><option value="Salon">Salon</option><option value="Cuisine">Cuisine</option><option value="Chambre">Chambre</option><option value="Entrée">Entrée</option><option value="Salle d&#39;eau">Salle d&#39;eau</option><option value="Autre">Autre</option></select></label>
 <label>Message<textarea name="contact[body]" rows="5" maxlength="4000" required></textarea></label>
 <button type="submit" class="ed-button">Demander un premier échange</button><p role="status" aria-live="polite" data-contact-status></p>
 </form>
 </div></div></section>

</div>
<div id="shopify-section-template--es__small" class="shopify-section " data-es-section="page.contact-test:small" data-es-type="ed-scene">
<section class="ed-section ed-scene ed-scene--closing color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><div class="ed-scene__media"><div class="ed-media ed-media--pending" role="img" aria-label="rive-05-salle-eau"><p>Visuel à importer<span>rive-05-salle-eau</span></p></div>
</div><div class="ed-scene__copy"><p class="ed-kicker"></p><h2 class="ed-title">Une place pour chaque usage.</h2><div class="ed-prose"><p>Projet d'intention — image de démonstration.</p></div></div></div></section>

</div>{/literal}