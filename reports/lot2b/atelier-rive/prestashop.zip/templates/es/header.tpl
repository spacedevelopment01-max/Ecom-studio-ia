{literal}<div id="shopify-section-template--es__header_1" class="shopify-section es-header-section" data-es-section="group:header:header_1" data-es-type="header"><header class="es-header es-header--logo-left es-header--shape-bar es-header--icons-plain es-header--sticky color-scheme-1" data-header>
  <div class="es-header__inner es-container">
    <button class="es-header__burger es-icon-button" type="button" aria-controls="MobileMenu" aria-expanded="false" data-menu-open>
      <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7h18M3 12h18M3 17h18"/></svg><span class="visually-hidden">Menu</span>
    </button>

    <a href="{/literal}{$urls.base_url}{literal}" class="es-header__logo" aria-label="Atelier Rive"><span class="es-header__wordmark">Atelier Rive</span></a>

    <nav class="es-header__nav" aria-label="Navigation principale">
      <ul role="list"><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}#approche" class="es-nav__link"><span>Notre approche</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/inspirations" class="es-nav__link"><span>Inspirations</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/accompagnements" class="es-nav__link"><span>Accompagnements</span></a></li></ul>
    </nav>

    <div class="es-header__icons"><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button es-button--small es-header__cta"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg><span>Parlons de votre intérieur</span></a></div>
  </div>

  <div class="es-mobile-menu es-mobile-menu--sheet es-mobile-menu--sub-accordion color-scheme-1" id="MobileMenu" hidden data-mobile-menu>
    <div class="es-mobile-menu__head">
      <span class="es-header__wordmark">Atelier Rive</span>
      <button type="button" class="es-icon-button" data-menu-close aria-label="Fermer"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 5 14 14M19 5 5 19"/></svg></button>
    </div><ul role="list" class="es-mobile-menu__list"><li style="--i: 1"><a href="{/literal}{$urls.base_url}{literal}#approche" class="es-mm__link"><span>Notre approche</span></a></li><li style="--i: 2"><a href="{/literal}{$urls.base_url}{literal}pages/inspirations" class="es-mm__link"><span>Inspirations</span></a></li><li style="--i: 3"><a href="{/literal}{$urls.base_url}{literal}pages/accompagnements" class="es-mm__link"><span>Accompagnements</span></a></li></ul><a href="{/literal}{$urls.base_url}{literal}pages/contact" class="es-button es-button--full es-mobile-menu__cta"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg><span>Parlons de votre intérieur</span></a><ul class="es-social" role="list"></ul>

  </div>
</header>




</div>{/literal}