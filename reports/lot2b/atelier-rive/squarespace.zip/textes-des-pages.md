## Accueil

### Section : ed-opening
- heading : Des espaces qui vous ressemblent.
- text : Des volumes plus lisibles, des matières qui se répondent et une place pensée pour chaque usage.
- button_label : Parlons de votre intérieur
- button_link : /pages/contact

### Section : ed-statement
- heading : Partir de votre quotidien. Dessiner ce qui lui manque.
- text : Un projet commence par la façon dont vous habitez : les passages, les gestes, la lumière et les objets que vous voulez garder.

### Section : ed-diptych
- heading : Des volumes, des usages, des intentions.
  - ratio : landscape · media_role : rive-02-cuisine · image_alt : rive 02 cuisine · title : Une cuisine qui ouvre la pièce. · text : Des circulations lisibles et une place pour préparer, échanger, se retrouver.
  - ratio : portrait · media_role : rive-03-chambre · image_alt : rive 03 chambre · title : Une chambre pour ralentir. · text : Une palette apaisée et des volumes qui laissent respirer les usages.
  - ratio : landscape · media_role : rive-04-entree · image_alt : rive 04 entree · title : Une entrée qui trouve sa place. · text : Accueillir, déposer, circuler : organiser le seuil de la maison.

### Section : ed-scene
- heading : Le caractère d'un lieu se joue aussi dans la matière.
- text : Bois, pierre et textiles composent une palette cohérente, pensée à l'échelle de votre intérieur.
- caption : Matières d'intention — démonstration

### Section : ref-narrative
- heading : Trois façons d'avancer.
  - title : Conseil & direction · text : Préciser l'ambiance et les choix qui donneront une direction à votre intérieur. · media_role : rive-08-plans · image_alt : rive 08 plans · caption : Projet d'intention — image de démonstration · link : /pages/conseil · link_label : Découvrir l'accompagnement
  - title : Aménagement d'une pièce · text : Organiser les usages, la circulation et les matières à l'échelle d'une pièce. · media_role : rive-06-bibliotheque · image_alt : rive 06 bibliotheque · caption : Projet d'intention — image de démonstration · link : /pages/amenagement-une-piece · link_label : Découvrir l'accompagnement
  - title : Projet d'ensemble · text : Relier plusieurs espaces autour d'une intention commune, avec un périmètre à définir ensemble. · media_role : rive-11-repas · image_alt : rive 11 repas · caption : Projet d'intention — image de démonstration · link : /pages/ensemble · link_label : Découvrir l'accompagnement

### Section : ed-scene
- heading : Donner une fonction aux espaces oubliés.
- text : Un passage peut accueillir un usage. Un angle peut retrouver une place dans la pièce. L'aménagement commence aussi par ces petits espaces que l'on traverse sans les regarder.
- caption : Projet d'intention — image de démonstration

### Section : ref-narrative
- heading : Échanger. Clarifier. Concevoir. Vous accompagner.
  - title : 01 — Échanger · text : Nous partons de votre quotidien : les gestes, les circulations et ce qui manque à la pièce. Vos priorités et les contraintes du lieu servent de point de départ, sans présumer du périmètre final.
  - title : 02 — Clarifier · text : Nous mettons en relation les volumes, la lumière et les matières. Des pistes d'ambiance permettent de discuter de vos préférences avant de retenir une direction.
  - title : 03 — Concevoir · text : L'implantation donne une place à chaque usage. Le choix des matières et du mobilier s'organise autour de cette proposition, avec les éléments à conserver et ceux à faire évoluer.
  - title : 04 — Vous accompagner · text : Nous reprenons ensemble les choix retenus et les points à approfondir. Le périmètre, le budget et le calendrier sont définis lors des échanges, sans engagement inventé dans cette démonstration.

### Section : ed-study
- heading : D'un volume à une intention.
- text : Deux vues d'intention pour discuter des usages et de la place du mobilier. Simulation de démonstration : ces images ne prouvent pas une réalisation client ni un avant/après parfaitement aligné.

### Section : v2-faq
- heading : Avant notre premier échange.
  - question : Puis-je commencer avec une seule pièce ? · answer : Oui. La page Aménagement d'une pièce présente cette approche ; le périmètre se précise au premier échange.
  - question : Faut-il déjà avoir un budget défini ? · answer : Une enveloppe ou des priorités permettent d'orienter la discussion. Aucun tarif ni budget de réalisation n'est validé dans cette démonstration.
  - question : Peut-on conserver du mobilier existant ? · answer : Les éléments à garder font partie des premières informations à partager pour organiser la proposition.
  - question : Les photographies présentent-elles des réalisations clients ? · answer : Non. Il s'agit de projets d'intention et d'images de démonstration, sans avis ni résultats clients revendiqués.
  - question : Quel est le délai pour mon projet ? · answer : Le calendrier dépend du périmètre défini ensemble. Aucun délai d'intervention ni disponibilité n'est promis ici.

### Section : ed-contact
- heading : Et si l'on commençait par votre pièce ?
- text : Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.

## Conseil & direction

### Section : ed-opening
- heading : Conseil & direction
- text : Préciser l'ambiance et les choix qui donneront une direction à votre intérieur.
- button_label : Parlons de votre intérieur
- button_link : #contact

### Section : ed-statement
- heading : Un périmètre à construire ensemble.
- text : Préciser l'ambiance et les choix qui donneront une direction à votre intérieur.
  - title : Vos usages et vos priorités
  - title : Les éléments à conserver
  - title : Les points à préciser au premier échange

### Section : ref-narrative
- heading : Échanger. Clarifier. Concevoir. Vous accompagner.
  - title : 01 — Échanger · text : Nous partons de votre quotidien : les gestes, les circulations et ce qui manque à la pièce. Vos priorités et les contraintes du lieu servent de point de départ, sans présumer du périmètre final.
  - title : 02 — Clarifier · text : Nous mettons en relation les volumes, la lumière et les matières. Des pistes d'ambiance permettent de discuter de vos préférences avant de retenir une direction.
  - title : 03 — Concevoir · text : L'implantation donne une place à chaque usage. Le choix des matières et du mobilier s'organise autour de cette proposition, avec les éléments à conserver et ceux à faire évoluer.
  - title : 04 — Vous accompagner · text : Nous reprenons ensemble les choix retenus et les points à approfondir. Le périmètre, le budget et le calendrier sont définis lors des échanges, sans engagement inventé dans cette démonstration.

### Section : ed-contact
- heading : Et si l'on commençait par votre pièce ?
- text : Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.

## Aménagement d'une pièce

### Section : ed-opening
- heading : Repensons la pièce que vous vivez le plus.
- text : Une proposition d'aménagement pour faire dialoguer vos usages, la lumière et les matières.
- button_label : Parler de ma pièce
- button_link : #contact

### Section : ed-statement
- heading : Pour quel projet ?
- text : Un salon, une pièce de repas ou une entrée : l'échelle d'une pièce permet de travailler les relations entre usages et volumes.
  - title : Salon — se retrouver, lire, recevoir
  - title : Pièce de repas — partager et circuler
  - title : Entrée — accueillir et organiser

### Section : ed-statement
- heading : Ce que nous préparons ensemble.
- text : La proposition s'appuie sur les informations que vous partagez et sur le périmètre convenu. Les livrables ci-dessous constituent une intention de démonstration, à adapter au projet.
  - title : Les besoins et les éléments à conserver
  - title : Une direction d'ambiance
  - title : Une proposition d'implantation
  - title : Des pistes de matières et de mobilier

### Section : ref-narrative
- heading : Échanger. Clarifier. Concevoir. Vous accompagner.
  - title : 01 — Échanger · text : Nous partons de votre quotidien : les gestes, les circulations et ce qui manque à la pièce. Vos priorités et les contraintes du lieu servent de point de départ, sans présumer du périmètre final.
  - title : 02 — Clarifier · text : Nous mettons en relation les volumes, la lumière et les matières. Des pistes d'ambiance permettent de discuter de vos préférences avant de retenir une direction.
  - title : 03 — Concevoir · text : L'implantation donne une place à chaque usage. Le choix des matières et du mobilier s'organise autour de cette proposition, avec les éléments à conserver et ceux à faire évoluer.
  - title : 04 — Vous accompagner · text : Nous reprenons ensemble les choix retenus et les points à approfondir. Le périmètre, le budget et le calendrier sont définis lors des échanges, sans engagement inventé dans cette démonstration.

### Section : ed-diptych
- heading : Du plan aux matières.
  - ratio : landscape · media_role : rive-08-plans · image_alt : rive 08 plans · title : L'implantation · text : Lire les passages, les proportions et les relations entre les usages.
  - ratio : portrait · media_role : rive-07-matieres · image_alt : rive 07 matieres · title : Les accords de matières · text : Faire dialoguer la lumière, les textures et les teintes.

### Section : ref-offers
- heading : Choisir le bon périmètre.
- text : Trois échelles de travail. Le contenu, le budget et le calendrier sont définis lors du premier échange ; aucun tarif n'est validé ici.
  - title : Conseil & direction · text : Préciser l'ambiance et les choix qui donneront une direction à votre intérieur. · link : /pages/conseil
  - title : Aménagement d'une pièce · text : Organiser les usages, la circulation et les matières à l'échelle d'une pièce. · link : /pages/amenagement-une-piece
  - title : Projet d'ensemble · text : Relier plusieurs espaces autour d'une intention commune, avec un périmètre à définir ensemble. · link : /pages/ensemble

### Section : ed-study
- heading : D'un volume à une intention.
- text : Deux vues d'intention pour discuter des usages et de la place du mobilier. Simulation de démonstration : ces images ne prouvent pas une réalisation client ni un avant/après parfaitement aligné.

### Section : v2-faq
- heading : Préciser votre projet.
  - question : Puis-je commencer avec une seule pièce ? · answer : Oui. La page Aménagement d'une pièce présente cette approche ; le périmètre se précise au premier échange.
  - question : Faut-il déjà avoir un budget défini ? · answer : Une enveloppe ou des priorités permettent d'orienter la discussion. Aucun tarif ni budget de réalisation n'est validé dans cette démonstration.
  - question : Peut-on conserver du mobilier existant ? · answer : Les éléments à garder font partie des premières informations à partager pour organiser la proposition.
  - question : Les photographies présentent-elles des réalisations clients ? · answer : Non. Il s'agit de projets d'intention et d'images de démonstration, sans avis ni résultats clients revendiqués.
  - question : Quel est le délai pour mon projet ? · answer : Le calendrier dépend du périmètre défini ensemble. Aucun délai d'intervention ni disponibilité n'est promis ici.

### Section : ed-contact
- heading : Et si l'on commençait par votre pièce ?
- text : Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.

## Projet d'ensemble

### Section : ed-opening
- heading : Projet d'ensemble
- text : Relier plusieurs espaces autour d'une intention commune, avec un périmètre à définir ensemble.
- button_label : Parlons de votre intérieur
- button_link : #contact

### Section : ed-statement
- heading : Un périmètre à construire ensemble.
- text : Relier plusieurs espaces autour d'une intention commune, avec un périmètre à définir ensemble.
  - title : Vos usages et vos priorités
  - title : Les éléments à conserver
  - title : Les points à préciser au premier échange

### Section : ref-narrative
- heading : Échanger. Clarifier. Concevoir. Vous accompagner.
  - title : 01 — Échanger · text : Nous partons de votre quotidien : les gestes, les circulations et ce qui manque à la pièce. Vos priorités et les contraintes du lieu servent de point de départ, sans présumer du périmètre final.
  - title : 02 — Clarifier · text : Nous mettons en relation les volumes, la lumière et les matières. Des pistes d'ambiance permettent de discuter de vos préférences avant de retenir une direction.
  - title : 03 — Concevoir · text : L'implantation donne une place à chaque usage. Le choix des matières et du mobilier s'organise autour de cette proposition, avec les éléments à conserver et ceux à faire évoluer.
  - title : 04 — Vous accompagner · text : Nous reprenons ensemble les choix retenus et les points à approfondir. Le périmètre, le budget et le calendrier sont définis lors des échanges, sans engagement inventé dans cette démonstration.

### Section : ed-contact
- heading : Et si l'on commençait par votre pièce ?
- text : Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.

## Parlons de votre intérieur

### Section : ed-opening
- heading : Parlons de votre intérieur.
- text : Un premier échange pour préciser ce que vous souhaitez faire évoluer.
- button_label : Décrire ma pièce
- button_link : #contact

### Section : ed-contact
- heading : Et si l'on commençait par votre pièce ?
- text : Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.

### Section : ed-scene
- heading : Une place pour chaque usage.
- text : Projet d'intention — image de démonstration.

## Inspirations

### Section : ed-opening
- heading : Des pistes pour habiter autrement.
- text : Projets d'intention — images de démonstration.
- button_label : Parlons de votre intérieur
- button_link : /pages/contact

### Section : ed-diptych
- heading : Des volumes, des usages, des intentions.
  - ratio : landscape · media_role : rive-02-cuisine · image_alt : rive 02 cuisine · title : Une cuisine qui ouvre la pièce. · text : Des circulations lisibles et une place pour préparer, échanger, se retrouver.
  - ratio : portrait · media_role : rive-03-chambre · image_alt : rive 03 chambre · title : Une chambre pour ralentir. · text : Une palette apaisée et des volumes qui laissent respirer les usages.
  - ratio : landscape · media_role : rive-04-entree · image_alt : rive 04 entree · title : Une entrée qui trouve sa place. · text : Accueillir, déposer, circuler : organiser le seuil de la maison.

### Section : ed-study
- heading : D'un volume à une intention.
- text : Deux vues d'intention pour discuter des usages et de la place du mobilier. Simulation de démonstration : ces images ne prouvent pas une réalisation client ni un avant/après parfaitement aligné.

## Les accompagnements

### Section : ed-opening
- heading : Une direction, à la bonne échelle.
- text : Conseil, une pièce ou plusieurs espaces : choisissons le périmètre qui répond à votre besoin.
- button_label : Parlons de votre intérieur
- button_link : /pages/contact

### Section : ref-narrative
- heading : Trois façons d'avancer.
  - title : Conseil & direction · text : Préciser l'ambiance et les choix qui donneront une direction à votre intérieur. · media_role : rive-08-plans · image_alt : rive 08 plans · caption : Projet d'intention — image de démonstration · link : /pages/conseil · link_label : Découvrir l'accompagnement
  - title : Aménagement d'une pièce · text : Organiser les usages, la circulation et les matières à l'échelle d'une pièce. · media_role : rive-06-bibliotheque · image_alt : rive 06 bibliotheque · caption : Projet d'intention — image de démonstration · link : /pages/amenagement-une-piece · link_label : Découvrir l'accompagnement
  - title : Projet d'ensemble · text : Relier plusieurs espaces autour d'une intention commune, avec un périmètre à définir ensemble. · media_role : rive-11-repas · image_alt : rive 11 repas · caption : Projet d'intention — image de démonstration · link : /pages/ensemble · link_label : Découvrir l'accompagnement

### Section : ref-narrative
- heading : Échanger. Clarifier. Concevoir. Vous accompagner.
  - title : 01 — Échanger · text : Nous partons de votre quotidien : les gestes, les circulations et ce qui manque à la pièce. Vos priorités et les contraintes du lieu servent de point de départ, sans présumer du périmètre final.
  - title : 02 — Clarifier · text : Nous mettons en relation les volumes, la lumière et les matières. Des pistes d'ambiance permettent de discuter de vos préférences avant de retenir une direction.
  - title : 03 — Concevoir · text : L'implantation donne une place à chaque usage. Le choix des matières et du mobilier s'organise autour de cette proposition, avec les éléments à conserver et ceux à faire évoluer.
  - title : 04 — Vous accompagner · text : Nous reprenons ensemble les choix retenus et les points à approfondir. Le périmètre, le budget et le calendrier sont définis lors des échanges, sans engagement inventé dans cette démonstration.

### Section : ed-contact
- heading : Et si l'on commençait par votre pièce ?
- text : Décrivez la pièce, ce que vous souhaitez y vivre et les points qui vous interrogent. Cette démonstration enregistre une demande de test : aucun e-mail n'est envoyé.