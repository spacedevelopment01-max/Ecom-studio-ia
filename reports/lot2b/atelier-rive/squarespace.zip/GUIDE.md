# Kit de création Squarespace — Atelier Rive

Squarespace n'accepte pas l'import d'un thème externe : ce kit n'est pas un thème installable.
Il rassemble tout ce qu'il faut pour reproduire fidèlement le site conçu dans le studio, dans l'éditeur de la plateforme.

## Étapes
1. Dans Squarespace, choisissez un modèle « Services » ou « Portfolio » épuré (pas de modèle Commerce).
2. Conception du site › Couleurs et Polices : reportez la palette et les familles indiquées ci-dessous.
3. Importez les médias du dossier « medias » dans la bibliothèque d'images.
4. Rendez-vous : utilisez Acuity Scheduling (intégré à Squarespace) ou un bouton vers votre lien de réservation.
5. Reconstituez les pages avec « textes-des-pages.md » (accueil, prestations, à propos, contact / rendez-vous, FAQ, mentions légales).
6. Infos pratiques : bloc Carte avec votre adresse, horaires en texte, téléphone en lien « tel: ».

## Palette
- scheme-1 : fond #EEEAE2 · texte #243B32 · accent #243B32 · texte sur accent #EEEAE2
- scheme-2 : fond #243B32 · texte #EEEAE2 · accent #EEEAE2 · texte sur accent #243B32
- scheme-3 : fond #FFFFFF · texte #243B32 · accent #243B32 · texte sur accent #FFFFFF

## Typographies
- Titres : Archivo
- Texte : Work Sans
