{literal}<div id="shopify-section-template--es__opening" class="shopify-section " data-es-section="index:opening" data-es-type="ed-opening">
<section class="ed-section ed-opening ed-opening--immersive color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell">
 <header class="ed-opening__copy"><p class="ed-kicker">ORBE — LUMIÈRE NOMADE</p>
 <h1 class="ed-title ed-opening__title" data-ed-title>La lumière change<br />
de place.<br />
L&#39;atmosphère aussi.</h1>
 <div class="ed-prose"><p>Du chevet à la table, une même silhouette accompagne les moments de la maison.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}products/lampe-nomade">Découvrir ORBE<span aria-hidden="true">↗</span></a></header>
 <div class="ed-opening__media"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-02-chambre"><p>Visuel à importer<span>orbe-02-chambre</span></p></div>
</div>
 
</div></section>

</div>
<div id="shopify-section-template--es__presence" class="shopify-section " data-es-section="index:presence" data-es-type="ed-statement">
<section class="ed-section ed-statement color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell ed-statement__grid"><header><h2 class="ed-title">Une présence discrète. Une ambiance qui reste.</h2><div class="ed-prose"><p>Un même objet, plusieurs façons de l'installer.</p></div></header><div class="ed-statement__aside"><ul class="ed-points" role="list"><li data-es-block="b0"><h3>Silhouette arrondie</h3><div class="ed-prose"></div></li><li data-es-block="b1"><h3>Trois finitions</h3><div class="ed-prose"></div></li><li data-es-block="b2"><h3>À poser au fil de vos envies</h3><div class="ed-prose"></div></li></ul></div></div></section>

</div>
<div id="shopify-section-template--es__moments" class="shopify-section " data-es-section="index:moments" data-es-type="ed-diptych">
<section class="ed-section ed-diptych ed-diptych--pair color-scheme-1" id="ambiances" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker"></p><h2 class="ed-title">Le temps d&#39;un dîner. Le calme d&#39;une lecture.</h2><div class="ed-prose"></div></header><div class="ed-diptych__grid"><figure class="ed-diptych__frame ed-ratio--landscape" data-es-block="b0"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-03-diner"><p>Visuel à importer<span>orbe-03-diner</span></p></div>
<figcaption><h3>Autour de la table</h3><div class="ed-prose"><p>Une lumière qui trouve sa place lorsque l'on se retrouve.</p></div><a class="ed-text-link" href="{/literal}{$urls.base_url}{literal}products/lampe-nomade?media=orbe-03-diner">Explorer cette intention<span aria-hidden="true">↗</span></a></figcaption></figure><figure class="ed-diptych__frame ed-ratio--portrait" data-es-block="b1"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-04-lecture"><p>Visuel à importer<span>orbe-04-lecture</span></p></div>
<figcaption><h3>Le temps pour soi</h3><div class="ed-prose"><p>Un point de lumière au fil des pages.</p></div><a class="ed-text-link" href="{/literal}{$urls.base_url}{literal}products/lampe-nomade?media=orbe-04-lecture">Explorer cette intention<span aria-hidden="true">↗</span></a></figcaption></figure></div></div></section>

</div>
<div id="shopify-section-template--es__night" class="shopify-section " data-es-section="index:night" data-es-type="ed-scene">
<section class="ed-section ed-scene ed-scene--split color-scheme-2" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><div class="ed-scene__media"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-08-lumiere"><p>Visuel à importer<span>orbe-08-lumiere</span></p></div>
</div><div class="ed-scene__copy"><p class="ed-kicker"></p><h2 class="ed-title">Quand la pièce ralentit.</h2><div class="ed-prose"><p>Une lumière d'ambiance et des lignes simples pour composer un coin plus intime.</p></div></div></div></section>

</div>
<div id="shopify-section-template--es__finishes" class="shopify-section " data-es-section="index:finishes" data-es-type="ed-finishes">
<section class="ed-section ed-finishes color-scheme-1" id="finitions" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;" data-ed-finishes>
 <div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker"></p><h2 class="ed-title">Dune. Argile. Charbon.</h2><div class="ed-prose"><p>Trois tonalités pour trouver votre place dans la pièce.</p></div></header><div class="ed-finishes__grid">
 <div class="ed-finishes__scene"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-07-trio"><p>Visuel à importer<span>orbe-07-trio</span></p></div>
</div>
 <div class="ed-finishes__selection"><div class="ed-finishes__views"><figure data-finish-view="1000"><div class="ed-media ed-media--pending"><p>Visuel à importer<span>Lampe nomade ORBE — Dune</span></p></div><figcaption>Dune</figcaption></figure><figure data-finish-view="1001" hidden><div class="ed-media ed-media--pending"><p>Visuel à importer<span>Lampe nomade ORBE — Argile</span></p></div><figcaption>Argile</figcaption></figure><figure data-finish-view="1002" hidden><div class="ed-media ed-media--pending"><p>Visuel à importer<span>Lampe nomade ORBE — Charbon</span></p></div><figcaption>Charbon</figcaption></figure></div>
 <fieldset><legend>Choisir les variantes</legend><label><input type="radio" name="ed-finish-template--es__finishes" value="1000" checked>Dune</label><label><input type="radio" name="ed-finish-template--es__finishes" value="1001">Argile</label><label><input type="radio" name="ed-finish-template--es__finishes" value="1002">Charbon</label></fieldset>
 <a class="ed-button" data-finish-link href="{/literal}{$urls.base_url}{literal}products/lampe-nomade#MainBuy">Choisir ma finition ↗</a></div>
 </div></div></section>

</div>
<div id="shopify-section-template--es__duo" class="shopify-section " data-es-section="index:duo" data-es-type="ed-scene">
<section class="ed-section ed-scene ed-scene--panorama color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><div class="ed-scene__media"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-06-duo"><p>Visuel à importer<span>orbe-06-duo</span></p></div>
</div><div class="ed-scene__copy"><p class="ed-kicker"></p><h2 class="ed-title">Deux points de lumière, un même équilibre.</h2><div class="ed-prose"><p>De part et d'autre d'une pièce ou dans deux espaces de la maison, composez le duo qui vous ressemble.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}products/lampe-nomade#MainBuy">Découvrir les offres<span aria-hidden="true">↗</span></a></div></div></section>

</div>
<div id="shopify-section-template--es__purchase" class="shopify-section es-section-wrapper" data-es-section="index:purchase" data-es-type="purchase-offers">
<div class="es-section color-scheme-1" style="--pt:32px;--pb:32px"><div class="es-container">

</div></div>

</div>
<div id="shopify-section-template--es__accessories" class="shopify-section " data-es-section="index:accessories" data-es-type="ed-diptych">
<section class="ed-section ed-diptych ed-diptych--pair color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><header class="ed-section-head"><p class="ed-kicker"></p><h2 class="ed-title">À offrir. À emporter.</h2><div class="ed-prose"></div></header><div class="ed-diptych__grid"><figure class="ed-diptych__frame ed-ratio--landscape" data-es-block="b0"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-11-boite"><p>Visuel à importer<span>orbe-11-boite</span></p></div>
<figcaption><h3>La boîte</h3><div class="ed-prose"><p>Une présentation dédiée. Accessoire distinct : aucune inclusion automatique dans les offres.</p></div></figcaption></figure><figure class="ed-diptych__frame ed-ratio--portrait" data-es-block="b1"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-12-pochette"><p>Visuel à importer<span>orbe-12-pochette</span></p></div>
<figcaption><h3>La pochette</h3><div class="ed-prose"><p>Une pochette offerte par lot à partir de trois lampes, selon le stock de démonstration.</p></div></figcaption></figure></div></div></section>

</div>
<div id="shopify-section-template--es__questions" class="shopify-section es-section-wrapper" data-es-section="index:questions" data-es-type="v2-faq"><section class="v2-faq v2-faq--side color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container v2-faq__grid">
    <header class="v2-head v2-faq__head"><h2 class="v2-h2" data-reveal="up">Les réponses, simplement.</h2></header>
    <div class="v2-faq__list"><details class="v2-faq__item" data-reveal="up" style="--i: 0" data-es-block="b0">
          <summary><span>Quelles finitions puis-je choisir ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Dune, Argile et Charbon. Chaque lampe d'un lot peut avoir sa propre finition.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 1" data-es-block="b1">
          <summary><span>Puis-je mélanger les couleurs dans un lot ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Oui. Sélectionnez votre offre puis la finition de chaque lampe avant de l'ajouter au panier de test.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 2" data-es-block="b2">
          <summary><span>Quand la pochette est-elle ajoutée ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Une pochette par lot de trois ou quatre lampes, selon le stock de démonstration. Elle est retirée si le lot passe sous trois lampes.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 3" data-es-block="b3">
          <summary><span>La boîte est-elle un cadeau automatique ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Non. La boîte et la pochette sont deux accessoires distincts ; seule la pochette suit la condition affichée.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 4" data-es-block="b4">
          <summary><span>Où trouver les caractéristiques techniques ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Autonomie, puissance, dimensions et alimentation restent à confirmer. Cette démonstration ne présente pas de performances ni de délais de livraison inventés.</p></div>
        </details></div>
  </div>
</section>


</div>
<div id="shopify-section-template--es__closing" class="shopify-section " data-es-section="index:closing" data-es-type="ed-scene">
<section class="ed-section ed-scene ed-scene--panorama color-scheme-1" data-ed-motion="reveal" style="--ed-pt:96px;--ed-pb:96px;">
<div class="ed-shell"><div class="ed-scene__media"><div class="ed-media ed-media--pending" role="img" aria-label="orbe-05-bureau"><p>Visuel à importer<span>orbe-05-bureau</span></p></div>
</div><div class="ed-scene__copy"><p class="ed-kicker"></p><h2 class="ed-title">Faites une place à la lumière.</h2><div class="ed-prose"><p>Commencez par une finition, puis composez votre ensemble.</p></div><a class="ed-button" href="{/literal}{$urls.base_url}{literal}products/lampe-nomade#MainBuy">Composer mon ORBE<span aria-hidden="true">↗</span></a></div></div></section>

</div>{/literal}