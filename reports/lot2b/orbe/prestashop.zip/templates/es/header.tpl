{literal}<div id="shopify-section-template--es__header_1" class="shopify-section es-header-section" data-es-section="group:header:header_1" data-es-type="header"><header class="es-header es-header--logo-left es-header--shape-bar es-header--icons-plain es-header--sticky color-scheme-1" data-header>
  <div class="es-header__inner es-container">
    <button class="es-header__burger es-icon-button" type="button" aria-controls="MobileMenu" aria-expanded="false" data-menu-open>
      <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 7h18M3 12h18M3 17h18"/></svg><span class="visually-hidden">Menu</span>
    </button>

    <a href="{/literal}{$urls.base_url}{literal}" class="es-header__logo" aria-label="ORBE"><span class="es-header__wordmark">ORBE</span></a>

    <nav class="es-header__nav" aria-label="Navigation principale">
      <ul role="list"><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}products/lampe-nomade" class="es-nav__link"><span>La lampe</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}#ambiances" class="es-nav__link"><span>Les ambiances</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}#finitions" class="es-nav__link"><span>Les finitions</span></a></li><li class="es-nav__item">
            <a href="{/literal}{$urls.base_url}{literal}pages/questions" class="es-nav__link"><span>Questions</span></a></li></ul>
    </nav>

    <div class="es-header__icons"><a href="{/literal}{$urls.pages.cart}{literal}" class="es-icon-button es-cart-link" data-cart-open aria-label="Panier">
          <svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 7h14l-1.2 12.1a1 1 0 0 1-1 .9H7.2a1 1 0 0 1-1-.9L5 7Z"/><path d="M9 7V6a3 3 0 0 1 6 0v1"/></svg>
          <span class="es-cart-count" data-cart-count{/literal}{if $cart.products_count == 0} hidden{/if}{literal}>{/literal}{$cart.products_count}{literal}</span>
        </a></div>
  </div>

  <div class="es-mobile-menu es-mobile-menu--sheet es-mobile-menu--sub-accordion color-scheme-1" id="MobileMenu" hidden data-mobile-menu>
    <div class="es-mobile-menu__head">
      <span class="es-header__wordmark">ORBE</span>
      <button type="button" class="es-icon-button" data-menu-close aria-label="Fermer"><svg class="es-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="m5 5 14 14M19 5 5 19"/></svg></button>
    </div><ul role="list" class="es-mobile-menu__list"><li style="--i: 1"><a href="{/literal}{$urls.base_url}{literal}products/lampe-nomade" class="es-mm__link"><span>La lampe</span></a></li><li style="--i: 2"><a href="{/literal}{$urls.base_url}{literal}#ambiances" class="es-mm__link"><span>Les ambiances</span></a></li><li style="--i: 3"><a href="{/literal}{$urls.base_url}{literal}#finitions" class="es-mm__link"><span>Les finitions</span></a></li><li style="--i: 4"><a href="{/literal}{$urls.base_url}{literal}pages/questions" class="es-mm__link"><span>Questions</span></a></li></ul><ul class="es-social" role="list"></ul>

  </div>
</header>




</div>{/literal}