{literal}<div id="shopify-section-template--es__footer_1" class="shopify-section es-footer-section" data-es-section="group:footer:footer_1" data-es-type="footer"><footer class="es-footer es-footer--reference-shop es-ambient color-scheme-1">
  <div class="es-container"><p class="ref-footer__signature" translate="no">ORBE</p><div class="es-footer__layout"><div class="es-footer__brandcol">
          <a href="{/literal}{$urls.base_url}{literal}" class="es-footer__brand color-scheme-1 ref-footer__logo-surface">ORBE</a><ul class="es-social" role="list"></ul>

        </div><div class="es-footer__grid"><div class="es-footer__block es-footer__block--text" data-es-block="about"><h2 class="es-footer__heading">La marque</h2><div class="es-rte"><p>ORBE — marque de démonstration. Prix fictifs, aucun paiement réel.</p></div></div><div class="es-footer__block es-footer__block--links" data-es-block="menu"><h2 class="es-footer__heading">ORBE</h2>
                <ul role="list" class="es-footer__links"><li><a href="{/literal}{$urls.base_url}{literal}products/lampe-nomade">La lampe</a></li><li><a href="{/literal}{$urls.base_url}{literal}#ambiances">Les ambiances</a></li><li><a href="{/literal}{$urls.base_url}{literal}#finitions">Les finitions</a></li><li><a href="{/literal}{$urls.base_url}{literal}pages/questions">Questions</a></li></ul></div></div></div><div class="es-footer__bottom">
      <p>&copy; 2026 ORBE</p><ul role="list" class="es-footer__policies"></ul><ul class="es-footer__payment" role="list"></ul></div>
  </div>
</footer>




</div>
    <div class="es-toast" role="status" aria-live="polite" hidden></div>
  </body>
</html>{/literal}