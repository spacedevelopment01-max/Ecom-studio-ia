{literal}<div id="shopify-section-template--es__questions" class="shopify-section es-section-wrapper" data-es-section="product.editorial:questions" data-es-type="v2-faq"><section class="v2-faq v2-faq--side color-scheme-1" style="--pt: 96px; --pb: 96px;">
  <div class="es-container v2-faq__grid">
    <header class="v2-head v2-faq__head"><h2 class="v2-h2" data-reveal="up">Avant de choisir.</h2></header>
    <div class="v2-faq__list"><details class="v2-faq__item" data-reveal="up" style="--i: 0" data-es-block="b0">
          <summary><span>Quelles finitions puis-je choisir ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Dune, Argile et Charbon. Chaque lampe d'un lot peut avoir sa propre finition.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 1" data-es-block="b1">
          <summary><span>Puis-je mélanger les couleurs dans un lot ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Oui. Sélectionnez votre offre puis la finition de chaque lampe avant de l'ajouter au panier de test.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 2" data-es-block="b2">
          <summary><span>Quand la pochette est-elle ajoutée ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Une pochette par lot de trois ou quatre lampes, selon le stock de démonstration. Elle est retirée si le lot passe sous trois lampes.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 3" data-es-block="b3">
          <summary><span>La boîte est-elle un cadeau automatique ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Non. La boîte et la pochette sont deux accessoires distincts ; seule la pochette suit la condition affichée.</p></div>
        </details><details class="v2-faq__item" data-reveal="up" style="--i: 4" data-es-block="b4">
          <summary><span>Où trouver les caractéristiques techniques ?</span><span class="v2-faq__plus" aria-hidden="true"></span></summary>
          <div class="v2-rte"><p>Autonomie, puissance, dimensions et alimentation restent à confirmer. Cette démonstration ne présente pas de performances ni de délais de livraison inventés.</p></div>
        </details></div>
  </div>
</section>


</div>{/literal}