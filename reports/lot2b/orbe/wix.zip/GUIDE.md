# Kit de création Wix — ORBE

Wix n'accepte pas l'import d'un thème externe : ce kit n'est pas un thème installable.
Il rassemble tout ce qu'il faut pour reproduire fidèlement la boutique conçue dans le studio, dans l'éditeur de la plateforme.

## Étapes
1. Dans l'éditeur Wix, créez un site vierge (ou un modèle Wix Stores sobre).
2. Thème du site › Couleurs : reportez la palette ci-dessous ; Thème du site › Texte : importez les polices du dossier « polices » (Ajouter des polices › Importer).
3. Médias : importez le dossier « medias » dans le gestionnaire de médias.
4. Wix Stores › Produits › Importer : utilisez « produits.csv » (vérifiez les colonnes avec le modèle CSV de Wix, puis ajoutez les images).
5. Reconstituez les pages avec les textes de « textes-des-pages.md » (accueil, produit, histoire, FAQ, contact, livraison).
6. Animations : Wix propose des effets d'apparition au défilement natifs (Animation › Entrée) ; préférez des effets discrets et vérifiez l'option de réduction des mouvements.

## Palette
- scheme-1 : fond #F4F0E8 · texte #29251F · accent #9B4F36 · texte sur accent #F4F0E8
- scheme-2 : fond #29251F · texte #F4F0E8 · accent #F4F0E8 · texte sur accent #29251F
- scheme-3 : fond #FFFFFF · texte #29251F · accent #9B4F36 · texte sur accent #FFFFFF

## Typographies
- Titres : Cormorant
- Texte : DM Sans
