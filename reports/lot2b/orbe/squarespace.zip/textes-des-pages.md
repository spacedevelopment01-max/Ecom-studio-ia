## Accueil

### Section : ed-opening
- heading : La lumière change de place. L'atmosphère aussi.
- text : Du chevet à la table, une même silhouette accompagne les moments de la maison.
- button_label : Découvrir ORBE
- button_link : /products/lampe-nomade

### Section : ed-statement
- heading : Une présence discrète. Une ambiance qui reste.
- text : Un même objet, plusieurs façons de l'installer.
  - title : Silhouette arrondie
  - title : Trois finitions
  - title : À poser au fil de vos envies

### Section : ed-diptych
- heading : Le temps d'un dîner. Le calme d'une lecture.
  - ratio : landscape · media_role : orbe-03-diner · image_alt : orbe 03 diner · title : Autour de la table · text : Une lumière qui trouve sa place lorsque l'on se retrouve. · link : /products/lampe-nomade?media=orbe-03-diner · link_label : Explorer cette intention
  - ratio : portrait · media_role : orbe-04-lecture · image_alt : orbe 04 lecture · title : Le temps pour soi · text : Un point de lumière au fil des pages. · link : /products/lampe-nomade?media=orbe-04-lecture · link_label : Explorer cette intention

### Section : ed-scene
- heading : Quand la pièce ralentit.
- text : Une lumière d'ambiance et des lignes simples pour composer un coin plus intime.

### Section : ed-finishes
- heading : Dune. Argile. Charbon.
- text : Trois tonalités pour trouver votre place dans la pièce.
- button_label : Choisir ma finition
- button_link : /products/lampe-nomade#MainBuy

### Section : ed-scene
- heading : Deux points de lumière, un même équilibre.
- text : De part et d'autre d'une pièce ou dans deux espaces de la maison, composez le duo qui vous ressemble.
- button_label : Découvrir les offres
- button_link : /products/lampe-nomade#MainBuy

### Section : purchase-offers
  - text : ORBE
  - 
  - 
  - picker : buttons
  - title : Une ORBE · price_mode : fixed_total
  - title : Le duo · price_mode : fixed_total · badge : Notre sélection
  - title : Le trio · price_mode : fixed_total
  - title : Quatre ORBE · price_mode : fixed_total
  - gift_target : product:catalog:pouch · sku : DEMO-POUCH
  - icon : check · title : Silhouette arrondie
  - icon : check · title : Trois finitions
  - icon : check · title : À poser au fil de vos envies

### Section : ed-diptych
- heading : À offrir. À emporter.
  - ratio : landscape · media_role : orbe-11-boite · image_alt : orbe 11 boite · title : La boîte · text : Une présentation dédiée. Accessoire distinct : aucune inclusion automatique dans les offres.
  - ratio : portrait · media_role : orbe-12-pochette · image_alt : orbe 12 pochette · title : La pochette · text : Une pochette offerte par lot à partir de trois lampes, selon le stock de démonstration.

### Section : v2-faq
- heading : Les réponses, simplement.
  - question : Quelles finitions puis-je choisir ? · answer : Dune, Argile et Charbon. Chaque lampe d'un lot peut avoir sa propre finition.
  - question : Puis-je mélanger les couleurs dans un lot ? · answer : Oui. Sélectionnez votre offre puis la finition de chaque lampe avant de l'ajouter au panier de test.
  - question : Quand la pochette est-elle ajoutée ? · answer : Une pochette par lot de trois ou quatre lampes, selon le stock de démonstration. Elle est retirée si le lot passe sous trois lampes.
  - question : La boîte est-elle un cadeau automatique ? · answer : Non. La boîte et la pochette sont deux accessoires distincts ; seule la pochette suit la condition affichée.
  - question : Où trouver les caractéristiques techniques ? · answer : Autonomie, puissance, dimensions et alimentation restent à confirmer. Cette démonstration ne présente pas de performances ni de délais de livraison inventés.

### Section : ed-scene
- heading : Faites une place à la lumière.
- text : Commencez par une finition, puis composez votre ensemble.
- button_label : Composer mon ORBE
- button_link : /products/lampe-nomade#MainBuy

## Fiche produit

### Section : main-product
  - text : ORBE
  - 
  - 
  - picker : buttons
  - title : Une ORBE · price_mode : fixed_total
  - title : Le duo · price_mode : fixed_total · badge : Notre sélection
  - title : Le trio · price_mode : fixed_total
  - title : Quatre ORBE · price_mode : fixed_total
  - gift_target : product:catalog:pouch · sku : DEMO-POUCH
  - icon : check · title : Silhouette arrondie
  - icon : check · title : Trois finitions
  - icon : check · title : À poser au fil de vos envies

## Notre histoire

### Section : rich-text
  - text : Notre histoire
  - text : Des objets qui trouvent leur place · size : h1
  - text : Une silhouette arrondie, trois finitions et des ambiances à composer dans la maison.

### Section : image-with-text
- heading : Pourquoi ce produit
- text : Lampe nomade à silhouette arrondie. Trois finitions : Dune, Argile et Charbon.

### Section : features-grid
- heading : Ce qui nous guide
  - title : Usage · text : Des objets pensés pour servir chaque jour. · icon : sparkle
  - title : Matières · text : Des matières décrites telles qu'elles sont. · icon : sparkle

### Section : cta-banner
- heading : Adopter Lampe nomade ORBE
- text : 
- button_label : Commander
- button_link : /products/lampe-nomade-orbe

## FAQ

### Section : faq
- heading : Questions fréquentes
  - question : Quelles sont ses dimensions ? · answer : [À compléter : dimensions]
  - question : En quelle matière ? · answer : [À compléter : matière]
  - question : Comment l'entretenir ? · answer : [À compléter : conseils d'entretien]
  - question : Comment l'utiliser ? · answer : [À compléter : mode d'emploi]
  - question : Quels sont les délais de livraison ? · answer : [À compléter : délais et tarifs de livraison]
  - question : Puis-je retourner ma commande ? · answer : [À compléter : conditions de retour]

### Section : contact-form
- heading : Une autre question ?
- text : Une question sur une commande ou un produit ? Nous vous répondons.

## Contact

### Section : contact-form
- heading : Écrivez-nous
- text : Une question sur une commande ou un produit ? Nous vous répondons.

## Livraison et retours

### Section : main-page

### Section : rich-text
  - text : Livraison et retours · size : h3
  - text : Livraison : [À compléter : délais et tarifs de livraison] Retours : [À compléter : conditions de retour] Contact : [À compléter : adresse e-mail du service client]