# Kit de création Squarespace — ORBE

Squarespace n'accepte pas l'import d'un thème externe : ce kit n'est pas un thème installable.
Il rassemble tout ce qu'il faut pour reproduire fidèlement la boutique conçue dans le studio, dans l'éditeur de la plateforme.

## Étapes
1. Dans Squarespace, choisissez un modèle Commerce épuré.
2. Conception du site › Couleurs : créez une palette avec les couleurs ci-dessous ; Polices : choisissez les familles indiquées (ou les plus proches disponibles ; Squarespace autorise l'import de polices personnalisées via CSS sur les offres compatibles).
3. Importez les médias du dossier « medias » dans la bibliothèque d'images.
4. Commerce › Produits › Importer : utilisez « produits.csv » (adaptez les colonnes au modèle d'import Squarespace).
5. Reconstituez les pages avec « textes-des-pages.md ».
6. Utilisez les animations de section natives avec parcimonie.

## Palette
- scheme-1 : fond #F4F0E8 · texte #29251F · accent #9B4F36 · texte sur accent #F4F0E8
- scheme-2 : fond #29251F · texte #F4F0E8 · accent #F4F0E8 · texte sur accent #29251F
- scheme-3 : fond #FFFFFF · texte #29251F · accent #9B4F36 · texte sur accent #FFFFFF

## Typographies
- Titres : Cormorant
- Texte : DM Sans
